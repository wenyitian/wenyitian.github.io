{
  "author":"Tangsan99999",
  "ua": "",
  "homeUrl": "http://789ba.com",
  //  "dcVipFlag": "false",
  //  "dcShow2Vip": {},
  "dcPlayUrl": "true",
  "cateNode": "//div[contains(@class,'stui-header_bd')]/ul[contains(@class, 'menu')]/li/a[contains(@href,'list')]",
  "cateName": "/text()",
  "cateId": "/@href",
  "cateIdR": "/list/(\\S+).html",
  "cateManual": {},
  "homeVodNode": "//div[contains(@class, 'stui-vodlist__box')]/a",
  "homeVodName": "/@title",
  "homeVodId": "/@href",
  "homeVodIdR": "/vod/(\\w+).html",
  "homeVodImg": "/@data-original",
  "homeVodImgR": "\\S+(http\\S+)",
  "homeVodMark": "/span[contains(@class,'pic-text')]/text()",
  "cateUrl": "http://789ba.com/show/{cateId}-{area}-{by}------{catePg}---{year}.html",
  "cateVodNode": "//div[contains(@class, 'stui-vodlist__box')]/a",
  "cateVodName": "/@title",
  "cateVodId": "/@href",
  "cateVodIdR": "/vod/(\\w+).html",
  "cateVodImg": "/@data-original",
  "cateVodImgR": "\\S+(http\\S+)",
  "cateVodMark": "/span[contains(@class,'pic-text')]/text()",
  "dtUrl": "http://789ba.com/vod/{vid}.html",
  "dtNode": "//body",
  "dtName": "//h1[@class='title']/text()",
  "dtNameR": "",
  "dtImg": "//div[@class='stui-content__thumb']/a/img/@data-original",
  "dtImgR": "\\S+(http\\S+)",
  "dtCate": "//p[@class='data']/span[contains(text(), '类型：')]/parent::*/a/text()",
  "dtCateR": "",
  "dtActor": "//p[@class='data']/span[contains(text(), '主演')]/parent::*/a/text()",
  "dtActorR": "",
  "dtDirector": "//p[@class='data']/span[contains(text(), '导演：')]/parent::*/a/text()",
  "dtDirectorR": "",
  "dtDesc": "//span[contains(text(), '简介：')]/parent::*/text()",
  "dtDescR": "",
  "dtFromNode": "//h3[contains(text(), '播放')]",
  "dtFromName": "concat('播放源',count(parent::*/preceding::*//h3[contains(text(), '播放')]) + 1)",
  "dtFromNameR": "(\\S+).0",
  "dtUrlNode": "//ul[contains(@class, 'stui-content__playlist')]",
  "dtUrlSubNode": "/li/a",
  "dtUrlId": "@href",
  "dtUrlIdR": "/play/(\\S+).html",
  "dtUrlName": "/text()",
  "dtUrlNameR": "",
  "playUrl": "http://789ba.com/play/{playUrl}.html",
  "playUa": "",
  "searchUrl": "http://789ba.com/index.php/ajax/suggest?mid=1&wd={wd}&limit=10",
  "scVodNode": "json:list",
  "scVodName": "name",
  "scVodId": "id",
  "scVodIdR": "",
  "scVodImg": "pic",
  "scVodMark": "",
  "filter": {
    "2": [
      {
        "key": "area",
        "name": "地区",
        "value": [
          {"n": "全部","v": ""},
          {"n": "大陆","v": "大陆"},
          {"n": "韩国","v": "韩国"},
          {"n": "香港","v": "香港"},
          {"n": "台湾","v": "台湾"},
          {"n": "日本","v": "日本"},
          {"n": "美国","v": "美国"},
          {"n": "泰国","v": "泰国"},
          {"n": "英国","v": "英国"},
          {"n": "新加坡","v": "新加坡"},
          {"n": "其他","v": "其他"}
        ]
      },
      {
        "key": "year",
        "name": "年份",
        "value": [
          {"n": "全部","v": ""},
          {"n": "2022","v": "2022"},
          {"n": "2021","v": "2021"},
          {"n": "2020","v": "2020"},
          {"n": "2019","v": "2019"},
          {"n": "2018","v": "2018"},
          {"n": "2017","v": "2017"},
          {"n": "2016","v": "2016"},
          {"n": "2015","v": "2015"},
          {"n": "2014","v": "2014"},
          {"n": "2013","v": "2013"},
          {"n": "2012","v": "2012"},
          {"n": "2011","v": "2011"},
          {"n": "2010","v": "2010"}
        ]
      },
      {
        "key": "by",
        "name": "排序",
        "value": [
          {"n": "时间","v": "time"},
          {"n": "人气","v": "hits"},
          {"n": "评分","v": "score"}
        ]
      }
    ],
    "1": [
      {
        "key": "area",
        "name": "地区",
        "value": [
          {"n": "全部","v": ""},
          {"n": "大陆","v": "大陆"},
          {"n": "韩国","v": "韩国"},
          {"n": "香港","v": "香港"},
          {"n": "台湾","v": "台湾"},
          {"n": "日本","v": "日本"},
          {"n": "美国","v": "美国"},
          {"n": "泰国","v": "泰国"},
          {"n": "英国","v": "英国"},
          {"n": "新加坡","v": "新加坡"},
          {"n": "其他","v": "其他"}
        ]
      },
      {
        "key": "year",
        "name": "年份",
        "value": [
          {"n": "全部","v": ""},
          {"n": "2022","v": "2022"},
          {"n": "2021","v": "2021"},
          {"n": "2020","v": "2020"},
          {"n": "2019","v": "2019"},
          {"n": "2018","v": "2018"},
          {"n": "2017","v": "2017"},
          {"n": "2016","v": "2016"},
          {"n": "2015","v": "2015"},
          {"n": "2014","v": "2014"},
          {"n": "2013","v": "2013"},
          {"n": "2012","v": "2012"},
          {"n": "2011","v": "2011"},
          {"n": "2010","v": "2010"}
        ]
      },
      {
        "key": "by",
        "name": "排序",
        "value": [
          {"n": "时间","v": "time"},
          {"n": "人气","v": "hits"},
          {"n": "评分","v": "score"}
        ]
      }
    ],
    "3": [
      {
        "key": "area",
        "name": "地区",
        "value": [
          {"n": "全部","v": ""},
          {"n": "内地","v": "内地"},
          {"n": "港台","v": "港台"},
          {"n": "日韩","v": "日韩"},
          {"n": "欧美","v": "欧美"}
        ]
      },
      {
        "key": "year",
        "name": "年份",
        "value": [
          {"n": "全部","v": ""},
          {"n": "2022","v": "2022"},
          {"n": "2021","v": "2021"},
          {"n": "2020","v": "2020"},
          {"n": "2019","v": "2019"},
          {"n": "2018","v": "2018"},
          {"n": "2017","v": "2017"},
          {"n": "2016","v": "2016"},
          {"n": "2015","v": "2015"},
          {"n": "2014","v": "2014"},
          {"n": "2013","v": "2013"},
          {"n": "2012","v": "2012"},
          {"n": "2011","v": "2011"},
          {"n": "2010","v": "2010"}
        ]
      },
      {
        "key": "by",
        "name": "排序",
        "value": [
          {"n": "时间","v": "time"},
          {"n": "人气","v": "hits"},
          {"n": "评分","v": "score"}
        ]
      }
    ],
    "4": [
      {
        "key": "area",
        "name": "地区",
        "value": [
          {"n": "全部","v": ""},
          {"n": "国产","v": "国产"},
          {"n": "日本","v": "日本"},
          {"n": "欧美","v": "欧美"},
          {"n": "其它","v": "其它"}
        ]
      },
      {
        "key": "year",
        "name": "年份",
        "value": [
          {"n": "全部","v": ""},
          {"n": "2022","v": "2022"},
          {"n": "2021","v": "2021"},
          {"n": "2020","v": "2020"},
          {"n": "2019","v": "2019"},
          {"n": "2018","v": "2018"},
          {"n": "2017","v": "2017"},
          {"n": "2016","v": "2016"},
          {"n": "2015","v": "2015"},
          {"n": "2014","v": "2014"},
          {"n": "2013","v": "2013"},
          {"n": "2012","v": "2012"},
          {"n": "2011","v": "2011"},
          {"n": "2010","v": "2010"}
        ]
      },
      {
        "key": "by",
        "name": "排序",
        "value": [
          {"n": "时间","v": "time"},
          {"n": "人气","v": "hits"},
          {"n": "评分","v": "score"}
        ]
      }
    ]
  }
}
