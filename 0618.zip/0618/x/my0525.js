🎀测试,#genre#
凤凰中文,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=37
凤凰资讯,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=36
凤凰香港,http://120.84.96.25:808/hls/81/index.m3u8
凤凰香港,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=38
TVB翡翠台,http://tv.mushui.tk:9090/itv/gd/utv/play.php?id=xgfeicui_1500
TVB翡翠台,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=67
TVB翡翠台,http://radius.8866.org:880/hls/80/index.m3u8
明珠台,http://tv.mushui.tk:9090/itv/gd/utv/play.php?id=1351_4500
明珠台,http://tv.mushui.tk:9090/itv/gd/utv/play.php?id=xgmingzhu_1500
TVB J2,http://120.84.96.25:808/hls/86/index.m3u8
TVB J2,http://120.84.96.33:808/hls/86/index.m3u8
TVB J2,http://120.84.96.32:808/hls/86/index.m3u8
TVB J2,http://120.84.96.29:808/hls/86/index.m3u8
TVB星河,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=135
TVB星河,http://tv.mushui.tk:9090/maotv/808xyz/tv.php?id=35
澳门莲花,http://nettvpro.live/hls/lotustv.php?zgangd
澳门莲花,http://anren.live/HK/BiIOU11uLA.m3u8?zgangd
澳门莲花,http://120.84.96.33:808/hls/24/index.m3u8
澳门莲花,http://ye23.win/iptv/lotustv2020.php
澳门莲花,http://120.84.96.25:808/hls/24/index.m3u8
天映经典,http://120.84.96.25:808/hls/85/index.m3u8
天映经典,http://tv.mushui.tk:9090/maotv/808xyz/tv.php?id=62
天映频道,http://50.7.220.74:8278/Celestial/playlist.m3u8?tid=MBBB6774222467742224&ct=19049&tsum=d0046a3b7f129d15414756b9fa75c512
东森电影,http://120.84.96.27:808/hls/32/index.m3u8
东森电影,http://120.84.96.29:808/hls/32/index.m3u8
东森电影,http://120.84.96.32:808/hls/32/index.m3u8
东森电影,http://tv.mushui.tk:9090/maotv/808xyz/tv.php?id=58
东森电影,http://120.84.96.25:808/hls/32/index.m3u8
东森电影,http://120.84.96.33:808/hls/32/index.m3u8
东森洋片,http://tv.mushui.tk:9090/maotv/808xyz/tv.php?id=59
东森洋片,http://120.84.96.25:808/hls/33/index.m3u8
东森洋片,http://120.84.96.33:808/hls/33/index.m3u8
龙祥时代,http://120.84.96.25:808/hls/35/index.m3u8
龙祥时代,http://tv.mushui.tk:9090/maotv/808xyz/tv.php?id=38
CCTV-1,http://120.84.96.25:808/hls/101/index.m3u8
CCTV-1,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=138
CCTV-2,http://120.84.96.25:808/hls/102/index.m3u8
CCTV-2,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=2
CCTV-3,http://120.84.96.25:808/hls/103/index.m3u8
CCTV-3,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=3
CCTV-4,http://120.84.96.25:808/hls/104/index.m3u8
CCTV-4,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=4
CCTV-5,http://120.84.96.25:808/hls/105/index.m3u8
CCTV-5+,http://120.84.96.25:808/hls/116/index.m3u8
CCTV-5+,http://120.84.96.25:808/hls/30/index.m3u8
CCTV-5,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=5
CCTV-5,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=16
CCTV-6,http://120.84.96.25:808/hls/106/index.m3u8
CCTV-6,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=6
CCTV-7,http://120.84.96.25:808/hls/107/index.m3u8
CCTV-7,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=7
CCTV-8,http://120.84.96.25:808/hls/108/index.m3u8
CCTV-8,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=8
CCTV-9,http://120.84.96.25:808/hls/109/index.m3u8
CCTV-9,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=9
CCTV-10,http://120.84.96.25:808/hls/110/index.m3u8
CCTV-11,http://120.84.96.25:808/hls/112/index.m3u8
CCTV-12,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=12
CCTV-14,http://120.84.96.25:808/hls/114/index.m3u8
CCTV-15,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=15
广东卫视,http://120.84.96.25:808/hls/121/index.m3u8
广东经济,http://120.84.96.25:808/hls/118/index.m3u8
广东经济,http://tv.mushui.tk:9090/itv/gd/utv/play.php?id=GDjingjikejiaoHD_7000
广东经济,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=66
广东经济,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=66
广东体育,http://120.84.96.25:808/hls/22/index.m3u8
广东体育,http://tv.mushui.tk:9090/itv/gd/utv/play.php?id=gdsportsHD_7000
广东体育,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=1
广东体育,http://tv.mushui.tk:9090/maotv/808xyz/tv.php?id=18
广东珠江,http://120.84.96.25:808/hls/122/index.m3u8
广东珠江,http://tv.mushui.tk:9090/itv/gd/utv/play.php?id=gdzhujiangHD_7500
广东珠江,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=41
湖南卫视,http://120.84.96.25:808/hls/126/index.m3u8
浙江卫视,http://120.84.96.25:808/hls/129/index.m3u8
江苏卫视,http://120.84.96.25:808/hls/130/index.m3u8
东方卫视,http://116.237.255.173:9901/tsfile/live/0107_1.m3u8
东方卫视,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=47
东方影视,http://116.237.255.173:9901/tsfile/live/1013_1.m3u8
东方影视,http://117.148.179.166:80/PLTV/88888888/224/3221231639/index.m3u8
北京卫视,http://120.84.96.25:808/hls/153/index.m3u8
北京卫视,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=45
深圳卫视,http://120.84.96.25:808/hls/125/index.m3u8
四川卫视,http://120.84.96.25:808/hls/165/index.m3u8
四川卫视,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=52
天津卫视,http://120.84.96.25:808/hls/149/index.m3u8
天津卫视,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=48
广西卫视,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=60
贵州卫视,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=53
河北卫视,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=57
黑龙江卫视,http://120.84.96.25:808/hls/139/index.m3u8
黑龙江卫视,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=50
湖北卫视,http://120.84.96.25:808/hls/128/index.m3u8
湖北卫视,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=51
东南卫视,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=55
安徽卫视,http://120.84.96.25:808/hls/131/index.m3u8
安徽卫视,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=49
吉林卫视,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=59
江西卫视,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=58
辽宁卫视,http://120.84.96.25:808/hls/133/index.m3u8
辽宁卫视,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=54
山东卫视,http://120.84.96.25:808/hls/132/index.m3u8
魅力音乐,http://tv.mushui.tk:9090/itv/gd/utv/play.php?id=meiliyinyueHD_7000
魅力足球,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=65
纪实人文,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=56
劲爆体育HD,http://tv.mushui.tk:9090/itv/gd/utv/play.php?id=jinbaotiyuHD_7000
新视觉HD,http://tv.mushui.tk:9090/itv/gd/utv/play.php?id=xinshijueHD_7000
求索动物HD,http://tv.mushui.tk:9090/itv/gd/utv/play.php?id=QSDWHD_7000
求索纪录HD,http://tv.mushui.tk:9090/itv/gd/utv/play.php?id=QSJLHD_7000
求索科学HD,http://tv.mushui.tk:9090/itv/gd/utv/play.php?id=qiusuokexueHD_7000
求索生活HD,http://tv.mushui.tk:9090/itv/gd/utv/play.php?id=QSSHHD_7000
全纪实HD,http://tv.mushui.tk:9090/itv/gd/utv/play.php?id=quanjishiHD_7000
欢笑剧场HD,http://tv.mushui.tk:9090/itv/gd/utv/play.php?id=huanxiaojuchangHD_7000
深圳电视剧频道,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=69
深圳都市频道,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=68
深圳体育健康,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=70
中国电影,http://tv.mushui.tk:9090/maotv/808xyz/tv.php?id=61

🈲港台,#genre#
凤凰资讯,http://39.135.55.105:6610/PLTV/88888888/224/3221227226/index.m3u8?servicetype=1
凤凰资讯,http://39.135.49.209:6610/PLTV/88888888/224/3221227226/1.m3u8?servicetype=1
凤凰资讯,http://183.207.249.35/PLTV/3/224/3221226923/index.m3u8
凤凰资讯,http://117.169.120.138:8080/live/fhzixun/index.m3u8
凤凰资讯,http://117.169.120.138:8080/live/fhzixun/.m3u8
凤凰中文,http://39.135.55.105:6610/PLTV/88888888/224/3221227222/index.m3u8?servicetype=1
凤凰中文,http://39.135.49.209:6610/PLTV/88888888/224/3221227222/1.m3u8?servicetype=1
凤凰中文,http://117.169.120.138:8080/live/fhchinese/index.m3u8
凤凰中文,http://117.169.120.138:8080/live/fhchinese/.m3u8
寰宇新闻,https://wabc.ml/hlk.php?id=136
寰宇新闻,http://60.249.146.250:8547/playlist.m3u8
寰宇财经,https://wabc.ml/hlk.php?id=141
TVBS新闻,http://38.64.72.148:80/hls/modn/list/4006/chunklist1.m3u8
TVBS新闻,http://38.64.72.148:80/hls/modn/list/4006/chunklist0.m3u8
TVBS新闻,http://38.64.72.148/hls/modn/list/4006/chunklist0.m3u8
台视新闻HD,http://38.64.72.148:80/hls/modn/list/4013/chunklist0.m3u8
台视新闻HD,http://38.64.72.148:80/hls/modn/list/4013/chunklist1.m3u8
东森新闻台,http://60.249.146.250:8594/playlist.m3u8
民视新闻台,http://60.249.146.250:8596/playlist.m3u8
民视新闻,https://wabc.ml/hlk.php?id=1011
民视新闻,http://38.64.72.148:80/hls/modn/list/4012/chunklist0.m3u8
华视新闻,http://60.249.146.250:8592/playlist.m3u8
三立新闻,http://60.249.146.250:8597/playlist.m3u8
亚洲新闻,http://d2e1asnsl7br7b.cloudfront.net/7782e205e72f43aeb4a48ec97f66ebbe/index_4.m3u8
亚洲ATV,https://juyunlive.juyun.tv/live/24950198.m3u8
无线新闻,http://radius.8866.org:880/hls/82/index.m3u8
无线财经,http://radius.8866.org:880/hls/83/index.m3u8
卫视中文台,http://60.249.146.250:8579/playlist.m3u8
卫视电影台,http://60.249.146.250:8553/playlist.m3u8
东森电影,http://120.84.96.46:808/hls/32/index.m3u8
东森电影,http://120.84.96.43:808/hls/32/index.m3u8
东森电影,http://120.84.96.42:808/hls/32/index.m3u8
东森电影,http://120.84.96.32:808/hls/32/index.m3u8
东森电影,http://120.84.96.29:808/hls/32/index.m3u8
东森电影,http://120.84.96.27:808/hls/32/index.m3u8
凤凰电影,http://111.59.189.40:8445/tsfile/live/1022_1.m3u8?zgangd
凤凰电影,http://111.59.189.40:8445/tsfile/live/1022_1.m3u8
澳门莲花,http://ye23.win/iptv/lotustv2020.php
澳门莲花,http://nettvpro.live/hls/lotustv.php
澳门莲花,http://anren.live/HK/BiIOU11uLA.m3u8?zgangd
澳门莲花,http://120.84.96.33:808/hls/24/index.m3u8
纬来综合台,http://60.249.146.250:8518/playlist.m3u8
纬来体育台,http://60.249.146.250:8563/playlist.m3u8
纬来日本台,http://60.249.146.250:8591/playlist.m3u8
天映经典,http://120.84.96.32:808/hls/85/index.m3u8?zgangd
台湾番薯台,http://61.216.67.119:1935/TWHG/E1/chunklist_w705811302.m3u8?zgangd
三立台湾TW,http://59.125.101.187:8501/playlist.m3u8
三立台湾,http://60.249.146.250:8534/playlist.m3u8
三立台湾,http://59.125.101.187:8501/http/60.251.39.91:8081/hls/65/807/ch20.m3u8
三立都会台,http://60.249.146.250:8557/playlist.m3u8
赛马直击,http://gslb.cdn.hk.chinamobile.com/live/d2afb43f61464fc5a3d3b1b0a4c187a1/11a674a3cca94ceaafab4bd0e2ae634c-2.m3u8
明珠台,http://radius.8866.org:880/hls/84/index.m3u8
翡翠台,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=67
翡翠台,http://radius.8866.org:880/hls/80/index.m3u8
凤凰香港,http://183.207.249.35/PLTV/3/224/3221226975/index.m3u8
民视台湾,https://wabc.ml/hlk.php?id=97
美食星球,https://wabc.ml/hlk.php?id=143
龙祥时代,http://120.84.96.32:808/hls/35/index.m3u8?zgangd
龙华戏剧,http://59.125.98.83:8534/playlist.m3u8
龙华戏剧,http://59.125.98.83:8534/http/192.168.1.9:8066/hls/210/10010/cstv10.m3u8?token=7375646f1298469fcd2cecf4cc31d29c6f203f0d?zgangd
龙华戏剧,http://59.125.98.83:8534/http/192.168.1.9:8066/hls/210/10010/cstv10.m3u8?token=7375646f1298469fcd2cecf4cc31d29c6f203f0d
龙华戏剧,http://59.125.98.83:8534/http/192.168.1.9:8066/hls/210/10010/cstv10.m3u8?token=7375646f1298469fcd2cecf4cc31d29c6f203f0d
龙华戏剧,http://59.125.98.83:8534/http/192.168.1.9:8066/hls/210/10010/cstv10.m3u8?token=7375646f1298469fcd2cecf4cc31d29c6f203f0d
龙华日韩,http://59.125.98.83:8535/playlist.m3u8
龙华日韩,http://59.125.98.83:8535/http/192.168.1.9:8066/hls/210/10011/cstv11.m3u8?token=7375646f1298469fcd2cecf4cc31d29c6f203f0d?zgangd
龙华日韩,http://59.125.98.83:8535/http/192.168.1.9:8066/hls/210/10011/cstv11.m3u8?token=7375646f1298469fcd2cecf4cc31d29c6f203f0d
龙华日韩,http://59.125.98.83:8535/http/192.168.1.9:8066/hls/210/10011/cstv11.m3u8?token=7375646f1298469fcd2cecf4cc31d29c6f203f0d
龙华日韩,http://59.125.98.83:8535/http/192.168.1.9:8066/hls/210/10011/cstv11.m3u8?token=7375646f1298469fcd2cecf4cc31d29c6f203f0d
龙华经典,https://wabc.ml/hlk.php?id=234
龙华电影,https://wabc.ml/hlk.php?id=132
靖天综合,https://wabc.ml/hlk.php?id=86
靖天映画,https://wabc.ml/hlk.php?id=114
靖天欢乐,https://wabc.ml/hlk.php?id=107
靖天国际,https://wabc.ml/hlk.php?id=155
寰宇综合,https://wabc.ml/hlk.php?id=142
寰宇新闻台湾台,https://wabc.ml/hlk.php?id=137
华视,http://60.249.146.250:8503/playlist.m3u8
公视,http://60.249.146.250:8505/playlist.m3u8
中视,http://60.249.146.250:8502/playlist.m3u8
耀才財經台,http://202.69.67.66:443/webcast/bshdlive-pc/playlist.m3u8
耀才财经,http://202.69.67.66:443/webcast/bshdlive-pc/playlist.m3u8?wowzasessionid=64000
动物星球,http://60.249.146.250:8512/playlist.m3u8
东森综合台,http://60.249.146.250:8581/playlist.m3u8
东森幼幼台,http://60.249.146.250:8515/playlist.m3u8
东森超视,http://60.249.146.250:8582/playlist.m3u8
东风卫视,http://60.249.146.250:8585/playlist.m3u8
点掌财经,http://cclive2.aniu.tv/live/anzb.m3u8?zgangd
大爱一台,https://pulltv1.wanfudaluye.com/live/tv1.m3u8
大爱二台,https://pulltv1.wanfudaluye.com/live/tv2.m3u8
博斯无限,https://wabc.ml/hlk.php?id=129
博斯网球,https://wabc.ml/hlk.php?id=53
博斯魅力,https://wabc.ml/hlk.php?id=135
博斯高球1,https://wabc.ml/hlk.php?id=108
博期无限II,https://wabc.ml/hlk.php?id=418
八大综合台,http://60.249.146.250:8520/playlist.m3u8
八大第一台,http://60.249.146.250:8519/playlist.m3u8
澳視卫星,http://61.244.22.5/ch3/ch3.live/chunklist_w30461384.m3u8
澳视综艺,http://61.244.22.5/ch6/definst/hd_ch6.live/playlist.m3u8
澳视葡文,http://61.244.22.4/ch2/ch2.live/playelist.m3u8
澳视澳门,http://61.244.22.4/ch1/ch1.live/playelist.m3u8
澳视澳门,http://103.233.191.133:1935/ch1/ch1.live/playlist.m3u8?$全网高清720P
澳视澳门,http://103.233.191.133:1935/ch1/ch1.live/playlist.m3u8?$全网高清720P
澳视澳门,http://103.233.191.133:1935/ch1/ch1.live/playlist.m3u8
澳门综艺,http://61.244.22.4/ch6/definst/hd_ch6.live/playlist.m3u8
澳门资讯,http://61.244.22.5/ch5/definst/info_ch5.live/playlist.m3u8
澳门资讯,http://61.244.22.4/ch5/info_ch5.live/master.m3u8
澳门资讯,http://61.244.22.4/ch5/info_ch5.live/chunklist_w1046558591.m3u8
澳门资讯,http://103.233.191.133:1935/ch5/info_ch5.live/playlist.m3u8
澳门体育,http://103.233.191.132:1935/ch4/sport_ch4.live/playlist.m3u8
澳门macau,http://103.233.191.132:1935/ch3/ch3.live/playlist.m3u8
ViuTV6,http://radius.8866.org:880/hls/85/index.m3u8
ViuTV6,http://kkmix1.f3322.net:762/hls/ch2/s.m3u8?zgangd
ViuTV,http://radius.8866.org:880/hls/86/index.m3u8
viu6,http://kkmix1.f3322.net:762/hls/ch2/s.m3u8
SMART,https://wabc.ml/hlk.php?id=68
RHK32,http://radius.8866.org:880/hls/90/index.m3u8
RHK31,http://radius.8866.org:880/hls/89/index.m3u8
NHK国际频道,https://nhkwlive-ojp.akamaized.net/hls/live/2003459/nhkwlive-ojp-en/index_4M.m3u8
NHK国际频道,https://nhkw-zh-hlscomp.akamaized.net:443/8thz5iufork8wjip/playlist.m3u8
NHK国际频道,http://nhkw-zh-hlscomp.akamaized.net/8thz5iufork8wjip/playlist.m3u8
NBC News Now F,http://nbcnews2.akamaized.net/hls/live/723426-b/NBCNewsPlaymaker24x7Linear99a3a827-ua/master.m3u8
MIGU24小时体育,http://117.148.179.172/PLTV/88888888/224/3221231778/index.m3u8
J2,http://120.84.96.32:808/hls/86/index.m3u8?zgangd
HQKKQTV,https://wabc.ml/hlk.php?id=422
HBO亚洲台,http://60.249.146.250:8580/playlist.m3u8
HBO其他,https://wabc.ml/hlk.php?id=228
Good2,https://wabc.ml/hlk.php?id=103
Global News,https://live.corusdigitaldev.com/groupd/live/8970c668-40cd-4ca9-8c4d-25fd04f619b5/live.isml/.m3u8
Global News,https://live.corusdigitaldev.com/groupd/live/49a91e7f-1023-430f-8d66-561055f3d0f7/live.isml/master.m3u8
Global News,https://live.corusdigitaldev.com/groupb/live/215422c9-d1b9-4009-aaca-32e403f22b01/live.isml/.m3u8
Global News,https://live.corusdigitaldev.com/groupa/live/48a5882b-a1ec-42d7-bfd7-6c2739e737da/live.isml/.m3u8
FOXMOVIES,http://60.249.146.250:8560/playlist.m3u8
FOX,http://60.249.146.250:8561/playlist.m3u8
Fox Sports News,https://austchannel-live.akamaized.net/hls/live/2002736/austchannel-sport/master.m3u8
fashion TV,https://fashiontv-fashiontv-2-es.samsung.wurl.com/manifest/playlist.m3u8
ET综合,https://wabc.ml/hlk.php?id=146
EDGESport,https://edgesports-sportstribal.amagi.tv/playlist.m3u8
EDGEsport,https://edgesport-samsungus.amagi.tv/playlist.m3u8
Dubai Racing 3,http://dmithrvll.cdn.mangomolo.com/dubaimubasher/smil:dubaimubasher.smil/playlist.m3u8
Dubai Racing 2,http://dmithrvll.cdn.mangomolo.com/dubairacing/smil:dubairacing.smil/chunklist_b1600000.m3u8
Discovery,http://60.249.146.250:8510/playlist.m3u8
CNA亚洲新闻,https://d2e1asnsl7br7b.cloudfront.net/7782e205e72f43aeb4a48ec97f66ebbe/index_5.m3u8
BBC World News,https://livecdn.fptplay.net/sdb/bbcnew_2000.stream/chunklist_b2500000.m3u8
BBC Lifestyle,https://livecdn.fptplay.net/sdb/bbclifestyle_2000.stream/chunklist_b2500000.m3u8
BBC Earth,https://livecdn.fptplay.net/hda2/bbcearth_vhls.smil/chunklist_b5000000.m3u8
BabyFirst,https://wabc.ml/hlk.php?id=78
Arirang,http://amdlive-ch03.ctnd.com.edgesuite.net/arirang_3ch/smil:arirang_3ch.smil/chunklist_b1728000_sleng.m3u8
Arirang,http://amdlive.ctnd.com.edgesuite.net/arirang_3ch/smil:arirang_3ch.smil/.m3u8
Arirang,http://amdlive.ctnd.com.edgesuite.net/arirang_1ch/smil:arirang_1ch.smil/.m3u8
Animax,https://livecdn.fptplay.net/hda3/animaxport_2000.stream/.m3u8
ABC News,http://cms-wowza.lunabyte.io/wbrz-live-1/definst/smil:wbrz-live.smil/chunklist_b1300000.m3u8

💥新闻,#genre#
凤凰中文,http://111.13.42.232/PLTV/88888888/224/3221225942/1.m3u8?icpid=88888888&from=1&hms_devid=459?zgangd
凤凰中文,http://111.59.189.40:8445/tsfile/live/1020_1.m3u8
凤凰中文,http://39.135.49.209:6610/PLTV/88888888/224/3221227222/1.m3u8?servicetype=1
凤凰中文,http://39.135.49.209:6610/PLTV/88888888/224/3221227222/1.m3u8?servicetype=1$闽移动FHD
凤凰中文,http://39.135.49.209:6610/PLTV/88888888/224/3221227222/1.m3u8?servicetype=1?zgangd
凤凰中文,http://39.135.55.105:6610/PLTV/88888888/224/3221227222/index.m3u8?servicetype=1
凤凰中文,http://39.135.55.105:6610/PLTV/88888888/224/3221227222/index.m3u8?servicetype=1&IASHttpSessionId=OTT2805920220502041807053655
凤凰中文,http://39.135.55.105:6610/PLTV/88888888/224/3221227222/index.m3u8?servicetype=1?zgangd
凤凰中文,http://39.135.55.7:6610/PLTV/88888888/224/3221227222/1ndex.m3u8?servicetype=1&IASHttpSessionld=OTT&IASHttpSessionId=OTT3514020220406143948025713?zgangd
凤凰中文,http://39.135.55.7:6610/PLTV/88888888/224/3221227222/1ndex.m3u8?servicetype=1&IASHttpSessionld=OTT?zgangd
凤凰中文,http://play-live.ifeng.com/live/06OLEGEGM4G.m3u8
凤凰资讯,http://111.13.42.230/PLTV/88888888/224/3221225949/1.m3u8?zgangd
凤凰资讯,http://111.59.189.40:8445/tsfile/live/1021_1.m3u8
凤凰资讯,http://111.59.189.40:8445/tsfile/live/1021_1.m3u8?zgangd
凤凰资讯,http://39.135.49.209:6610/PLTV/88888888/224/3221227226/1.m3u8?servicetype=1
凤凰资讯,http://39.135.49.209:6610/PLTV/88888888/224/3221227226/1.m3u8?servicetype=1$闽移动FHD
凤凰资讯,http://39.135.49.209:6610/PLTV/88888888/224/3221227226/1.m3u8?servicetype=1?zgangd
凤凰资讯,http://39.135.55.10:6610/PLTV/88888888/224/3221227226/index.m3u8?servicetype=1&IASHttpSessionId=OTT3410420220406144433022303?zgangd
凤凰资讯,http://39.135.55.105:6610/PLTV/88888888/224/3221227226/index.m3u8?servicetype=1
凤凰资讯,http://39.135.55.105:6610/PLTV/88888888/224/3221227226/index.m3u8?servicetype=1&IASHttpSessionId=OTT2727320220502042549047624
凤凰资讯,http://39.135.55.105:6610/PLTV/88888888/224/3221227226/index.m3u8?servicetype=1?zgangd
凤凰资讯,http://39.135.55.7:6610/PLTV/88888888/224/3221227226/index.m3u8?servicetype=1&IASHttpSessionld=OTT?zgangd
凤凰资讯,http://play-live.ifeng.com/live/06OLEEWQKN4.m3u8
凤凰资讯,http://play-live.ifeng.com/live/06OLEEWQKN4.m3u8?zgangd
寰宇新闻,https://wabc.ml/hlk.php?id=136
TVBS新闻,http://38.64.72.148/hls/modn/list/4006/chunklist0.m3u8
TVBS新闻,http://38.64.72.148:80/hls/modn/list/4006/chunklist0.m3u8
TVBS新闻,http://38.64.72.148:80/hls/modn/list/4006/chunklist1.m3u8
东森新闻,https://ssttvv1.6zxr.xyz/dsxw/index.m3u8
民视新闻,http://38.64.72.148:80/hls/modn/list/4012/chunklist0.m3u8
民视新闻,http://38.64.72.148:80/hls/modn/list/4012/chunklist1.m3u8
台视新闻,http://38.64.72.148:80/hls/modn/list/4013/chunklist0.m3u8
中天新闻,http://60.251.59.179:8529/http/192.168.77.24:8081/hls/64/806/ch16.m3u8
CCTV-1,http://39.134.115.163:8080/PLTV/88888910/224/3221225618/index.m3u8
CCTV-1,http://39.134.115.163:8080/PLTV/88888910/224/3221225642/index.m3u8
CCTV-1,http://39.135.138.60:18890/PLTV/88888910/224/3221225618/index.m3u8
CCTV-1,http://39.135.47.100:6610/000000001000/HD-8000k-1080P-cctv1/1.m3u8?IASHttpSessionId=OTT
CCTV-1,http://39.135.55.105:6610/PLTV/88888888/224/3221225922/index.m3u8?servicetype=1
CCTV-1,http://39.135.55.105:6610/PLTV/88888888/224/3221226995/index.m3u8?servicetype=1
CCTV-1,http://117.148.179.155:80/PLTV/88888888/224/3221231468/1.m3u8
CCTV-1,http://117.169.120.140:8080/live/cctv-1/.m3u8
CCTV-1,http://183.207.249.15/PLTV/3/224/3221225530/index.m3u8
CCTV-1,http://222.132.191.125:9901/tsfile/live/0001_1.m3u8
CCTV-1,http://39.135.55.105:6610/PLTV/88888888/224/3221226995/index.m3u8?servicetype=1
CCTV-13,http://117.169.120.142:8080/live/cctv-13/1.m3u8
CCTV-13,http://183.207.249.14/PLTV/3/224/3221225560/index.m3u8
CCTV-13,http://183.207.249.36/PLTV/4/224/3221227387/index.m3u8
CCTV-13,http://39.134.115.163:8080/PLTV/88888910/224/3221225638/index.m3u8
CCTV-13,http://39.134.116.30:8080/PLTV/88888910/224/3221225638/index.m3u8
CCTV-13,http://39.135.138.60:18890/PLTV/88888910/224/3221225638/index.m3u8
CCTV-13,http://39.135.55.105:6610/PLTV/88888888/224/3221225817/index.m3u8?servicetype=1
CCTV-13,http://39.135.55.105:6610/PLTV/88888888/224/3221226985/index.m3u8?servicetype=1
CCTV-13,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225638/index.m3u8
CCTV-13,http://tv.mushui.tk:9090/itv/gd/utv/play.php?id=yueyuHD_7000
CCTV-2,http://39.134.115.163:8080/PLTV/88888910/224/3221225619/index.m3u8
CCTV-2,http://39.134.115.163:8080/PLTV/88888910/224/3221225643/index.m3u8
CCTV-2,http://39.135.138.58:18890/PLTV/88888888/224/3221225643/index.m3u8
CCTV-2,http://39.135.138.60:18890/PLTV/88888910/224/3221225619/index.m3u8
CCTV-2,http://39.135.138.60:18890/PLTV/88888910/224/3221225643/index.m3u8
CCTV-2,http://39.135.47.100:6610/000000001000/HD-8000k-1080P-cctv2/1.m3u8?IASHttpSessionId=OTT
CCTV-2,http://39.135.55.105:6610/PLTV/88888888/224/3221225923/index.m3u8?servicetype=1
CCTV-2,http://39.135.55.105:6610/PLTV/88888888/224/3221226915/index.m3u8?servicetype=1
CCTV-2,http://migu.jilu8.cn/3221232362/index.m3u8
CCTV-2,http://117.148.179.147/TVOD/88888888/224/3221231678/index.m3u8
CCTV-2,http://117.148.179.147:80/PLTV/88888888/224/3221231678/1.m3u8
CCTV-2,http://117.169.120.140:8080/live/cctv-2/.m3u8
CCTV-4,http://183.207.248.15/PLTV/3/224/3221225534/index.m3u8?$移动超清1080P
CCTV-4,http://222.132.191.125:9901/tsfile/live/0004_1.m3u8
CCTV-4,http://39.135.138.58:18890/PLTV/88888888/224/3221225621/index.m3u8
CCTV-4,http://39.135.138.58:18890/PLTV/88888888/224/3221225621/index.m3u8?$移动蓝光1080P
CCTV-4,http://39.135.138.60:18890/PLTV/88888910/224/3221225621/index.m3u8
CCTV-4,http://39.135.55.105:6610/PLTV/88888888/224/3221225802/index.m3u8?servicetype=1
CCTV-4,http://39.135.55.105:6610/PLTV/88888888/224/3221226968/index.m3u8?servicetype=1
CCTV-4,http://tv.mushui.tk:9090/itv/gd/utv/play.php?id=CCTV-4HD_7500
CCTV-4,http://117.148.179.182/PLTV/88888888/224/3221231726/index.m3u8
CCTV-4,http://117.148.179.182/TVOD/88888888/224/3221231726/index.m3u8
CCTV-4,http://117.148.179.183/PLTV/88888888/224/3221231726/index.m3u8
CNA亚洲新闻,http://d2e1asnsl7br7b.cloudfront.net/7782e205e72f43aeb4a48ec97f66ebbe/index_4.m3u8
CNA亚洲新闻,https://d2e1asnsl7br7b.cloudfront.net/7782e205e72f43aeb4a48ec97f66ebbe/index_5.m3u8
FOX新闻,https://fox-foxnewsnow-samsungus.amagi.tv/playlist720p.m3u8

👌精品,#genre#

CCTV6电影高清,http://39.135.138.58:18890/PLTV/88888888/224/3221225632/index.m3u8
CCTV6电影高清,http://111.20.41.252:80/dbiptv.sn.chinamobile.com/PLTV/88888888/224/3221226393/1.m3u8
CCTV6电影高清,http://111.20.33.93:80/PLTV/88888893/224/3221226011/index.m3u8
CCTV6电影高清,http://39.135.55.105:6610/PLTV/88888888/224/3221227137/index.m3u8?servicetype=1
CCTV6电影高清,http://39.135.138.59:18890/PLTV/88888910/224/3221225632/index.m3u8
CCTV6电影高清,http://117.148.179.153:80/PLTV/88888888/224/3221231724/index.m3u8
CCTV6电影高清,http://117.148.179.153/TVOD/88888888/224/3221231724/index.m3u8
CHC动作电影,http://59.49.41.41/live.aishang.ctlcdn.com/00000110240324_1/playlist.m3u8?CONTENTID=00000110240324_1
CHC动作电影,http://111.20.33.93/TVOD/88888893/224/3221226465/index.m3u8
CHC动作电影,http://39.134.18.82/dbiptv.sn.chinamobile.com/PLTV/88888890/224/3221226465/index.m3u8
CHC高清电影,http://39.134.18.82/dbiptv.sn.chinamobile.com/PLTV/88888890/224/3221226463/index.m3u8
CHC高清电影,http://tv.mushui.tk:9090/itv/gd/utv/play.php?id=CHCHD_7000
CHC高清电影,http://59.49.41.41/live.aishang.ctlcdn.com/00000110240325_1/playlist.m3u8?CONTENTID=00000110240325_1
CHC家庭影院,http://111.20.33.93/TVOD/88888893/224/3221226462/index.m3u8
CHC家庭影院,http://39.134.18.82/dbiptv.sn.chinamobile.com/PLTV/88888890/224/3221226462/index.m3u8
CHC家庭影院,http://117.148.179.151/PLTV/88888888/224/3221231799/index.m3u8
CHC家庭影院,http://39.134.19.252:6610/yinhe/2/ch00000090990000002085/index.m3u8?virtualDomain=yinhe.live_hls.zte.com
CHC家庭影院,http://59.49.41.41/live.aishang.ctlcdn.com/00000110240323_1/playlist.m3u8?CONTENTID=00000110240323_1
CCTV3综艺高清,http://39.135.55.105:6610/PLTV/88888888/224/3221227055/index.m3u8?servicetype=1
CCTV3综艺高清,http://39.135.55.105:6610/PLTV/88888888/224/3221227055/index.m3u8?servicetype=1
CCTV3综艺高清,http://111.40.196.29/PLTV/88888888/224/3221225588/index.m3u8
CCTV3综艺高清,http://39.134.65.175/PLTV/88888888/224/3221225799/index.m3u8
CCTV3综艺高清,http://111.20.41.249:80/dbiptv.sn.chinamobile.com/PLTV/88888888/224/3221226397/1.m3u8
CCTV3综艺高清,http://117.148.179.183:80/PLTV/88888888/224/3221231682/index.m3u8
CCTV8电视剧高清,http://39.136.48.99:8089/PLTV/88888888/224/3221226429/index.m3u8
CCTV8电视剧高清,http://59.49.41.41/live.aishang.ctlcdn.com/00000110240249_1/playlist.m3u8?CONTENTID=00000110240249_1
CCTV8电视剧高清,http://39.135.55.105:6610/PLTV/88888888/224/3221227174/index.m3u8?servicetype=1
CCTV8电视剧高清,http://39.135.55.105:6610/PLTV/88888888/224/3221227174/index.m3u8?servicetype=1
CCTV8电视剧高清,http://39.135.138.58:18890/PLTV/88888888/224/3221225631/index.m3u8
CCTV8电视剧高清,http://111.40.196.31/PLTV/88888888/224/3221225592/index.m3u8
CCTV8电视剧高清,http://117.148.179.160/TVOD/88888888/224/3221231694/index.m3u8
CCTV8电视剧高清,http://117.148.179.160:80/PLTV/88888888/224/3221231694/index.m3u8
CCTV8电视剧高清,http://39.135.138.59:18890/TVOD/88888910/224/3221225635/index.m3u8
湖南卫视,http://222.132.191.125:9901/tsfile/live/0128_1.m3u8
湖南卫视,http://39.135.55.105:6610/PLTV/88888888/224/3221227232/index.m3u8?servicetype=1
湖南卫视,http://39.134.66.66/PLTV/88888888/224/3221225506/index.m3u8
湖南卫视,http://39.135.138.58:18890/PLTV/88888910/224/3221225704/index.m3u8
湖南卫视,http://39.135.138.59:18890/PLTV/88888910/224/3221225745/index.m3u8
湖南卫视,http://117.148.179.135/PLTV/88888888/224/3221230206/index.m3u8
湖南卫视,http://117.148.179.148/PLTV/88888888/224/3221230824/index.m3u8
湖南卫视,http://39.134.115.163:8080/PLTV/88888910/224/3221225745/index.m3u8
湖南卫视,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225490/index.m3u8?fmt=ts2hls
湖南卫视,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225704/index.m3u8
湖南卫视,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225745/index.m3u8
湖南卫视,http://39.135.138.59:18890/PLTV/88888910/224/3221225704/index.m3u8
湖南卫视,http://117.148.179.172/PLTV/88888888/224/3221231729/index.m3u8
浙江卫视,http://222.132.191.125:9901/tsfile/live/0124_1.m3u8
浙江卫视,http://39.135.55.105:6610/PLTV/88888888/224/3221227193/index.m3u8?servicetype=1
浙江卫视,http://39.135.138.59:18890/PLTV/88888910/224/3221225744/index.m3u8
浙江卫视,http://117.148.179.140/PLTV/88888888/224/3221229352/index.m3u8
东方卫视,http://112.25.47.24/gitv_live/G_DONGFANG-HD-265-8M/G_DONGFANG-HD-265-8M.m3u8?p=GITV&area=JS_CMCC_CP
东方卫视,http://112.25.47.24/gitv_live/G_DONGFANG-MD/G_DONGFANG-MD.m3u8?p=GITV&area=JS_CMCC_CP
东方卫视,http://222.132.191.125:9901/tsfile/live/0107_1.m3u8
东方卫视,http://39.135.55.105:6610/PLTV/88888888/224/3221226603/index.m3u8?servicetype=1
东方卫视,http://39.135.55.105:6610/PLTV/88888888/224/3221227059/index.m3u8?servicetype=1
东方卫视,http://39.135.55.105:6610/PLTV/88888888/224/3221226895/index.m3u8?servicetype=1
东方卫视,http://39.135.138.58:18890/PLTV/88888910/224/3221225659/index.m3u8
东方卫视,http://39.135.138.59:18890/PLTV/88888910/224/3221225658/index.m3u8
东方卫视,http://117.148.179.167/PLTV/88888888/224/3221231450/index.m3u8
东方卫视,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225489/index.m3u8?fmt=ts2hls
东方卫视,http://117.148.179.160/PLTV/88888888/224/3221231738/index.m3u8
江苏卫视,http://222.132.191.125:9901/tsfile/live/0127_1.m3u8
江苏卫视,http://39.135.55.105:6610/PLTV/88888888/224/3221225847/index.m3u8?servicetype=1
江苏卫视,http://39.135.55.105:6610/PLTV/88888888/224/3221227160/index.m3u8?servicetype=1
江苏卫视,http://39.134.66.66/PLTV/88888888/224/3221225503/index.m3u8
江苏卫视,http://117.148.179.175/PLTV/88888888/224/3221231447/index.m3u8
江苏卫视,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225488/index.m3u8?fmt=ts2hls
江苏卫视,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225702/index.m3u8
江苏卫视,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225743/index.m3u8
江苏卫视,http://39.135.138.59:18890/PLTV/88888910/224/3221225702/index.m3u8
江苏卫视,http://39.134.115.163:8080/PLTV/88888910/224/3221225702/index.m3u8
江苏卫视,http://39.134.115.163:8080/PLTV/88888910/224/3221225743/index.m3u8
金牌综艺,http://39.134.115.163:8080/PLTV/88888910/224/3221225711/index.m3u8
CCTV兵器科技,rtsp://221.203.83.35/PLTV/88888888/224/3221226704/10000100000000060000000006385167_0.smil?$联通超清1080P
CCTV风云剧场,http://42.176.185.28:9901/tsfile/live/1030_1.m3u8
CCTV风云剧场,http://42.176.185.28:9901/tsfile/live/1030_1.m3u8?$联通超清1080P
CCTV风云剧场,rtsp://221.203.83.35/PLTV/88888888/224/3221226671/10000100000000060000000006385152_0.smil?$联通超清1080P
CCTV风云音乐,http://42.176.185.28:9901/tsfile/live/1024_1.m3u8
CCTV怀旧剧场,rtsp://221.203.83.35/PLTV/88888888/224/3221226700/10000100000000060000000006385151_0.smil?$联通超清1080P
CCTV世界地理,http://42.176.185.28:9901/tsfile/live/1037_1.m3u8?$联通超清1080P
MTV音乐频道,http://pluto-live.plutotv.net/egress/chandler/pluto01/live/VIACBS02/master_2400.m3u8
快乐垂钓HD,http://39.135.55.105:6610/PLTV/88888888/224/3221226940/index.m3u8?servicetype=1
快乐垂钓HD,http://39.135.55.105:6610/PLTV/88888888/224/3221227028/index.m3u8?servicetype=1
快乐垂钓HD,http://39.135.55.7:6610/PLTV/88888888/224/3221227028/index.m3u8?servicetype=1&IASHttpSessionId=OTT
金鹰纪实HD,http://39.135.55.105:6610/PLTV/88888888/224/3221226937/index.m3u8?servicetype=1
金鹰纪实HD,http://39.135.55.105:6610/PLTV/88888888/224/3221226975/index.m3u8?servicetype=1
金鹰纪实HD,http://39.135.55.105:6610/PLTV/88888888/224/3221227018/index.m3u8?servicetype=1
金鹰纪实HD,http://111.20.33.93/PLTV/88888893/224/3221226351/index.m3u8
纪实人文HD,http://39.134.115.163:8080/PLTV/88888910/224/3221225654/index.m3u8
纪实人文HD,http://39.134.115.163:8080/PLTV/88888910/224/3221225655/index.m3u8
纪实人文HD,http://39.135.55.105:6610/PLTV/88888888/224/3221225946/index.m3u8?servicetype=1
纪实人文HD,http://shbu.live.bestvcdn.com.cn:8080/live/program/live/jspdhd/4000000/mnf.m3u8
北京纪实,http://117.148.179.138:80/PLTV/88888888/224/3221233356/1.m3u8
北京纪实,http://39.134.116.30:8080/PLTV/88888910/224/3221225676/index.m3u8
北京纪实,http://39.135.138.59:18890/PLTV/88888888/224/3221225676/index.m3u8
北京纪实4K,http://live.aikan.miguvideo.com/PLTV/88888888/224/3221233353/index.m3u8
北京纪实8K,http://117.148.179.157/PLTV/88888888/224/3221233448/index.m3u8
求索科学HD,http://tv.mushui.tk:9090/itv/gd/utv/play.php?id=qiusuokexueHD_7000
求索科学,http://111.11.123.49:6610/000000001000/6000000002000032344/1.m3u8?Contentid=6000000002000032344&livemode=1&stbId=3&channel-id=wasusyt
求索动物HD,http://tv.mushui.tk:9090/itv/gd/utv/play.php?id=QSDWHD_7000
求索动物,http://111.11.123.49:6610/000000001000/6000000002000010046/1.m3u8?Contentid=6000000002000010046&livemode=1&stbId=3&channel-id=wasusyt
求索生活HD,http://tv.mushui.tk:9090/itv/gd/utv/play.php?id=QSSHHD_7000
求索生活,http://111.11.123.49:6610/000000001000/6000000002000003382/1.m3u8?Contentid=6000000002000003382&livemode=1&stbId=3&channel-id=wasusyt
第一财经HD,http://219.151.139.35/keonline.shanghai.liveplay.qq.com/live/program/live/dycjhd/4000000/mnf.m3u8
黑莓电竞,http://39.134.66.66/PLTV/88888888/224/3221225559/index.m3u8
黑莓电竞,http://39.135.138.60:18890/PLTV/88888910/224/3221225653/index.m3u8
黑莓电竞,http://39.135.55.7:6610/PLTV/88888888/224/3221225894/index.m3u8?servicetype=1&IASHttpSessionId=OTT
黑莓电影,http://39.135.138.60:18890/PLTV/88888910/224/3221225718/index.m3u8
黑莓电影,http://39.135.138.60:18890/PLTV/88888910/224/3221225769/index.m3u8
黑莓电影,http://39.135.55.7:6610/PLTV/88888888/224/3221225891/index.m3u8?servicetype=1&IASHttpSessionId=OTT
黑莓动画,http://39.135.138.60:18890/PLTV/88888910/224/3221225672/index.m3u8
黑莓动画,http://39.135.55.7:6610/PLTV/88888888/224/3221225878/index.m3u8?servicetype=1&IASHttpSessionId=OTT

🏀体育,#genre#
CCTV5,http://39.135.138.59:18890/PLTV/88888910/224/3221225633/index.m3u8
CCTV5,http://39.135.138.60:18890/PLTV/88888910/224/3221225633/index.m3u8
CCTV5,http://39.135.32.24:6610/000000001000/1000000001000004794/index.m3u8?i
CCTV5,http://111.59.189.40:8445/tsfile/live/0113_1.m3u8
CCTV5,http://117.148.179.183/PLTV/88888888/224/3221231702/index.m3u8
CCTV5,http://39.134.115.163:8080/PLTV/88888910/224/3221225633/index.m3u8
CCTV5,http://39.135.138.59:18890/PLTV/88888888/224/3221225767/index.m3u8
CCTV5,http://live.aikan.miguvideo.com/PLTV/88888888/224/3221233115/index.m3u8
CCTV5,http://117.148.179.165/PLTV/88888888/224/3221231702/index.m3u8
CCTV5+,http://111.59.189.40:8445/tsfile/live/1018_1.m3u8
CCTV5+,http://117.148.179.183/PLTV/88888888/224/3221231459/index.m3u8
CCTV5+,http://39.134.115.163:8080/PLTV/88888910/224/3221225706/index.m3u8
CCTV5+,http://39.135.138.59:18890/PLTV/88888888/224/3221225706/index.m3u8
CCTV5+,http://live.aikan.miguvideo.com/PLTV/88888888/224/3221233107/index.m3u8
CCTV5+,http://117.148.179.136/PLTV/88888888/224/3221231459/index.m3u8
CCTV5+,http://39.135.138.60:18890/PLTV/88888910/224/3221225649/index.m3u8
CCTV5+,http://39.135.138.59:18890/PLTV/88888910/224/3221225649/index.m3u8
CCTV16,http://liveop.cctv.cn/hls/CCTV16HD/playlist.m3u8
CCTV16,http://39.135.138.60:18890/TVOD/88888910/224/3221226230/index.m3u8
CCTV16,http://112.25.47.24/gitv_live/G_CCTV-16-CQ/G_CCTV-16-CQ.m3u8
CCTV16,http://39.134.116.30:8080/PLTV/88888888/224/3221226230/index.m3u8
CCTV16,http://39.135.138.59:18890/PLTV/88888888/224/3221226233/index.m3u8
CCTV16,http://live.aikan.miguvideo.com/PLTV/88888888/224/3221233392/index.m3u8
PP体育,http://117.148.179.172/PLTV/88888888/224/3221231778/index.m3u8
劲爆体育,http://219.151.139.35/keonline.shanghai.liveplay.qq.com/live/program/live/jbtyhd/4000000/mnf.m3u8
劲爆体育,http://36.142.6.143/liveplay-kk.rtxapp.com/live/program/live/jbtyhd/4000000/mnf.m3u8
劲爆体育,http://139.215.233.152/liveplay-kk.rtxapp.com/live/program/live/ssty/4000000/mnf.m3u8
劲爆体育,http://shbu.live.bestvcdn.com.cn:8080/live/program/live/jbtyhd/2300000/mnf.m3u8
新视觉,http://183.207.255.188/live/program/live/xsjhd/4000000/mnf.m3u8
五星体育,http://111.40.196.25/PLTV/88888888/224/3221225503/index.m3u8
五星体育,http://219.151.139.35/keonline.shanghai.liveplay.qq.com/live/program/live/ssty/4000000/mnf.m3u8
五星体育,http://36.142.6.143/liveplay-kk.rtxapp.com/live/program/live/ssty/4000000/mnf.m3u8
广东体育,http://tv.mushui.tk:9090/maotv/808jxx/tv.php?id=1
广东体育,http://tv.mushui.tk:9090/maotv/808xyz/tv.php?id=18
广东体育,http://tv.mushui.tk:9090/itv/gd/utv/play.php?id=gdsportsHD_7000
ESPN,https://demf1kf3itpt4.cloudfront.net/hls/espn/chunks.m3u8
TNT,https://demf1kf3itpt4.cloudfront.net/hls/TNT/chunks.m3u8
NBATV,https://demf1kf3itpt4.cloudfront.net/hls/nbatv/chunks.m3u8
ABC,https://demf1kf3itpt4.cloudfront.net/hls/abc/chunks.m3u8
TSN,https://demf1kf3itpt4.cloudfront.net/hls/tsn/chunks.m3u8
魅力足球,http://183.207.255.188/live/program/live/mlyyhd/4000000/mnf.m3u8
魅力足球,http://tv.mushui.tk:9090/maotv/808xyz/tv.php?id=50
魅力足球,http://shbu.live.bestvcdn.com.cn:8080/live/program/live/mlyyhd/2300000/mnf.m3u8
超级体育,http://39.134.115.163:8080/PLTV/88888910/224/3221225622/index.m3u8
哒啵赛事1,http://39.135.55.105:6610/PLTV/88888888/224/3221225894/index.m3u8?servicetype=1
哒啵赛事2,http://39.135.55.105:6610/PLTV/88888888/224/3221226676/index.m3u8?servicetype=1
哒啵赛事3,http://39.135.55.105:6610/PLTV/88888888/224/3221226680/index.m3u8?servicetype=1
咪咕1,http://39.135.134.67/000000001000/3000000001000028638/index.m3u8
咪咕2,http://39.135.134.67/000000001000/3000000001000008379/index.m3u8
咪咕3,http://39.135.134.67/000000001000/3000000001000008001/index.m3u8
咪咕4,http://39.135.134.67/000000001000/3000000001000031494/index.m3u8
咪咕5,http://39.135.134.67/000000001000/3000000001000008176/index.m3u8
咪咕6,http://39.135.134.34/000000001000/3000000001000010129/index.m3u8
咪咕7,http://39.135.134.67/000000001000/3000000001000010948/index.m3u8
咪咕8,http://39.135.134.67/000000001000/3000000001000007218/index.m3u8
咪咕9,http://39.135.134.67/000000001000/3000000001000005308/index.m3u8
咪咕10,http://39.135.134.67/000000001000/3000000001000005969/index.m3u8
咪咕11,http://39.135.134.67/000000001000/3000000001000026778/index.m3u8
咪咕12,http://39.135.137.203/000000001000/3000000010000027691/index.m3u8
咪咕13,http://39.135.137.203/000000001000/3000000010000015560/index.m3u8
咪咕14,http://39.135.137.205/000000001000/3000000010000002809/index.m3u8
咪咕15,http://39.135.137.206/000000001000/3000000010000000097/index.m3u8
咪咕16,http://39.135.137.205/000000001000/3000000010000006077/index.m3u8
咪咕17,http://39.135.137.203/000000001000/3000000010000012558/index.m3u8
咪咕18,http://39.135.137.208/000000001000/3000000010000023434/index.m3u8
咪咕19,http://39.135.137.203/000000001000/3000000010000003915/index.m3u8
咪咕20,http://39.135.137.205/000000001000/3000000010000004193/index.m3u8
咪咕21,http://39.135.137.205/000000001000/3000000010000021904/index.m3u8
咪咕22,http://39.135.137.207/000000001000/3000000010000011297/index.m3u8
咪咕23,http://39.135.137.208/000000001000/3000000010000006658/index.m3u8
咪咕24,http://39.135.137.205/000000001000/3000000010000010833/index.m3u8
咪咕25,http://39.135.137.203/000000001000/3000000010000025380/index.m3u8
咪咕26,http://39.135.137.209/000000001000/3000000010000015686/index.m3u8
咪咕27,http://39.135.137.208/000000001000/3000000010000005180/index.m3u8
咪咕28,http://39.135.55.105:6610/PLTV/88888888/224/3221226564/index.m3u8?servicetype=1
咪咕29,http://39.135.55.105:6610/PLTV/88888888/224/3221226565/index.m3u8?servicetype=1
咪咕30,http://39.135.55.105:6610/PLTV/88888888/224/3221226568/index.m3u8?servicetype=1
咪咕31,http://39.135.55.105:6610/PLTV/88888888/224/3221226569/index.m3u8?servicetype=1
咪咕32,http://39.135.55.105:6610/PLTV/88888888/224/3221226573/index.m3u8?servicetype=1
咪咕33,http://39.135.55.105:6610/PLTV/88888888/224/3221226638/index.m3u8?servicetype=1
咪咕34,http://39.135.55.105:6610/PLTV/88888888/224/3221226642/index.m3u8?servicetype=1
咪咕35,http://39.135.55.105:6610/PLTV/88888888/224/3221226646/index.m3u8?servicetype=1
咪咕36,http://39.135.55.105:6610/PLTV/88888888/224/3221227047/index.m3u8?servicetype=1
咪咕37,http://39.135.55.105:6610/PLTV/88888888/224/3221227107/index.m3u8?servicetype=1
咪咕38,http://39.135.55.105:6610/PLTV/88888888/224/3221227158/index.m3u8?servicetype=1
咪咕39,http://39.135.55.105:6610/PLTV/88888888/224/3221227189/index.m3u8?servicetype=1
咪咕40,http://39.135.55.105:6610/PLTV/88888888/224/3221227228/index.m3u8?servicetype=1
快乐垂钓,http://39.135.55.105:6610/PLTV/88888888/224/3221226940/index.m3u8?servicetype=1
快乐垂钓,http://39.135.55.105:6610/PLTV/88888888/224/3221227028/index.m3u8?servicetype=1
快乐垂钓,http://39.135.55.7:6610/PLTV/88888888/224/3221227028/index.m3u8?servicetype=1&IASHttpSessionId=OTT
四海钓鱼,http://117.148.179.159/PLTV/88888888/224/3221231718/index.m3u8
风尚运动,http://211.94.219.178:18080/PLTV/68/224/3221226429/index.m3u8
游戏风云,http://111.20.41.242/dbiptv.sn.chinamobile.com/PLTV/88888888/224/3221226579/1.m3u8?from=everydaytv4.2
杭州体育,http://live.aikan.miguvideo.com/PLTV/88888888/224/3221229316/index.m3u8
杭州体育,http://hms363nc1880172761.live.aikan.miguvideo.com/wh7f454c46tw2880854862_-704780469/PLTV/88888888/224/3221229316/index.m3u8
杭州体育,http://live.aikan.miguvideo.com/PLTV/88888888/224/3221229316/index.m3u8
福建文体,http://39.135.55.105:6610/PLTV/88888888/224/3221227188/index.m3u8?servicetype=1
游戏风云,http://183.207.255.188/live/program/live/yxfyhd/4000000/mnf.m3u8
游戏风云,http://shbu.live.bestvcdn.com.cn:8080/live/program/live/yxfyhd/4000000/mnf.m3u8
智林体育,http://58.99.33.16:1935/liveedge17/live_122_3.stream/chunklist.m3u8
体育彩票,http://117.148.179.183/PLTV/88888888/224/3221231730/index.m3u8
精彩体育,http://111.20.41.252/dbiptv.sn.chinamobile.com/PLTV/88888888/224/3221226010/1.m3u8?from=everydaytv4.2
冬奥纪实,http://39.135.138.60:18890/PLTV/88888910/224/3221225676/index.m3u8
冬奥纪实,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225675/index.m3u8
冬奥纪实,http://39.134.115.163:8080/PLTV/88888910/224/3221225676/index.m3u8

👍4K,#genre#
冬奥纪实4K,http://117.148.179.157/PLTV/88888888/224/3221233401/index.m3u8
冬奥纪实8K,http://117.148.179.157/PLTV/88888888/224/3221233395/index.m3u8
冬奥纪实8K,http://117.148.179.157/PLTV/88888888/224/3221233448/index.m3u8
CCTV4K F,http://liveop.cctv.cn/hls/4KHD/playlist.m3u8
CCTV4K U,http://open.live-web.timetv.cn/live03/cctv4k.m3u8
CCTV4K,http://39.135.55.7:6610/PLTV/88888888/224/3221226998/index.m3u8?servicetype=1&IASHttpSessionId=OTT
CCTV4K,http://39.135.55.7:6610/PLTV/88888888/224/3221226998/index.m3u8?servicetype=1&IASHttpSessionId=OTT
CCTV4K,http://117.148.179.157/PLTV/88888888/224/3221233460/index.m3u8
CCTV4K,http://ye23.win/iptv/4k.cctv.php
CCTV4K,http://39.135.55.105:6610/PLTV/88888888/224/3221226998/index.m3u8?servicetype=1
CCTV4K,http://39.135.55.7:6610/PLTV/88888888/224/3221226998/everydaylive_cctv4k.m3u8?servicetype=1&from=everydaytv4.2
CCTV4K,http://liveop.cctv.cn/hls/4KHD/playlist.m3u8
CCTV8K,http://117.148.179.148:80/PLTV/88888888/224/3221233350/1.m3u8
CCTV8K,http://live.aikan.miguvideo.com/PLTV/88888888/224/3221233350/index.m3u8
CCTV-8K,http://117.148.179.157/PLTV/88888888/224/3221233350/index.m3u8
CCTV-8K,http://117.148.179.157/PLTV/88888888/224/3221233413/index.m3u8
CCTV-8K,http://117.148.179.157/PLTV/88888888/224/3221233439/index.m3u8
CCTV-8K,http://117.148.179.157/PLTV/88888888/224/3221233457/index.m3u8
CCTV-8K,http://117.148.179.157/PLTV/88888888/224/3221233350/index.m3u8?from=everydaytv4.2
CCTV-8K,http://117.148.179.146/PLTV/88888888/224/3221233413/index.m3u8
纯享4K,http://39.134.115.163:8080/PLTV/88888910/224/3221225786/index.m3u8
纯享4K,http://39.135.138.60:18890/PLTV/88888910/224/3221225786/index.m3u8
纯享4K,http://39.135.55.7:6610/PLTV/88888888/224/3221226825/index.m3u8?servicetype=1&IASHttpSessionId=OTT
纯享4k,http://39.135.32.6:6610/PLTV/77777777/224/3221225726/index.m3u8?servicetype=1&IASHttpSessionId=OTT
纯享4k,http://39.135.32.10:6610/000000001000/HD-20M-2160P-chunxiang4k/1.m3u8?IASHttpSessionId=OTT
纯享4k,http://39.135.138.58:18890/PLTV/88888888/224/3221225786/index.m3u8
纯享4k,http://39.134.115.163:8080/PLTV/88888910/224/3221225786/index.m3u8?
纯享4K,http://39.135.55.105:6610/PLTV/88888888/224/3221226825/index.m3u8?servicetype=1
爱上4K,http://111.20.33.93/TVOD/88888893/224/3221226352/index.m3u8
爱上4K,http://39.134.18.82/dbiptv.sn.chinamobile.com/PLTV/88888890/224/3221226352/index.m3u8
爱上4k,http://111.20.41.242/dbiptv.sn.chinamobile.com/PLTV/88888888/224/3221226352/1.m3u8
爱上4k,http://111.20.33.93/PLTV/88888893/224/3221226352/index.m3u8
爱上4K,http://39.134.19.252:6610/yinhe/2/ch00000090990000001709/index.m3u8?virtualDomain=yinhe.live_hls.zte.com
爱上4K,http://39.134.18.82/dbiptv.sn.chinamobile.com/PLTV/88888890/224/3221226352/index.m3u8
爱上4K,http://39.134.18.82/dbiptv.sn.chinamobile.com/PLTV/88888888/224/3221226352/1.m3u8$陕西移动4K
欢笑剧场4k,http://183.207.255.188/live/program/live/hxjchd/4000000/mnf.m3u8
芒果TV4K,http://39.135.55.105:6610/PLTV/88888888/224/3221226887/index.m3u8?servicetype=1
苏州4k,http://liveshowbak2.kan0512.com/ksz-norecord/csztv4k_4k.m3u8

💖央视,#genre#
CCTV-1,http://39.134.19.252:6610/yinhe/2/ch00000090990000001971/index.m3u8?virtualDomain=yinhe.live_hls.zte.com$
CCTV-1,http://39.134.65.141/PLTV/88888888/224/3221225816/1.m3u8
CCTV-1,http://39.134.65.143/PLTV/88888888/224/3221225816/1.m3u8
CCTV-1,http://39.134.65.151/PLTV/88888888/224/3221225816/1.m3u8
CCTV-1,http://39.135.138.58:18890/PLTV/88888888/224/3221225618/index.m3u8
CCTV-1,http://39.135.138.58:18890/PLTV/88888888/224/3221225762/index.m3u8
CCTV-1,http://39.135.138.58:18890/PLTV/88888888/224/3221226221/index.m3u8
CCTV-1,http://39.135.138.58:18890/PLTV/88888888/224/3221226225/index.m3u8
CCTV-1,http://117.148.179.155/PLTV/88888888/224/3221231468/index.m3u8
CCTV-1,http://117.169.120.142:8080/live/cctv-1/1.m3u8
CCTV-1,http://39.135.55.105:6610/PLTV/88888888/224/3221226995/index.m3u8?servicetype=1
CCTV-1,http://39.135.55.7:6610/PLTV/88888888/224/3221225829/index.m3u8?servicetype=1&IASHttpSessionId=OTT
CCTV-1,http://39.135.55.7:6610/PLTV/88888888/224/3221225922/index.m3u8?servicetype=1&IASHttpSessionId=OTT
CCTV-1,http://39.135.55.7:6610/PLTV/88888888/224/3221226908/index.m3u8?servicetype=1&IASHttpSessionId=OTT
CCTV-2,http://39.134.18.82/dbiptv.sn.chinamobile.com/PLTV/88888890/224/3221226195/index.m3u8
CCTV-2,http://39.135.138.58:18890/PLTV/88888888/224/3221225619/index.m3u8
CCTV-2,http://39.135.55.105:6610/PLTV/88888888/224/3221226915/index.m3u8?servicetype=1
CCTV-2,http://39.136.48.53:8089/PLTV/88888888/224/3221225751/index.m3u8
CCTV-2,http://117.169.120.142:8080/live/cctv-2/1.m3u8
CCTV-3,http://111.63.117.13:6060/030000001000/CCTV-3/CCTV-3.m3u8
CCTV-3,http://112.25.47.24/gitv_live/G_CCTV-3-HD-265-8M/G_CCTV-3-HD-265-8M.m3u8?p=GITV&area=JS_CMCC_CP
CCTV-3,http://112.25.47.24/gitv_live/G_CCTV-3-MD/G_CCTV-3-MD.m3u8?p=GITV&area=JS_CMCC_CP
CCTV-3,http://117.148.179.183/TVOD/88888888/224/3221231682/index.m3u8
CCTV-3,http://111.63.117.13:6060/030000001000/CCTV-3/CCTV-3.m3u8
CCTV-3,http://39.135.55.105:6610/PLTV/88888888/224/3221227055/index.m3u8?servicetype=1
CCTV-3,http://117.148.179.183/PLTV/88888888/224/3221231682/index.m3u8
CCTV-3,http://117.169.120.142:8080/live/cctv-3/1.m3u8
CCTV-3,http://39.134.115.163:8080/PLTV/88888910/224/3221225634/index.m3u8
CCTV-3,http://39.134.115.163:8080/PLTV/88888910/224/3221225647/index.m3u8
CCTV-3,http://39.134.18.82/dbiptv.sn.chinamobile.com/PLTV/88888890/224/3221226397/index.m3u8
CCTV-3,http://39.134.65.141/PLTV/88888888/224/3221225799/1.m3u8
CCTV-3,http://39.135.138.58:18890/PLTV/88888888/224/3221225634/index.m3u8
CCTV-3,http://39.135.138.60:18890/PLTV/88888910/224/3221225634/index.m3u8
CCTV-3,http://39.135.138.60:18890/PLTV/88888910/224/3221225647/index.m3u8
CCTV-3,http://39.135.55.105:6610/PLTV/88888888/224/3221227055/index.m3u8?servicetype=1
CCTV-4,http://39.134.115.163:8080/PLTV/88888910/224/3221225621/index.m3u8
CCTV-4,http://39.134.18.82/dbiptv.sn.chinamobile.com/PLTV/88888890/224/3221226191/index.m3u8
CCTV-4,http://39.135.55.105:6610/PLTV/88888888/224/3221226968/index.m3u8?servicetype=1
CCTV-4,http://39.135.55.7:6610/PLTV/88888888/224/3221226968/index.m3u8?servicetype=1&IASHttpSessionId=OTT
CCTV-4,http://39.136.48.53:8089/PLTV/88888888/224/3221225757/index.m3u8
CCTV-5,http://111.63.117.13:6060/030000001000/CCTV-5/CCTV-5.m3u8
CCTV-4,http://117.148.179.182:80/PLTV/88888888/224/3221231726/index.m3u8
CCTV-4,http://117.169.120.142:8080/live/cctv-4/1.m3u8
CCTV-5,http://39.135.138.59:18890/TVOD/88888910/224/3221225633/index.m3u8
CCTV-5,http://39.134.19.252:6610/yinhe/2/ch00000090990000001850/index.m3u8?virtualDomain=yinhe.live_hls.zte.com$
CCTV-5,http://39.135.55.105:6610/PLTV/88888888/224/3221227170/index.m3u8?servicetype=1
CCTV-5,http://39.136.48.4:8089/PLTV/88888888/224/3221226425/index.m3u8
CCTV-5+,http://111.63.117.13:6060/030000001000/G_CCTV-5PLUS/G_CCTV-5PLUS.m3u8
CCTV-5+,http://39.135.138.59:18890/TVOD/88888910/224/3221225706/index.m3u8
CCTV-5+,http://39.134.18.82/dbiptv.sn.chinamobile.com/PLTV/88888890/224/3221226221/index.m3u8
CCTV-5+,http://39.135.55.105:6610/PLTV/88888888/224/3221225821/index.m3u8?servicetype=1
CCTV-5+,http://39.135.138.60:18890/PLTV/88888910/224/3221225706/index.m3u8
CCTV-5+,http://39.136.48.53:8089/PLTV/88888888/224/3221225781/index.m3u8
CCTV-5+,http://111.63.117.13:6060/030000001000/G_CCTV-5PLUS/G_CCTV-5PLUS.m3u8
CCTV-6,http://219.151.31.38/liveplay-kk.rtxapp.com/live/program/live/cctv6hd/4000000/mnf.m3u8
CCTV-6,http://39.134.115.163:8080/PLTV/88888910/224/3221225632/index.m3u8
CCTV-6,http://39.134.18.82/dbiptv.sn.chinamobile.com/PLTV/88888890/224/3221226393/index.m3u8
CCTV-6,http://39.134.19.252:6610/yinhe/2/ch00000090990000001859/index.m3u8?virtualDomain=yinhe.live_hls.zte.com$
CCTV-6,http://39.135.138.59:18890/PLTV/88888910/224/3221225650/index.m3u8
CCTV-6,http://39.135.138.60:18890/PLTV/88888910/224/3221225632/index.m3u8
CCTV-6,http://117.148.179.153/PLTV/88888888/224/3221231724/index.m3u8
CCTV-6,http://117.169.120.142:8080/live/cctv-6/1.m3u8
CCTV-6,http://117.148.179.153/TVOD/88888888/224/3221231724/index.m3u8
CCTV-6,http://39.135.55.105:6610/PLTV/88888888/224/3221227137/index.m3u8?servicetype=1
CCTV-7,http://117.148.179.160/TVOD/88888888/224/3221231633/index.m3u8
CCTV-7,http://117.148.179.160/PLTV/88888888/224/3221231633/index.m3u8
CCTV-7,http://117.148.179.160:80/PLTV/88888888/224/3221231633/index.m3u8
CCTV-7,http://117.169.120.142:8080/live/cctv-7/1.m3u8
CCTV-7,http://39.134.115.163:8080/PLTV/88888910/224/3221225624/index.m3u8
CCTV-7,http://39.134.115.163:8080/PLTV/88888910/224/3221225644/index.m3u8
CCTV-7,http://39.134.18.82/dbiptv.sn.chinamobile.com/PLTV/88888890/224/3221226192/index.m3u8
CCTV-7,http://39.134.67.6:80/ottrrs.hl.chinamobile.com/PLTV/88888888/224/3221225733/1.m3u8
CCTV-7,http://39.135.138.59:18890/PLTV/88888910/224/3221225644/index.m3u8
CCTV-7,http://39.135.138.60:18890/PLTV/88888910/224/3221225624/index.m3u8
CCTV-7,http://39.135.55.105:6610/PLTV/88888888/224/3221226972/index.m3u8?servicetype=1
CCTV-7,http://39.136.48.53:8089/PLTV/88888888/224/3221225753/index.m3u8
CCTV-8,http://117.148.179.160/TVOD/88888888/224/3221231694/index.m3u8
CCTV-8,http://111.20.41.248/dbiptv.sn.chinamobile.com/PLTV/88888888/224/3221226391/1.m3u8
CCTV-8,http://117.148.179.160/PLTV/88888888/224/3221231694/index.m3u8
CCTV-8,http://117.169.120.142:8080/live/cctv-8/1.m3u8
CCTV-8,http://39.134.115.163:8080/PLTV/88888910/224/3221225631/index.m3u8
CCTV-8,http://39.134.115.163:8080/PLTV/88888910/224/3221225635/index.m3u8
CCTV-8,http://39.134.19.252:6610/yinhe/2/ch00000090990000001869/index.m3u8?virtualDomain=yinhe.live_hls.zte.com$
CCTV-8,http://39.135.138.59:18890/PLTV/88888910/224/3221225631/index.m3u8
CCTV-8,http://39.135.138.60:18890/PLTV/88888910/224/3221225631/index.m3u8
CCTV-8,http://39.135.138.60:18890/PLTV/88888910/224/3221225635/index.m3u8
CCTV-8,http://39.135.55.105:6610/PLTV/88888888/224/3221227174/index.m3u8?servicetype=1
CCTV-9,http://39.134.115.163:8080/PLTV/88888910/224/3221225626/index.m3u8
CCTV-9,http://39.134.115.163:8080/PLTV/88888910/224/3221225646/index.m3u8
CCTV-9,http://39.134.18.82/dbiptv.sn.chinamobile.com/PLTV/88888890/224/3221226197/index.m3u8
CCTV-9,http://39.135.138.59:18890/PLTV/88888910/224/3221225626/index.m3u8
CCTV-9,http://39.135.138.60:18890/PLTV/88888910/224/3221225626/index.m3u8
CCTV-9,http://39.135.138.60:18890/PLTV/88888910/224/3221225646/index.m3u8
CCTV-9,http://39.135.55.105:6610/PLTV/88888888/224/3221225929/index.m3u8?servicetype=1
CCTV-9,http://117.148.179.162/TVOD/88888888/224/3221231697/index.m3u8
CCTV-9,http://117.148.179.162/PLTV/88888888/224/3221231697/index.m3u8
CCTV-9,http://117.148.179.162:80/PLTV/88888888/224/3221231697/index.m3u8
CCTV-9,http://117.169.120.142:8080/live/cctv-news/1.m3u8
CCTV-9,http://222.132.191.125:9901/tsfile/live/0009_1.m3u8
CCTV-9,http://39.136.48.53:8089/PLTV/88888888/224/3221225759/index.m3u8
CCTV-10,http://222.132.191.125:9901/tsfile/live/0002_1.m3u8
CCTV-10,http://39.134.115.163:8080/PLTV/88888910/224/3221225627/index.m3u8
CCTV-10,http://39.134.115.163:8080/PLTV/88888910/224/3221225636/index.m3u8
CCTV-10,http://39.134.18.82/dbiptv.sn.chinamobile.com/PLTV/88888890/224/3221226189/index.m3u8
CCTV-10,http://39.134.66.66/PLTV/88888888/224/3221225677/index.m3u8
CCTV-10,http://39.135.138.59:18890/PLTV/88888910/224/3221225627/index.m3u8
CCTV-10,http://39.135.138.60:18890/PLTV/88888910/224/3221225636/index.m3u8
CCTV-10,http://39.135.55.105:6610/PLTV/88888888/224/3221226976/index.m3u8?servicetype=1
CCTV-10,http://39.136.48.53:8089/PLTV/88888888/224/3221225761/index.m3u8
CCTV-10,http://117.148.179.175/TVOD/88888888/224/3221231666/index.m3u8
CCTV-10,http://117.148.179.137:80/PLTV/88888888/224/3221231666/1.m3u8
CCTV-10,http://117.148.179.175:80/PLTV/88888888/224/3221231666/index.m3u8
CCTV-10,http://117.169.120.142:8080/live/cctv-10/1.m3u8
CCTV-11,http://39.134.115.163:8080/PLTV/88888910/224/3221225628/index.m3u8
CCTV-11,http://39.135.138.58:18890/PLTV/88888888/224/3221225628/index.m3u8
CCTV-11,http://39.135.138.59:18890/PLTV/88888910/224/3221225628/index.m3u8
CCTV-11,http://39.135.138.60:18890/PLTV/88888910/224/3221225628/index.m3u8
CCTV-11,http://39.135.55.105:6610/PLTV/88888888/224/3221226927/index.m3u8?servicetype=1
CCTV-11,http://117.148.179.164/TVOD/88888888/224/3221231711/index.m3u8
CCTV-11,http://117.148.179.163:80/PLTV/88888888/224/3221231711/1.m3u8
CCTV-11,http://117.169.120.142:8080/live/cctv-11/1.m3u8
CCTV-12,http://39.134.115.163:8080/PLTV/88888910/224/3221225629/index.m3u8
CCTV-12,http://39.134.115.163:8080/PLTV/88888910/224/3221225637/index.m3u8
CCTV-12,http://39.135.138.59:18890/PLTV/88888910/224/3221225629/index.m3u8
CCTV-12,http://39.135.138.60:18890/PLTV/88888910/224/3221225637/index.m3u8
CCTV-12,http://39.135.55.105:6610/PLTV/88888888/224/3221226931/index.m3u8?servicetype=1
CCTV-12,http://39.136.48.53:8089/PLTV/88888888/224/3221225763/index.m3u8
CCTV-12,http://117.148.179.150/TVOD/88888888/224/3221231660/index.m3u8
CCTV-12,http://39.135.49.209:6610/PLTV/88888888/224/3221225932/1.m3u8?servicetype=1
CCTV-12,http://117.148.179.150/PLTV/88888888/224/3221231660/index.m3u8
CCTV-12,http://117.148.179.150:80/PLTV/88888888/224/3221231660/index.m3u8
CCTV-12,http://117.169.120.142:8080/live/cctv-12/1.m3u8
CCTV-12,http://222.132.191.125:9901/tsfile/live/0007_1.m3u8
CCTV-13,http://39.135.55.105:6610/PLTV/88888888/224/3221225817/index.m3u8?servicetype=1
CCTV-13,http://39.135.55.105:6610/PLTV/88888888/224/3221225817/index.m3u8?servicetype=1
CCTV-13,http://39.135.55.105:6610/PLTV/88888888/224/3221226985/index.m3u8?servicetype=1
CCTV-13,http://39.136.48.4:8089/PLTV/88888888/224/3221226328/index.m3u8
CCTV-13,http://39.136.48.53:8089/PLTV/88888888/224/3221226328/index.m3u8
CCTV-14,http://117.148.179.182/TVOD/88888888/224/3221231648/index.m3u8
CCTV-14,http://39.135.49.209:6610/PLTV/88888888/224/3221227086/1.m3u8?servicetype=1
CCTV-14,http://111.59.189.40:8445/tsfile/live/1012_1.m3u8
CCTV-14,http://39.135.55.105:6610/PLTV/88888888/224/3221225819/index.m3u8?servicetype=1
CCTV-14,http://117.148.179.182/PLTV/88888888/224/3221231648/index.m3u8
CCTV-14,http://117.169.120.142:8080/live/cctv-14/1.m3u8
CCTV-14,http://222.132.191.125:9901/tsfile/live/0010_1.m3u8
CCTV-14,http://39.134.115.163:8080/PLTV/88888910/224/3221225639/index.m3u8
CCTV-14,http://39.134.115.163:8080/PLTV/88888910/224/3221225640/index.m3u8
CCTV-14,http://39.134.66.66/PLTV/88888888/224/3221225674/index.m3u8
CCTV-14,http://39.134.67.6:80/ottrrs.hl.chinamobile.com/PLTV/88888888/224/3221225732/1.m3u8
CCTV-14,http://39.135.138.59:18890/PLTV/88888910/224/3221225640/index.m3u8
CCTV-14,http://39.135.138.60:18890/PLTV/88888910/224/3221225639/index.m3u8
CCTV-14,http://39.136.48.53:8089/PLTV/88888888/224/3221225765/index.m3u8
CCTV-15,http://117.148.179.169/TVOD/88888888/224/3221231693/index.m3u8
CCTV-15,http://117.148.179.169/PLTV/88888888/224/3221231693/index.m3u8
CCTV-15,http://117.148.179.169:80/PLTV/88888888/224/3221231693/1.m3u8
CCTV-15,http://117.148.179.169:80/PLTV/88888888/224/3221231693/index.m3u8
CCTV-15,http://117.169.120.142:8080/live/cctv-15/1.m3u8
CCTV-15,http://39.134.115.163:8080/PLTV/88888910/224/3221225641/index.m3u8
CCTV-15,http://39.135.138.58:18890/PLTV/88888910/224/3221225641/index.m3u8
CCTV-15,http://39.135.138.60:18890/PLTV/88888910/224/3221225641/index.m3u8
CCTV-15,http://39.135.55.105:6610/PLTV/88888888/224/3221226989/index.m3u8?servicetype=1
CCTV-15,http://39.135.55.7:6610/PLTV/88888888/224/3221225818/index.m3u8?servicetype=1&IASHttpSessionId=OTT
CCTV-16,http://117.148.179.157/PLTV/88888888/224/3221233392/index.m3u8
CCTV-16,http://117.148.179.157/PLTV/88888888/224/3221233403/index.m3u8
CCTV-16,http://39.134.18.82/dbiptv.sn.chinamobile.com/PLTV/88888890/224/3221226921/index.m3u8
CCTV-16,http://39.135.138.60:18890/TVOD/88888910/224/3221226230/index.m3u8
CCTV-16,http://39.135.55.7:6610/PLTV/88888888/224/3221227148/index.m3u8?servicetype=1&IASHttpSessionId=OTT
CCTV-16,http://liveop.cctv.cn/hls/CCTV16HD/playlist.m3u8
CCTV-17,http://112.25.47.24/gitv_live/G_CCTV-17-HD/G_CCTV-17-HD.m3u8
CCTV-17,http://117.148.179.167/TVOD/88888888/224/3221231772/index.m3u8
CCTV-17,http://117.148.179.167/PLTV/88888888/224/3221231772/index.m3u8
CCTV-17,http://117.148.179.167:80/PLTV/88888888/224/3221231772/index.m3u8
CCTV-17,http://39.134.115.163:8080/PLTV/88888910/224/3221225908/index.m3u8
CCTV-17,http://39.134.66.110/PLTV/88888888/224/3221225708/index.m3u8
CCTV-17,http://39.135.138.60:18890/PLTV/88888910/224/3221225908/index.m3u8
CCTV-17,http://39.135.55.105:6610/PLTV/88888888/224/3221226986/index.m3u8?servicetype=1
CCTV-17,http://39.136.48.53:8089/PLTV/88888888/224/3221226093/index.m3u8
CETV-1,http://39.135.55.105:6610/PLTV/88888888/224/3221227067/index.m3u8?servicetype=1
CETV-1,http://117.148.179.156/PLTV/88888888/224/3221231714/index.m3u8?$咪咕移动1080P
CETV-1,http://117.148.179.160/PLTV/88888888/224/3221231714/index.m3u8
CETV-1,http://39.135.55.7:6610/PLTV/88888888/224/3221227067/index.m3u8?servicetype=1$移动超清1080P
CETV-1,http://39.136.48.106:8089/PLTV/88888888/224/3221226252/index.m3u8?$移动超清1080P
CETV-1,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225917/index.m3u8?fmt=ts2hls?$移动超清1080P
CETV-1,http://39.135.55.7:6610/PLTV/88888888/224/3221227067/everydaylive_cetv1.m3u8?servicetype=1&from=everydaytv4.2
CETV-1,http://117.148.179.156/PLTV/88888888/224/3221231714/index.m3u8
CETV-1,http://111.59.63.32:9901/tsfile/live/1024_1.m3u8
CETV-2,http://117.148.179.162/PLTV/88888888/224/3221231607/index.m3u8
CETV-2,http://111.63.117.13:6060/030000001000/G_CETV-2/G_CETV-2.m3u8
CETV-3,http://117.148.179.136/PLTV/88888888/224/3221231543/index.m3u8
CETV-4,http://117.148.179.155/PLTV/88888888/224/3221231613/index.m3u8
CETV-4,http://111.63.117.13:6060/030000001000/G_CETV-4/G_CETV-4.m3u8

💟卫视,#genre#
湖南卫视,http://39.135.55.105:6610/PLTV/88888888/224/3221227232/index.m3u8?servicetype=1
湖南卫视,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225490/index.m3u8?fmt=ts2hls
湖南卫视,http://39.136.48.18:8089/PLTV/88888888/224/3221225767/index.m3u8
湖南卫视,http://39.136.48.2:8089/PLTV/88888888/224/3221225767/index.m3u8
湖南卫视,http://39.136.48.5:8089/PLTV/88888888/224/3221225767/index.m3u8
湖南卫视,http://39.135.138.60:18890/PLTV/88888910/224/3221225745/index.m3u8
湖南卫视,http://117.148.179.135/TVOD/88888888/224/3221230206/index.m3u8
湖南卫视,http://117.148.179.148/TVOD/88888888/224/3221230824/index.m3u8
湖南卫视,http://117.148.179.172/TVOD/88888888/224/3221231729/index.m3u8
湖南卫视,http://39.135.138.59:18890/TVOD/88888910/224/3221225704/index.m3u8
湖南卫视,http://39.134.18.82/dbiptv.sn.chinamobile.com/PLTV/88888890/224/3221225799/index.m3u8
湖南卫视,http://39.134.65.208/PLTV/88888888/224/3221225506/index.m3u8
湖南卫视,http://39.134.65.162/PLTV/88888888/224/3221225506/index.m3u8
湖南卫视,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225490/index.m3u8?fmt=ts2hls
东方卫视,http://39.135.55.105:6610/PLTV/88888888/224/3221226603/index.m3u8?servicetype=1
东方卫视,http://39.135.55.105:6610/PLTV/88888888/224/3221227059/index.m3u8?servicetype=1
东方卫视,http://39.135.55.105:6610/PLTV/88888888/224/3221226895/index.m3u8?servicetype=1
东方卫视,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225489/index.m3u8?fmt=ts2hls
东方卫视,http://39.135.138.60:18890/PLTV/88888910/224/3221225658/index.m3u8
东方卫视,http://39.134.115.163:8080/PLTV/88888910/224/3221225658/index.m3u8
东方卫视,http://39.134.18.82/dbiptv.sn.chinamobile.com/PLTV/88888890/224/3221225798/index.m3u8
东方卫视,http://39.134.115.163:8080/PLTV/88888910/224/3221225744/index.m3u8
东方卫视,http://219.151.31.38/liveplay-kk.rtxapp.com/live/program/live/hddfws/4000000/mnf.m3u8
东方卫视,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225658/index.m3u8
东方卫视,http://39.134.65.208/PLTV/88888888/224/3221225672/index.m3u8
东方卫视,http://39.134.66.66/PLTV/88888888/224/3221225672/index.m3u8
东方卫视,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225489/index.m3u8?fmt=ts2hls
东方卫视,http://117.148.179.160/TVOD/88888888/224/3221231738/index.m3u8
东方卫视,http://117.148.179.167/TVOD/88888888/224/3221231450/index.m3u8
东方卫视,http://39.135.138.59:18890/TVOD/88888910/224/3221225659/index.m3u8
东方卫视,http://111.20.41.249/dbiptv.sn.chinamobile.com/PLTV/88888888/224/3221226217/1.m3u8
东方卫视,http://111.59.189.40:8445/tsfile/live/0107_1.m3u8
东方卫视,http://117.148.179.175:80/PLTV/88888888/224/3221231738/index.m3u8
东方卫视,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225659/index.m3u8
东方卫视,http://39.135.138.59:18890/PLTV/88888910/224/3221225659/index.m3u8
东方卫视,http://39.134.115.163:8080/PLTV/88888910/224/3221225659/index.m3u8
浙江卫视,http://39.135.138.59:18890/TVOD/88888910/224/3221225703/index.m3u8
浙江卫视,http://39.135.55.105:6610/PLTV/88888888/224/3221227193/index.m3u8?servicetype=1
浙江卫视,http://39.135.138.60:18890/PLTV/88888910/224/3221225744/index.m3u8
浙江卫视,http://39.134.66.66/PLTV/88888888/224/3221225514/index.m3u8
浙江卫视,http://39.136.48.53:8089/PLTV/88888888/224/3221225585/index.m3u8
浙江卫视,http://39.135.138.60:18890/PLTV/88888910/224/3221225703/index.m3u8
浙江卫视,http://hw-m-l.cztv.com/channels/lantian/channel01/1080p.m3u8
浙江卫视,http://39.134.65.208/PLTV/88888888/224/3221225514/index.m3u8
浙江卫视,http://39.135.138.58:18890/PLTV/88888910/224/3221225703/index.m3u8
浙江卫视,http://39.134.115.163:8080/PLTV/88888910/224/3221225703/index.m3u8
浙江卫视,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225491/index.m3u8?fmt=ts2hls
浙江卫视,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225703/index.m3u8
浙江卫视,http://39.135.138.59:18890/PLTV/88888910/224/3221225703/index.m3u8
浙江卫视,http://117.148.179.140/TVOD/88888888/224/3221229352/index.m3u8
浙江卫视,http://hw-m-l.cztv.com/channels/lantian/channel001/1080p.m3u8
浙江卫视,http://yd-m-l.cztv.com/channels/lantian/channel01/1080p.m3u8
浙江卫视,http://hw-m-l.cztv.com/channels/lantian/channel13/1080p.m3u8
浙江卫视,http://yd-m-l.cztv.com/channels/lantian/channel15/1080p.m3u8
浙江卫视,http://39.134.67.226/PLTV/88888888/224/3221225880/index.m3u8
浙江卫视,http://39.134.67.2:80/ottrrs.hl.chinamobile.com/PLTV/88888888/224/3221225612/1.m3u8
浙江卫视,http://hw-m-l.cztv.com/channels/lantian/channel012/1080p.m3u8
浙江卫视,http://183.207.255.197/live/program/live/jswshd/4000000/mnf.m3u8
江苏卫视,http://39.135.138.59:18890/TVOD/88888910/224/3221225702/index.m3u8
江苏卫视,http://39.135.55.105:6610/PLTV/88888888/224/3221225847/index.m3u8?servicetype=1
江苏卫视,http://39.135.55.105:6610/PLTV/88888888/224/3221225847/index.m3u8?servicetype=1
江苏卫视,http://39.135.55.105:6610/PLTV/88888888/224/3221227160/index.m3u8?servicetype=1
江苏卫视,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225488/index.m3u8?fmt=ts2hls
江苏卫视,http://39.135.138.60:18890/PLTV/88888910/224/3221225743/index.m3u8
江苏卫视,http://39.136.48.53:8089/PLTV/88888888/224/3221226211/index.m3u8
江苏卫视,http://39.135.138.59:18890/PLTV/88888910/224/3221225743/index.m3u8
江苏卫视,http://39.135.32.26:6610/000000001000/1000000001000001828/index.m3u8?i
江苏卫视,http://39.134.65.208/PLTV/88888888/224/3221225503/index.m3u8
江苏卫视,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225488/index.m3u8?fmt=ts2hls
江苏卫视,http://39.134.115.163:8080/PLTV/88888910/224/3221225704/index.m3u8
江苏卫视,http://117.148.179.175/TVOD/88888888/224/3221231447/index.m3u8
深圳卫视,http://39.135.138.59:18890/TVOD/88888910/224/3221225700/index.m3u8
深圳卫视,http://39.135.55.105:6610/PLTV/88888888/224/3221225848/index.m3u8?servicetype=1
深圳卫视,http://222.132.191.125:9901/tsfile/live/0126_1.m3u8
深圳卫视,http://39.135.138.60:18890/PLTV/88888910/224/3221225741/index.m3u8
北京卫视,http://39.135.138.59:18890/TVOD/88888910/224/3221225674/index.m3u8
北京卫视,http://39.135.55.105:6610/PLTV/88888888/224/3221225826/index.m3u8?servicetype=1
北京卫视,http://117.148.179.168:80/PLTV/88888888/224/3221231732/index.m3u8
北京卫视,http://117.148.179.175:80/PLTV/88888888/224/3221231732/index.m3u8
北京卫视,http://39.135.138.59:18890/PLTV/88888888/224/3221225674/index.m3u8
北京卫视,http://222.132.191.125:9901/tsfile/live/0122_1.m3u8
北京卫视,http://117.148.179.168/PLTV/88888888/224/3221231732/index.m3u8
北京卫视,http://39.135.138.60:18890/PLTV/88888910/224/3221225673/index.m3u8
北京卫视,http://39.134.115.163:8080/PLTV/88888910/224/3221225674/index.m3u8
北京卫视,http://39.135.55.7:6610/PLTV/88888888/224/3221225826/index.m3u8?servicetype=1&IASHttpSessionId=OTT
北京卫视,http://183.207.249.7/PLTV/3/224/3221225574/index.m3u8
北京卫视,http://39.136.48.53:8089/PLTV/88888888/224/3221226146/index.m3u8
北京卫视,http://219.151.31.38/liveplay-kk.rtxapp.com/live/program/live/bjwshd/4000000/mnf.m3u8
北京卫视,http://39.134.65.208/PLTV/88888888/224/3221225678/index.m3u8
北京卫视,http://39.135.138.58:18890/PLTV/88888910/224/3221225673/index.m3u8
北京卫视,http://39.135.138.59:18890/PLTV/88888910/224/3221225673/index.m3u8
北京卫视,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225600/index.m3u8?fmt=ts2hls
北京卫视,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225674/index.m3u8
北京卫视,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225673/index.m3u8
北京卫视,http://39.135.138.59:18890/PLTV/88888910/224/3221225674/index.m3u8
北京卫视,http://39.134.115.163:8080/PLTV/88888910/224/3221225739/index.m3u8
北京卫视,http://39.134.115.163:8080/PLTV/88888910/224/3221225698/index.m3u8
北京卫视,http://39.134.115.163:8080/PLTV/88888910/224/3221225705/index.m3u8
重庆卫视,http://39.135.138.59:18890/TVOD/88888910/224/3221225692/index.m3u8
重庆卫视,http://39.135.55.105:6610/PLTV/88888888/224/3221225831/index.m3u8?servicetype=1
重庆卫视,http://222.132.191.125:9901/tsfile/live/0142_1.m3u8
重庆卫视,http://39.135.138.60:18890/PLTV/88888910/224/3221225734/index.m3u8
重庆卫视,http://39.135.138.59:18890/PLTV/88888910/224/3221225734/index.m3u8
重庆卫视,http://39.134.19.252:6610/yinhe/2/ch00000090990000001297/index.m3u8?virtualDomain=yinhe.live_hls.zte.com$
云南卫视,http://39.135.55.105:6610/PLTV/88888888/224/3221227181/index.m3u8?servicetype=1
云南卫视,http://39.135.55.7:6610/PLTV/88888888/224/3221227181/everydaylive_ynws.m3u8?servicetype=1&from=everydaytv4.2
云南卫视,http://39.135.55.7:6610/PLTV/88888888/224/3221227181/index.m3u8?servicetype=1&IASHttpSessionId=OTT
天津卫视,http://39.135.138.59:18890/TVOD/88888910/224/3221225698/index.m3u8
天津卫视,http://39.135.55.105:6610/PLTV/88888888/224/3221225830/index.m3u8?servicetype=1
天津卫视,http://222.132.191.125:9901/tsfile/live/0135_1.m3u8
天津卫视,http://39.135.138.60:18890/PLTV/88888910/224/3221225739/index.m3u8
天津卫视,http://39.136.48.4:8089/PLTV/88888888/224/3221226485/index.m3u8
天津卫视,http://39.134.66.66/PLTV/88888888/224/3221225665/index.m3u8
四川卫视,http://117.148.179.142/TVOD/88888888/224/3221231885/index.m3u8
四川卫视,http://39.135.55.105:6610/PLTV/88888888/224/3221227182/index.m3u8?servicetype=1
四川卫视,http://39.136.48.2:8089/PLTV/88888888/224/3221226327/index.m3u8
四川卫视,http://39.136.48.6:8089/PLTV/88888888/224/3221226327/index.m3u8
山东卫视,http://39.135.138.59:18890/TVOD/88888910/224/3221225697/index.m3u8
山东卫视,http://39.135.55.105:6610/PLTV/88888888/224/3221225843/index.m3u8?servicetype=1
山东卫视,http://222.132.191.125:9901/tsfile/live/0131_1.m3u8
山东卫视,http://39.135.138.60:18890/PLTV/88888910/224/3221225738/index.m3u8
山东卫视,http://39.135.138.59:18890/PLTV/88888910/224/3221225697/index.m3u8
山东卫视,http://39.134.65.141/PLTV/88888888/224/3221225952/1.m3u8
山东卫视,http://219.151.31.38/liveplay-kk.rtxapp.com/live/program/live/sdwshd/4000000/mnf.m3u8
山东卫视,http://39.135.138.59:18890/PLTV/88888910/224/3221225738/index.m3u8
山东卫视,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225697/index.m3u8
山东卫视,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225738/index.m3u8
山东卫视,http://39.134.67.226/PLTV/88888888/224/3221225857/index.m3u8
山东卫视,http://111.20.33.93/TVOD/88888893/224/3221226209/index.m3u8
厦门卫视,http://39.135.55.105:6610/PLTV/88888888/224/3221226781/index.m3u8?servicetype=1
厦门卫视,http://39.135.55.7:6610/PLTV/88888888/224/3221226781/everydaylive_xmws.m3u8?servicetype=1&from=everydaytv4.2
厦门卫视,http://39.135.55.7:6610/PLTV/88888888/224/3221226781/index.m3u8?servicetype=1&IASHttpSessionId=OTT
南方卫视,https://zqy-live.nanyuecloud.com/qingyuandianshi/qingyuandianshistream.m3u8?auth_key=601634549257-0-0-73ab89e29b6bf8ef7b5144cf0c04935a
辽宁卫视,http://117.148.179.152/TVOD/88888888/224/3221231802/index.m3u8
辽宁卫视,http://39.135.138.59:18890/TVOD/88888910/224/3221225696/index.m3u8
辽宁卫视,http://39.135.55.105:6610/PLTV/88888888/224/3221225832/index.m3u8?servicetype=1
辽宁卫视,http://39.135.55.7:6610/PLTV/88888888/224/3221225832/everydaylive_lnws.m3u8?servicetype=1&from=everydaytv4.2
辽宁卫视,http://222.132.191.125:9901/tsfile/live/0121_1.m3u8
辽宁卫视,http://117.148.179.152/PLTV/88888888/224/3221231802/index.m3u8
辽宁卫视,http://39.135.138.60:18890/PLTV/88888910/224/3221225735/index.m3u8
辽宁卫视,http://39.135.138.59:18890/PLTV/88888910/224/3221225696/index.m3u8
辽宁卫视,http://39.134.115.163:8080/PLTV/88888910/224/3221225696/index.m3u8
辽宁卫视,http://39.134.19.252:6610/yinhe/2/ch00000090990000001296/index.m3u8?virtualDomain=yinhe.live_hls.zte.com$
辽宁卫视,http://39.136.48.53:8089/PLTV/88888888/224/3221225789/index.m3u8
辽宁卫视,http://219.151.31.38/liveplay-kk.rtxapp.com/live/program/live/lnwshd/4000000/mnf.m3u8
辽宁卫视,http://39.135.138.59:18890/PLTV/88888910/224/3221225735/index.m3u8
辽宁卫视,http://39.134.115.163:8080/PLTV/88888910/224/3221225735/index.m3u8
辽宁卫视,http://39.135.138.58:18890/PLTV/88888910/224/3221225696/index.m3u8
辽宁卫视,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225601/index.m3u8?fmt=ts2hls
辽宁卫视,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225696/index.m3u8
辽宁卫视,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225735/index.m3u8
辽宁卫视,http://39.135.138.58:18890/PLTV/88888888/224/3221225696/index.m3u8
辽宁卫视,http://111.20.33.93/TVOD/88888893/224/3221226210/index.m3u8
江西卫视,http://117.148.179.141/TVOD/88888888/224/3221231964/index.m3u8
江西卫视,http://39.135.138.59:18890/TVOD/88888910/224/3221225705/index.m3u8
江西卫视,http://39.135.55.105:6610/PLTV/88888888/224/3221225834/index.m3u8?servicetype=1
江西卫视,http://117.148.179.141/PLTV/88888888/224/3221231964/index.m3u8
江西卫视,http://39.135.138.60:18890/PLTV/88888910/224/3221225746/index.m3u8
江西卫视,http://219.151.31.38/liveplay-kk.rtxapp.com/live/program/live/jxwshd/4000000/mnf.m3u8
吉林卫视,http://39.135.55.105:6610/PLTV/88888888/224/3221227099/index.m3u8?servicetype=1
吉林卫视,http://39.134.66.110/PLTV/88888888/224/3221225981/index.m3u8
吉林卫视,http://39.134.65.149/PLTV/88888888/224/3221225981/1.m3u8
吉林卫视,http://39.134.65.141/PLTV/88888888/224/3221225981/1.m3u8
吉林卫视,http://39.134.65.151/PLTV/88888888/224/3221225981/1.m3u8
吉林卫视,http://39.135.55.7:6610/PLTV/88888888/224/3221227099/index.m3u8?servicetype=1&IASHttpSessionId=OTT
吉林卫视,http://39.134.65.145/PLTV/88888888/224/3221225981/1.m3u8
湖北卫视,http://117.148.179.142/TVOD/88888888/224/3221231888/index.m3u8
湖北卫视,http://39.135.138.59:18890/TVOD/88888910/224/3221225699/index.m3u8
湖北卫视,http://39.135.55.105:6610/PLTV/88888888/224/3221225840/index.m3u8?servicetype=1
湖北卫视,http://222.132.191.125:9901/tsfile/live/0132_1.m3u8
湖北卫视,http://39.135.138.60:18890/PLTV/88888910/224/3221225740/index.m3u8
湖北卫视,http://39.134.66.66/PLTV/88888888/224/3221225569/index.m3u8
湖北卫视,http://39.135.32.27:6610/000000001000/1000000001000010355/index.m3u8?i
湖北卫视,http://39.134.19.252:6610/yinhe/2/ch00000090990000001299/index.m3u8?virtualDomain=yinhe.live_hls.zte.com$
黑龙江卫视,http://117.148.179.141/TVOD/88888888/224/3221231967/index.m3u8
黑龙江卫视,http://39.135.138.59:18890/TVOD/88888910/224/3221225690/index.m3u8
黑龙江卫视,http://39.135.55.105:6610/PLTV/88888888/224/3221225862/index.m3u8?servicetype=1
黑龙江卫视,http://39.136.48.5:8089/PLTV/88888888/224/3221226148/index.m3u8
黑龙江卫视,http://39.136.48.7:8089/PLTV/88888888/224/3221226148/index.m3u8
黑龙江卫视,http://39.136.48.53:8089/PLTV/88888888/224/3221226148/index.m3u8
黑龙江卫视,http://219.151.31.38/liveplay-kk.rtxapp.com/live/program/live/hljwshd/4000000/mnf.m3u8
河南卫视,http://39.135.55.7:6610/PLTV/88888888/224/3221227095/index.m3u8?servicetype=1&IASHttpSessionId=OTT
河南卫视,http://39.135.55.7:6610/PLTV/88888888/224/3221227095/index.m3u8?servicetype=1&IASHttpSessionId=OTT
河北卫视,http://39.136.48.2:8089/PLTV/88888888/224/3221225779/index.m3u8
河北卫视,http://39.136.48.5:8089/PLTV/88888888/224/3221225779/index.m3u8
河北卫视,http://39.136.48.8:8089/PLTV/88888888/224/3221225779/index.m3u8
河北卫视,http://39.135.55.7:6610/PLTV/88888888/224/3221227063/index.m3u8?servicetype=1&IASHttpSessionId=OTT
海南卫视,http://39.135.55.7:6610/PLTV/88888888/224/3221227216/index.m3u8?servicetype=1&IASHttpSessionId=OTT
海南卫视,http://39.135.55.7:6610/PLTV/88888888/224/3221227216/index.m3u8?servicetype=1&IASHttpSessionId=OTT
贵州卫视,http://39.136.48.2:8089/PLTV/88888888/224/3221225777/index.m3u8
贵州卫视,http://39.136.48.5:8089/PLTV/88888888/224/3221225777/index.m3u8
贵州卫视,http://39.134.65.149/PLTV/88888888/224/3221225974/1.m3u8
贵州卫视,http://39.134.65.141/PLTV/88888888/224/3221225974/1.m3u8
贵州卫视,http://39.134.65.151/PLTV/88888888/224/3221225974/1.m3u8
贵州卫视,http://39.134.65.145/PLTV/88888888/224/3221225974/1.m3u8
贵州卫视,http://39.135.55.7:6610/PLTV/88888888/224/3221227201/index.m3u8?servicetype=1&IASHttpSessionId=OTT
广东卫视,http://222.132.191.125:9901/tsfile/live/0125_1.m3u8
广东卫视,http://117.148.179.141/PLTV/88888888/224/3221231891/index.m3u8
广东卫视,http://39.135.138.60:18890/PLTV/88888910/224/3221225742/index.m3u8
广东卫视,http://39.134.115.163:8080/PLTV/88888910/224/3221225701/index.m3u8
广东卫视,http://39.135.138.59:18890/PLTV/88888910/224/3221225742/index.m3u8
广东卫视,http://39.136.48.53:8089/PLTV/88888888/224/3221226213/index.m3u8
广东卫视,http://219.151.31.38/liveplay-kk.rtxapp.com/live/program/live/gdwshd/4000000/mnf.m3u8
广东卫视,http://39.135.138.58:18890/PLTV/88888910/224/3221225742/index.m3u8
广东卫视,http://39.134.115.163:8080/PLTV/88888910/224/3221225742/index.m3u8
广东卫视,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225701/index.m3u8
广东卫视,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225742/index.m3u8
广东卫视,http://39.135.138.59:18890/PLTV/88888910/224/3221225701/index.m3u8
广东卫视,http://39.134.115.163:8080/PLTV/88888910/224/3221225738/index.m3u8
广东卫视,http://39.134.115.163:8080/PLTV/88888910/224/3221225697/index.m3u8
甘肃卫视,http://39.136.48.26:8089/PLTV/88888888/224/3221226387/index.m3u8
东南卫视,http://39.134.66.110/PLTV/88888888/224/3221225863/index.m3u8
东南卫视,http://39.134.115.163:8080/PLTV/88888910/224/3221225657/index.m3u8
东南卫视,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225657/index.m3u8
东南卫视,http://219.151.31.38/liveplay-kk.rtxapp.com/live/program/live/dnwshd/4000000/mnf.m3u8
安徽卫视,http://112.25.47.24/gitv_live/G_ANHUI-HD-265-8M/G_ANHUI-HD-265-8M.m3u8?p=GITV&area=JS_CMCC_CP
安徽卫视,http://112.25.47.24/gitv_live/G_ANHUI-MD/G_ANHUI-MD.m3u8?p=GITV&area=JS_CMCC_CP
安徽卫视,http://117.148.179.177/TVOD/88888888/224/3221230215/index.m3u8
安徽卫视,http://39.135.138.59:18890/TVOD/88888910/224/3221225691/index.m3u8
安徽卫视,http://39.135.55.105:6610/PLTV/88888888/224/3221225844/index.m3u8?servicetype=1
安徽卫视,http://111.20.41.249/dbiptv.sn.chinamobile.com/PLTV/88888888/224/3221226196/1.m3u8
安徽卫视,http://111.59.189.40:8445/tsfile/live/0130_1.m3u8
安徽卫视,http://222.132.191.125:9901/tsfile/live/0130_1.m3u8
安徽卫视,http://39.135.138.59:18890/PLTV/88888910/224/3221225737/index.m3u8
安徽卫视,http://39.134.65.141/PLTV/88888888/224/3221225925/1.m3u8
安徽卫视,http://39.135.55.7:6610/PLTV/88888888/224/3221225844/index.m3u8?servicetype=1&IASHttpSessionId=OTT
安徽卫视,http://219.151.31.38/liveplay-kk.rtxapp.com/live/program/live/ahwshd/4000000/mnf.m3u8
安徽卫视,http://39.134.19.252:6610/yinhe/2/ch00000090990000001298/index.m3u8?virtualDomain=yinhe.live_hls.zte.com$
兵团卫视,http://111.59.189.40:8445/tsfile/live/0115_1.m3u8

💦湖南,#genre#
湖南都市,http://124.232.233.15:6610/000000001001/201600020003/1400.m3u8?IASHttpSessionId=SLB2046220190906022827233263&m3u8_level=2&ztecid=201500000245&ispcode=3
湖南都市,http://124.232.233.15:6610/000000001001/201600020003/1400.m3u8?m3u8_level=2
湖南都市,http://124.232.233.15:6610/000000001001/201600020003/1400.m3u8?IASHttpSessionId=SLB2046220190906022827233263&m3u8_level=2
湖南都市,http://124.232.231.246:6610/000000001001/201600020003/index.m3u8?A
湖南都市,http://124.232.233.15:6610/000000001001/201600020003/1400.m3u8?IASHttpSessionId=SLB2046220190906022827233263&m3u8_level=2
湖南都市,http://kjol.cc/proxy/hunan.php?id=346
湖南都市,http://stream.guihet.com/t/hunan.php?id=346
湖南经视,http://124.232.231.246:6610/000000001001/201600020002/index.m3u8?A
湖南经视,http://124.232.233.15:6610/000000001001/201600020002/1400.m3u8?m3u8_level=2
湖南经视,http://cache.ott.fifalive.itv.cmvideo.cn:80/000000001000/hnjingshi/index.m3u8?channel-id=ystenlive&Contentid=hnjingshi&livemode=1&authCode=3a&stbId=004203003004001001B254C57A60AC10&version=1.0&owaccmark=hnjingshi&owchid=ystenlive&owsid=8551421638843014795&AuthInfo=WeQYnwDbWk4GUvd54G0dJtof3vRM%2B2ypD%2BOuRwkfZL3%2FBgTw8EGqxrSqrXVnNtk0eJwD1HUQQtD%2FH4R96rWx%2F0Dpj5cysh2VR1rCb5to72k%3D
湖南经视,http://cache.ott.fifalive.itv.cmvideo.cn:80/000000001000/hnjingshi/index.m3u8?channel-id=ystenlive&Contentid=hnjingshi&livemode=1&authCode=3a&stbId=004701FF0001182003AB60313BF7655A&version=1.0&owaccmark=hnjingshi&owchid=ystenlive&owsid=8417171638842885282&AuthInfo=CddfQWIesl%2B0%2FTw4xAGbWBKSbFx4tSCKlQU%2FjlITR9D%2FBgTw8EGqxrSqrXVnNtk0QgONMXSDecfPIRrzlxJp1WdeMjBWruDH7wD8bpRx1dQ%3D
湖南经视,http://ls.qingting.fm/live/1207.m3u8
湖南经视,http://220.202.142.253:808/hls/13/index.m3u8
湖南电影,http://124.232.233.15:6610/000000001001/201600020005/1400.m3u8?m3u8_level=2
湖南电影,http://124.232.233.15:6610/000000001001/201600020005/1400.m3u8?IASHttpSessionId=SLB2046220190906022827233263&m3u8_level=2
湖南电影,http://111.40.196.30/PLTV/88888888/224/3221225660/index.m3u8
湖南教育,http://119.39.128.12:88/hls/25/index.m3u8
湖南教育,http://pull.hnedutv.com/live/hnedutv1206.m3u8?sub_m3u8=true&edge_slice=true
湖南教育,http://0b4e127539ff8c3fb7398ab07b004ec1.livehwc3.cn/pull.hnedutv.com/live/hnedutv1206.m3u8?sub_m3u8=true&edge_slice=true&user_session_id=7ee96ed9c66d94296014ecde50ff6933
湖南电视剧,http://124.232.233.15:6610/000000001001/201600020006/1400.m3u8?m3u8_level=2
湖南电视剧,http://111.40.196.9/PLTV/88888888/224/3221225662/index.m3u8
湖南电视剧,http://kjol.cc/proxy/hunan.php?id=484
湖南电视剧,http://stream.guihet.com/t/hunan.php?id=484
湖南公共,http://124.232.233.15:6610/000000001001/201600020007/1400.m3u8?m3u8_level=2
湖南公共,http://124.232.231.246:6610/000000001001/201600020007/index.m3u8?A
湖南公共,http://cache.ott.fifalive.itv.cmvideo.cn/000000001000/6307875884530512195/index.m3u8?channel-id=hnbblive&Contentid=6307875884530512195&livemode=1&authCode=3a&stbId=0010039901A0130000010016FBA11E44&version=1.0&owaccmark=6307875884530512195&owchid=hnbblive&owsid=8155251638769667490&AuthInfo=%2F%2F4bFTP9QvUxZzR6rcopDy6cEI%2Bi1cBITpvk0DOmTTwWxCpDbpek4w%2FFGgK3s6Ky4QMI3SYq%2Fix5f5BNuXESS%2Bo%2BtHf%2F8yaLvz%2Fw8iztow1tYKlMyEBOV5nOp8DMakQR
湖南公共,http://cache.ott.fifalive.itv.cmvideo.cn:80/000000001000/6307875884530512195/index.m3u8?channel-id=hnbblive&Contentid=6307875884530512195&livemode=1&authCode=3a&stbId=004701FF0001061001B354C57A9F78ED&version=1.0&owaccmark=6307875884530512195&owchid=hnbblive&owsid=8845681638776584973&AuthInfo=byYOYFPlCvQbKYBGvmFPFr8%2FjJsFLkA3P37IprRFU5UWxCpDbpek4w%2FFGgK3s6Kyqd6Z7KQ1C8zN8e2BL7m%2F3ef8QY4WazbHIjy%2BF1eGxvkUEEot8m7M1dOjqqzZFlhf
湖南公共,http://kjol.cc/proxy/hunan.php?id=261
湖南公共,http://stream.guihet.com/t/hunan.php?id=261
湖南国际,http://124.232.233.15:6610/000000001001/201600020001/1400.m3u8?m3u8_level=2
湖南国际,http://124.232.231.246:6610/000000001001/201600020001/index.m3u8?A
湖南国际,http://cache.ott.fifalive.itv.cmvideo.cn/000000001000/5015828848322021526/index.m3u8?channel-id=hnbblive&Contentid=5015828848322021526&livemode=1&authCode=3a&stbId=0010099900E08200SY0488947E7BCB37&version=1.0&owaccmark=5015828848322021526&owchid=hnbblive&owsid=1213951638767440573&AuthInfo=1cKEtXhCyPUp0C7Os%2F4hFnRLJbdGQml%2FJ6SgEPCodeRUjPYNyZbt2ySh3CnWRg7ZXZOBrprOC1TMGiwuCjsNRU%2FY5Cf1JJzs15jSc3VWnlYEWWUEij0Yl3a7KJlYq%2FHc
湖南国际,http://124.232.231.246:6610/000000001001/201600020001/1000.m3u8?IASHttpSessionId=OTT2939020211208005610067491&zte_bandwidth=1000&bandwidth=1433600&ispcode=3&timeformat=local&channel=201600020001&ztecid=201600020001&m3u8_level=2&A=
湖南国际,http://124.232.231.246:6610/000000001001/201600020001/index.m3u8?A=&IASHttpSessionId=OTT2938120211208005554069879
湖南国际,http://kjol.cc/proxy/hunan.php?id=229
湖南国际,http://stream.guihet.com/t/hunan.php?id=229
湖南娱乐,http://124.232.233.15:6610/000000001001/201600020004/1400.m3u8?m3u8_level=2
湖南娱乐,http://124.232.231.246:6610/000000001001/201600020004/index.m3u8?A
湖南娱乐,http://cache.ott.fifalive.itv.cmvideo.cn:80/000000001000/6427893650335440392/index.m3u8?channel-id=hnbblive&Contentid=6427893650335440392&livemode=1&authCode=3a&stbId=2E100499007034400000749781B4F9F8&version=1.0&owaccmark=6427893650335440392&owchid=hnbblive&owsid=6996331638768384328&AuthInfo=tKKJ%2BFVlkuoKUIcI9GZjdphwp0XaPa1o9oRt%2FcblwIg2UICXh55EE5Fvjda4XWRZzZxIMTZzB5D%2FFHWfxb1J50K%2FVXfkUEHtGoLd5N9fdairytkVI%2Bd0O3lms2CNYwPF
湖南娱乐,http://124.232.231.246:6610/000000001001/201600020004/1000.m3u8?IASHttpSessionId=OTT2933020211208004916069966&zte_bandwidth=1000&bandwidth=1433600&ispcode=3&timeformat=local&channel=201600020004&ztecid=201600020004&m3u8_level=2&A=
湖南娱乐,http://124.232.231.246:6610/000000001001/201600020004/1000.m3u8?IASHttpSessionId=OTT2939820211208005305069106&zte_bandwidth=1000&bandwidth=1433600&ispcode=3&timeformat=local&channel=201600020004&ztecid=201600020004&m3u8_level=2&A=
湖南娱乐,http://kjol.cc/proxy/hunan.php?id=344
湖南娱乐,http://stream.guihet.com/t/hunan.php?id=344
金鹰纪实,http://124.232.231.246:6610/000000001001/201600020008/index.m3u8?A
金鹰纪实,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221226198/index.m3u8
金鹰卡通,http://59.44.10.113:9901/tsfile/live/1063_1.m3u8
金鹰卡通,http://39.135.49.209:6610/PLTV/88888888/224/3221227018/1.m3u8?servicetype=1
金鹰卡通,http://cache.ott.fifalive.itv.cmvideo.cn/000000001000/1000000002000016601/index.m3u8?channel-id=ystenlive&Contentid=1000000002000016601&livemode=1&authCode=3a&stbId=0043030000011010171158B42D04EED1&version=1.0&owaccmark=1000000002000016601&owchid=ystenlive&owsid=1120031638765059827&AuthInfo=UDPnSALVZASHe9mxqf4Fx9zPIkxQyGJ8Rg6PAXxqwNO%2BQOp3NtYnO5PijiYOGTWGmW6n6f129zMRFLrBYb%2F75HnBDhN24JHKp42xDvsoFQ1ys9FfB2c52uEeNFd7Tyxa
金鹰卡通,http://cache.ott.fifalive.itv.cmvideo.cn/000000001000/5201381050640253101/index.m3u8?channel-id=ystenlive&Contentid=5201381050640253101&livemode=1&authCode=3a&stbId=004903FF000248000004A8BD3A9D31A0&version=1.0&owaccmark=5201381050640253101&owchid=ystenlive&owsid=1927321638765262142&AuthInfo=U4bGXPj8KcQ7vS4uSzzkFNpBa6KLZNVpYaMV%2FHxBe5AxDiVMr6y7mEqDg%2F2RkwAPc1GK%2B3pf5rQs%2FuG6G7Lkc4YnGA3tEx2dCo9yzV7j0hKFakrHH1xP4ZcYSskMu%2FHE
金鹰卡通,http://39.134.66.66/PLTV/88888888/224/3221225561/index.m3u8
金鹰卡通,http://111.40.196.9/PLTV/88888888/224/3221225605/index.m3u8
金鹰卡通,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/88888888/3221225554/index.m3u8?fmt=ts2hls
先锋乒羽,http://cache.ott.fifalive.itv.cmvideo.cn:80/000000001000/4886720949268374180/index.m3u8?channel-id=hnbblive&Contentid=4886720949268374180&livemode=1&authCode=3a&stbId=0010099900E08200SY0488947E7BCB37&version=1.0&owaccmark=4886720949268374180&owchid=hnbblive&owsid=9422161639442351812&AuthInfo=1cKEtXhCyPUp0C7Os%2F4hFnRLJbdGQml%2FJ6SgEPCodeSyEl4YgZli3eCZkxKxNZoAH%2Bwl40La22jRoeLS4FjRFBQbjb8Orq4Iz%2FRjuDeKGnZGLEtWzZ6xtbev%2FwV3b19q
先锋乒羽,http://cache.ott.fifalive.itv.cmvideo.cn:80/000000001000/4886720949268374180/index.m3u8?channel-id=hnbblive&Contentid=4886720949268374180&livemode=1&authCode=3a&stbId=381001000000004000001A2B3C4D5E6F&version=1.0&owaccmark=4886720949268374180&owchid=hnbblive&owsid=2008781639442355049&AuthInfo=iLXPSBa%2BDR34rZ0yMNNDDc4pGTJZc1VCPpfsNdYPlFKyEl4YgZli3eCZkxKxNZoAH%2Bwl40La22jRoeLS4FjRFMPior9WMUHMnc7M2orxIOxJI5Gsm9oW1cPww%2B5ATuAU
先锋乒羽,http://116.211.156.28/live.aishang.ctlcdn.com/00000110240320_1/encoder/0/playlist.m3u8?CONTENTID=00000110240320_1
茶频道,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225781/index.m3u8?fmt=ts2hls
快乐垂钓,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225780/index.m3u8?fmt=ts2hls
长沙新闻,rtmp://35848.lssplay.aodianyun.com/guangdianyun_35848/tv_channel_346?auth_key=1936692784-0-0-9042421539d8424068f7e575f090dbca
长沙政法,http://35848.hlsplay.aodianyun.com/guangdianyun_35848/tv_channel_348.flv?auth_key=1936693647-0-0-09a2ab1e7112296d76b1c37999a5cf32
长沙影视,http://35848.hlsplay.aodianyun.com/guangdianyun_35848/tv_channel_350.flv?auth_key=1936694127-0-0-f081dadf4de8780d84d51755eb65e516
永州综合,http://stream.21ytv.com/xw/8twnQW67/live.m3u8?_upt=2ee2ce141629088895
永州公共,http://stream.21ytv.com/gg/playlist.m3u8?_upt=2f1afe4a1638954105
永州公共,http://stream.21ytv.com/gg/8twnQW67/live.m3u8?_upt=0a400dbe1638954104
永州公共,http://stream.21ytv.com/gg/playlist.m3u8?_upt=8f360a7b1638940836
东安综合,http://play-dgv-xhncloud.voc.com.cn/live/5243_Twis7r.m3u8
点掌财经,http://cclive2.aniu.tv/live/anzb.m3u8
时尚频道,https://juyunlive.juyun.tv/live/24950198.m3u8

☺北京,#genre#
北京IPTV淘电影,http://39.134.135.81/otttv.bj.chinamobile.com/PLTV/88888888/224/3221226552/index.m3u8?servicetype=1&icpid=&accounttype=1&limitflux=-1&limitdur=-1&GuardEncType=2&accountinfo=3QGHZfaujB8rRCsAsCvwpxxlHr4QY7xmzJA0CWZ2m2oFrdR%2B0WqiDAHoOrKmOBjJo1DAVyGMxV75D0k9A8UW52%2FrO%2F0g1FiOsgmHLskIhGej57NNTIcVyR%2FC8%2FqFakBO7Z60nQmH%2FQdgWVzAI0y58w%3D%3D%3A20211105223205%2C10000100000000050000000003887498%2CF6D75A298389DD1E7C3B7D397327CA23%2C-1%2C0%2C1%2C%2C%2C2%2C%2C%2CEND
北京IPTV淘剧场,http://39.134.134.84/otttv.bj.chinamobile.com/PLTV/88888888/224/3221226553/index.m3u8?servicetype=1&icpid=&accounttype=1&limitflux=-1&limitdur=-1&GuardEncType=2&accountinfo=3QGHZfaujB8rRCsAsCvwpxxlHr4QY7xmzJA0CWZ2m2oFrdR%2B0WqiDAHoOrKmOBjJo1DAVyGMxV75D0k9A8UW52%2FrO%2F0g1FiOsgmHLskIhGej57NNTIcVyR%2FC8%2FqFakBOatI%2F3LD77f6VT%2BVI0tODRw%3D%3D%3A20211105223205%2C10000100000000050000000003887497%2CF6D75A298389DD1E7C3B7D397327CA23%2C-1%2C0%2C1%2C%2C%2C2%2C%2C%2CEND
北京IPTV淘娱乐,http://39.134.134.88/otttv.bj.chinamobile.com/PLTV/88888888/224/3221226551/index.m3u8?servicetype=1&icpid=&accounttype=1&limitflux=-1&limitdur=-1&GuardEncType=2&accountinfo=3QGHZfaujB8rRCsAsCvwpxxlHr4QY7xmzJA0CWZ2m2oFrdR%2B0WqiDAHoOrKmOBjJo1DAVyGMxV75D0k9A8UW52%2FrO%2F0g1FiOsgmHLskIhGej57NNTIcVyR%2FC8%2FqFakBOtChdQBj46BMs%2FmbjOB0PZw%3D%3D%3A20211105223205%2C10000100000000050000000003887499%2CF6D75A298389DD1E7C3B7D397327CA23%2C-1%2C0%2C1%2C%2C%2C2%2C%2C%2CEND
北京IPTV萌宠TV,http://39.134.134.84/otttv.bj.chinamobile.com/PLTV/88888888/224/3221226555/index.m3u8?servicetype=1&icpid=&accounttype=1&limitflux=-1&limitdur=-1&GuardEncType=2&accountinfo=3QGHZfaujB8rRCsAsCvwpxxlHr4QY7xmzJA0CWZ2m2oFrdR%2B0WqiDAHoOrKmOBjJo1DAVyGMxV75D0k9A8UW52%2FrO%2F0g1FiOsgmHLskIhGej57NNTIcVyR%2FC8%2FqFakBOSDD3mErwuVWF5DqfHIW%2FMQ%3D%3D%3A20211105223205%2C10000100000000050000000003887495%2CF6D75A298389DD1E7C3B7D397327CA23%2C-1%2C0%2C1%2C%2C%2C2%2C%2C%2CEND
北京IPTV淘BABY,http://39.134.134.89/otttv.bj.chinamobile.com/PLTV/88888888/224/3221226554/index.m3u8?servicetype=1&icpid=&accounttype=1&limitflux=-1&limitdur=-1&GuardEncType=2&accountinfo=3QGHZfaujB8rRCsAsCvwpxxlHr4QY7xmzJA0CWZ2m2oFrdR%2B0WqiDAHoOrKmOBjJo1DAVyGMxV75D0k9A8UW52%2FrO%2F0g1FiOsgmHLskIhGej57NNTIcVyR%2FC8%2FqFakBOBGhARyizMEPlAOe9nM1b5Q%3D%3D%3A20211105223205%2C10000100000000050000000003887496%2CF6D75A298389DD1E7C3B7D397327CA23%2C-1%2C0%2C1%2C%2C%2C2%2C%2C%2CEND
北京IPTV大健康,http://39.134.134.88/otttv.bj.chinamobile.com/PLTV/88888888/224/3221226556/index.m3u8?servicetype=1&icpid=&accounttype=1&limitflux=-1&limitdur=-1&GuardEncType=2&accountinfo=3QGHZfaujB8rRCsAsCvwpxxlHr4QY7xmzJA0CWZ2m2oFrdR%2B0WqiDAHoOrKmOBjJo1DAVyGMxV75D0k9A8UW52%2FrO%2F0g1FiOsgmHLskIhGej57NNTIcVyR%2FC8%2FqFakBOwqRuq1wlVOXKPSxUnb4JNQ%3D%3D%3A20211105223205%2C10000100000000050000000003887494%2CF6D75A298389DD1E7C3B7D397327CA23%2C-1%2C0%2C1%2C%2C%2C2%2C%2C%2CEND
北京IPTV4K超清,http://39.134.134.85/otttv.bj.chinamobile.com/PLTV/88888888/224/3221226550/index.m3u8?servicetype=1&icpid=&accounttype=1&limitflux=-1&limitdur=-1&GuardEncType=2&accountinfo=3QGHZfaujB8rRCsAsCvwpxxlHr4QY7xmzJA0CWZ2m2oFrdR%2B0WqiDAHoOrKmOBjJo1DAVyGMxV75D0k9A8UW52%2FrO%2F0g1FiOsgmHLskIhGej57NNTIcVyR%2FC8%2FqFakBO3%2B2%2FLci77HWE%2FMDUdCEgEA%3D%3D%3A20211105223205%2C10000100000000050000000003887500%2CF6D75A298389DD1E7C3B7D397327CA23%2C-1%2C0%2C1%2C%2C%2C2%2C%2C%2CEND
北京卫视,http://111.6.126.218/hsplay-360.v.btime.com/live_btime/btv_sn_20170706_s1/index.m3u8
北京文艺,http://111.6.126.218/hsplay-360.v.btime.com/live_btime/btv_sn_20170706_s2/index.m3u8
北京科教,http://111.6.126.218/hsplay-360.v.btime.com/live_btime/btv_sn_20170706_s3/index.m3u8
北京影视,http://111.6.126.218/hsplay-360.v.btime.com/live_btime/btv_sn_20170706_s4/index.m3u8
北京财经,http://111.6.126.218/hsplay-360.v.btime.com/live_btime/btv_sn_20170706_s5/index.m3u8
北京生活,http://111.6.126.218/hsplay-360.v.btime.com/live_btime/btv_sn_20170706_s7/index.m3u8
北京青年,http://111.6.126.218/hsplay-360.v.btime.com/live_btime/btv_sn_20170706_s8/index.m3u8
北京新闻,http://111.6.126.218/hsplay-360.v.btime.com/live_btime/btv_sn_20170706_s9/index.m3u8
欢笑剧场,http://shbu.live.bestvcdn.com.cn:8080/live/program/live/hxjchd/4000000/mnf.m3u8
动漫秀场,http://shbu.live.bestvcdn.com.cn:8080/live/program/live/dmxchd/4000000/mnf.m3u8

💯课堂,#genre#
一年级,http://117.148.179.183/PLTV/88888888/224/3221231721/index.m3u8
二年级,http://117.148.179.183/PLTV/88888888/224/3221231663/index.m3u8
三年级,http://117.148.179.183/PLTV/88888888/224/3221231739/index.m3u8
四年级,http://117.148.179.183/PLTV/88888888/224/3221231748/index.m3u8
五年级,http://117.148.179.183/PLTV/88888888/224/3221231766/index.m3u8
六年级,http://117.148.179.183/PLTV/88888888/224/3221231796/index.m3u8
七年级,http://117.148.179.183/PLTV/88888888/224/3221231781/index.m3u8
八年级,http://117.148.179.183/PLTV/88888888/224/3221231691/index.m3u8
九年级,http://117.148.179.183/PLTV/88888888/224/3221231642/index.m3u8
高一年级,http://117.148.179.183/PLTV/88888888/224/3221231705/index.m3u8
高二年级,http://117.148.179.183/PLTV/88888888/224/3221231630/index.m3u8
高三年级,http://117.148.179.183/PLTV/88888888/224/3221231690/index.m3u8

🟠斗鱼,#genre#
斗鱼电影HD1,http://124.223.212.38:83/douyu/4246519
斗鱼电影HD3,http://124.223.212.38:83/douyu/122402
斗鱼电影HD4,http://124.223.212.38:83/douyu/85894
斗鱼电影HD5,http://124.223.212.38:83/douyu/747764
斗鱼电影HD6,http://zzy-789.xyz/douyu1.php?id=747764
斗鱼电影HD7,http://124.223.212.38:83/douyu/20415
斗鱼电影HD9,http://124.223.212.38:83/douyu/323876
斗鱼电影HD10,http://124.223.212.38:83/douyu/6140589
斗鱼电影HD10,http://zzy-789.xyz/douyu1.php?id=6140589
斗鱼电影HD11,http://124.223.212.38:83/douyu/8770422
斗鱼电影HD11,http://diyp.112114.xyz/douyu/8770422
斗鱼电影HD12,http://124.223.212.38:83/douyu/2436390
斗鱼电影HD12,http://diyp.112114.xyz/douyu/2436390
斗鱼电影HD13,http://124.223.212.38:83/douyu/218859
斗鱼电影HD13,http://zzy-789.xyz/douyu1.php?id=218859
斗鱼电影HD14,http://124.223.212.38:83/douyu/36337
斗鱼电影HD14,http://diyp.112114.xyz/douyu/36337
斗鱼电影HD15,http://124.223.212.38:83/douyu/413573
斗鱼电影HD15,http://diyp.112114.xyz/douyu/413573
斗鱼电影HD16,http://124.223.212.38:83/douyu/1504768
斗鱼电影HD17,http://124.223.212.38:83/douyu/3637726
斗鱼电影HD18,http://124.223.212.38:83/douyu/9292492
斗鱼电影HD18,http://zzy-789.xyz/douyu1.php?id=9292492
斗鱼电影HD19,http://zzy-789.xyz/douyu1.php?id=3637765
斗鱼电影HD20,http://zzy-789.xyz/douyu1.php?id=10395991
斗鱼电影HD21,http://zzy-789.xyz/douyu1.php?id=10395986
斗鱼电影HD22,http://124.223.212.38:83/douyu/252802
斗鱼电影HD23,http://zzy-789.xyz/douyu1.php?id=252802
斗鱼电影HD24,http://124.223.212.38:83/douyu/6079455
斗鱼电影HD24,http://zzy-789.xyz/douyu1.php?id=6079455
斗鱼电影HD25,http://124.223.212.38:83/douyu/315131
斗鱼电影HD25,http://diyp.112114.xyz/douyu/315131
斗鱼电影HD26,http://124.223.212.38:83/douyu/8945323
斗鱼电影HD26,http://zzy-789.xyz/douyu1.php?id=8945323
斗鱼电影HD27,http://124.223.212.38:83/douyu/2516864
斗鱼电影HD28,http://zzy-789.xyz/douyu1.php?id=2516864
斗鱼电影HD29,http://124.223.212.38:83/douyu/248753
斗鱼电影HD29,http://zzy-789.xyz/douyu1.php?id=248753
斗鱼电影HD30,http://124.223.212.38:83/douyu/4332
斗鱼电影HD31,http://zzy-789.xyz/douyu1.php?id=4332
斗鱼电影HD32,http://124.223.212.38:83/douyu/9651304
斗鱼电影HD32,http://zzy-789.xyz/douyu1.php?id=9651304
斗鱼电影HD33,http://124.223.212.38:83/douyu/9650887
斗鱼电影HD34,http://zzy-789.xyz/douyu1.php?id=9650887
斗鱼电影HD35,http://124.223.212.38:83/douyu/8814650
斗鱼电影HD35,http://zzy-789.xyz/douyu1.php?id=8814650
斗鱼电影HD36,http://zzy-789.xyz/douyu1.php?id=10240510
斗鱼电影HD37,http://zzy-789.xyz/douyu1.php?id=52787
斗鱼电影HD38,http://124.223.212.38:83/douyu/8985415
斗鱼电影HD39,http://zzy-789.xyz/douyu1.php?id=1165374
斗鱼电影HD40,http://zzy-789.xyz/douyu1.php?id=1735337
斗鱼电影HD41,http://zzy-789.xyz/douyu1.php?id=1226741
斗鱼电影HD42,http://zzy-789.xyz/douyu1.php?id=59612
斗鱼电影1,http://zzy-789.xyz/douyu1.php?id=2935323
斗鱼电影2,http://124.223.212.38:83/douyu/6027991
斗鱼电影3,http://124.223.212.38:83/douyu/4105989
斗鱼电影4,http://124.223.212.38:83/douyu/6369954
斗鱼电影5,http://124.223.212.38:83/douyu/2793084
斗鱼电影6,http://124.223.212.38:83/douyu/434971
斗鱼电影7,http://124.223.212.38:83/douyu/7494871
斗鱼电影8,http://124.223.212.38:83/douyu/74374
斗鱼电影9,http://124.223.212.38:83/douyu/4870914
斗鱼电影9,http://zzy-789.xyz/douyu1.php?id=4870914
斗鱼电影10,http://124.223.212.38:83/douyu/7305938
斗鱼电影10,http://zzy-789.xyz/douyu1.php?id=7305938
斗鱼电影11,http://124.223.212.38:83/douyu/310926
斗鱼电影12,http://zzy-789.xyz/douyu1.php?id=310926
斗鱼电影13,http://124.223.212.38:83/douyu/9292499
斗鱼电影13,http://zzy-789.xyz/douyu1.php?id=9292499
斗鱼电影14,http://124.223.212.38:83/douyu/3637778
斗鱼电影15,http://124.223.212.38:83/douyu/8603174
斗鱼电影16,http://zzy-789.xyz/douyu1.php?id=96577
斗鱼电影16,http://diyp.112114.xyz/douyu/96577
斗鱼电影17,http://124.223.212.38:83/douyu/4282654
斗鱼电影18,http://124.223.212.38:83/douyu/338759
斗鱼电影20,http://124.223.212.38:83/douyu/9275635
斗鱼电影21,http://124.223.212.38:83/douyu/5581257
斗鱼电影22,http://zzy-789.xyz/douyu1.php?id=2466104
斗鱼电影25,http://124.223.212.38:83/douyu/9826611
斗鱼电影26,http://zzy-789.xyz/douyu1.php?id=4505431
斗鱼电影29,http://124.223.212.38:83/douyu/315457
斗鱼电影31,http://124.223.212.38:83/douyu/6655271
斗鱼电视剧HD1,http://124.223.212.38:83/douyu/2838296
斗鱼电视剧HD1,http://zzy-789.xyz/douyu1.php?id=2838296
斗鱼电视剧HD2,http://124.223.212.38:83/douyu/7701735
斗鱼电视剧HD2,http://zzy-789.xyz/douyu1.php?id=7701735
斗鱼电视剧HD4,http://124.223.212.38:83/douyu/7489563
斗鱼电视剧HD4,http://zzy-789.xyz/douyu1.php?id=7489563
斗鱼电视剧HD5,http://124.223.212.38:83/douyu/6566658
斗鱼电视剧HD5,http://zzy-789.xyz/douyu1.php?id=6566658
斗鱼电视剧HD6,http://124.223.212.38:83/douyu/431460
斗鱼电视剧HD7,http://zzy-789.xyz/douyu1.php?id=431460
斗鱼电视剧HD8,http://zzy-789.xyz/douyu1.php?id=8600645
斗鱼电视剧HD9,http://zzy-789.xyz/douyu1.php?id=7575350
斗鱼电视剧HD10,http://zzy-789.xyz/douyu1.php?id=7644931
斗鱼电视剧HD11,http://zzy-789.xyz/douyu1.php?id=9650860
斗鱼电视剧HD12,http://zzy-789.xyz/douyu1.php?id=3756989
斗鱼电视剧HD13,http://zzy-789.xyz/douyu1.php?id=6706214
斗鱼电视剧HD14,http://124.223.212.38:83/douyu/6706214
斗鱼电视剧1,http://zzy-789.xyz/douyu1.php?id=299854
斗鱼电视剧2,http://124.223.212.38:83/douyu/6899895
斗鱼电视剧2,http://zzy-789.xyz/douyu1.php?id=6899895
斗鱼电视剧3,http://124.223.212.38:83/douyu/276200
斗鱼电视剧3,http://zzy-789.xyz/douyu1.php?id=276200
斗鱼电视剧4,http://zzy-789.xyz/douyu1.php?id=4290711
斗鱼电视剧5,http://124.223.212.38:83/douyu/6648727
斗鱼电视剧6,http://124.223.212.38:83/douyu/7314294
斗鱼电视剧6,http://zzy-789.xyz/douyu1.php?id=7314294
斗鱼电视剧7,http://124.223.212.38:83/douyu/9638983
斗鱼电视剧7,http://zzy-789.xyz/douyu1.php?id=9638983

🍊虎牙,#genre#
铁齿铜ya纪晓岚 经典铁三角组合 - 小木子先生丶,http://61.241.131.18/tx.rtmp.huya.com/1394565204-1394565204-5989611943319568384-2789253864-10057-A-0-1-imgplus.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
滚滚长江东逝水 - 鯎爺,http://61.241.131.18/tx.rtmp.huya.com/1423787831-1423787831-6115122170587774976-2847699118-10057-A-0-1-imgplus.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
英叔护体 | 林正英搞笑僵尸系列 - 7喜先生,http://61.241.131.18/tx.rtmp.huya.com/1394575543-1394575543-5989656348986441728-2789274542-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
湾偶像剧：更新微笑百事达 - 瞬间爆炸,http://61.241.131.18/tx.rtmp.huya.com/1423787860-1423787860-6115122295141826560-2847699176-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
新水hu·在下正是西公子！ - 鱼塘塘主张年年,http://61.241.131.18/tx.rtmp.huya.com/1394565188-1394565188-5989611874600091648-2789253832-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
康熙·民间私访 - 裸奔的蜗牛╮,http://61.241.131.18/tx.rtmp.huya.com/1250011-1250011-5368756364640256-2789274536-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
实业救国、自强不息 - 我是詹密,http://61.241.131.18/tx.rtmp.huya.com/1448738195-1448738195-6222283167991070720-2789274594-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
看孙悟空唐三藏取西经 - TVB官方,http://61.241.131.18/tx.rtmp.huya.com/1199561181026-1199561181026-5434445492840824832-2399122485508-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
你怎么穿着品如的衣服 - 萌新司机,http://61.241.131.18/tx.rtmp.huya.com/1449698864-1449698864-6226409209928351744-2847687540-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
封神榜-重生之超级莲藕人 - 普通司机小马,http://61.241.131.18/tx.rtmp.huya.com/1199561158071-1199561158071-5434346901866545152-2399122439598-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
出国还是继续中考，你选择哪个？ - Wang-我的女人,http://61.241.131.18/tx.rtmp.huya.com/1448737923-1448737923-6222281999759966208-2847699110-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
官场大佬再创业 - 凌莲,http://61.241.131.18/tx.rtmp.huya.com/1524439854-1524439854-6547419317649014784-3049003164-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【经典】桃园结义三兄弟 - 全优少年,http://61.241.131.18/tx.rtmp.huya.com/1524439845-1524439845-6547419278994309120-3049003146-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
看宋世杰如何替百姓申冤 - 大懒猫,http://61.241.131.18/tx.rtmp.huya.com/1524434091-1524434091-6547394565752487936-3048991638-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
通讯班快集合·开炮啦 - 勞資ヽ尐爺,http://61.241.131.18/tx.rtmp.huya.com/1394575560-1394575560-5989656422000885760-2789274576-10057-A-0-1-imgplus.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
神貂侠侣·小笼包版姑姑上线 - 老王夸我帅,http://61.241.131.18/tx.rtmp.huya.com/1423787869-1423787869-6115122333796532224-2847699194-10057-A-0-1-imgplus.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
六大门派围攻光明顶·马甲掉了 - 不发威当我Kitty,http://61.241.131.18/tx.rtmp.huya.com/1394565214-1394565214-5989611986269241344-2789253884-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
张卫健版西游记-当蜘蛛精看上了齐天大圣 - 我是靓宝,http://61.241.131.18/tx.rtmp.huya.com/1199561182641-1199561182641-5434452429213007872-2399122488738-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
你还记得大明湖畔的夏雨荷吗？ - 童可可,http://61.241.131.18/tx.rtmp.huya.com/1423787874-1423787874-6115122355271368704-2847699204-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
神医必备 红烧狮子头 - 粉娘,http://61.241.131.18/tx.rtmp.huya.com/1524418104-1524418104-6547325902110326784-3048959664-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【神话】良心穿越剧 - loVe、飘零,http://61.241.131.18/tx.rtmp.huya.com/1524439835-1524439835-6547419236044636160-3049003126-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【毛骗】烧脑！街头小骗子的连环骗术！ - 二次元控,http://61.241.131.18/tx.rtmp.huya.com/1423782083-1423782083-6115097483115757568-2847687622-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【霍建华陈乔恩】令狐冲&东方不败 - 北岛南城,http://61.241.131.18/tx.rtmp.huya.com/1524418076-1524418076-6547325781851242496-3048959608-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
隋唐英雄·张卫健版程咬金 - 小轩,http://61.241.131.18/tx.rtmp.huya.com/59087345-59087345-253778214382469120-2847687592-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
楚汉骄雄-我恨做皇后 但我做刘邦的皇后 - 埋堆堆官方,http://61.241.131.18/tx.rtmp.huya.com/1199561177177-1199561177177-5434428961511702528-2399122477810-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【二炮】宁舍自己不舍兄弟 - 地狱ヽ妖妖,http://61.241.131.18/tx.rtmp.huya.com/1423782021-1423782021-6115097216827785216-2847687498-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【春秋战国】乱世出英雄 - 漓江塔景区售票阿姨,http://61.241.131.18/tx.rtmp.huya.com/1524439846-1524439846-6547419283289276416-3049003148-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【女神系列】邱淑贞 王祖贤 张曼玉 - 槽老师,http://61.241.131.18/tx.rtmp.huya.com/1388451591-1388451591-5963354175424167936-2777026638-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
和我一起打怪兽 - 小军迷,http://61.241.131.18/tx.rtmp.huya.com/1423782080-1423782080-6115097470230855680-2847687616-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【怒火重案】放映厅周四晚首映！ - 虎牙放映厅,http://61.241.131.18/tx.rtmp.huya.com/1524439840-1524439840-6547419257519472640-3049003136-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
便利贴女孩的阴差阳错 - 小妖孽,http://61.241.131.18/tx.rtmp.huya.com/1449584504-1449584504-6225918037468381184-3049003172-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
旋风球技 学踢球吗？ - 包蛋超人,http://61.241.131.18/tx.rtmp.huya.com/1394565208-1394565208-5989611960499437568-2789253872-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]人
【镖行天下】使命必达 - 世界格斗场,http://61.241.131.18/tx.rtmp.huya.com/1449574253-1449574253-6225874009758629888-2847699210-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
喜剧人搞笑上演东北版让子弹飞 - 柠檬树下你和我,http://61.241.131.18/tx.rtmp.huya.com/1423782056-1423782056-6115097367151640576-2847687568-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
王宝强系列·既分高下，也决生死 - 沐小错,http://61.241.131.18/tx.rtmp.huya.com/1423787852-1423787852-6115122260782088192-2847699160-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【怀念金庸】金庸作品电影集 - 汽车人,http://61.241.131.18/tx.rtmp.huya.com/1449584124-1449584124-6225916405380808704-2847687586-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
快意江湖：金庸的武侠世界 - 可爱的小强,http://61.241.131.18/tx.rtmp.huya.com/1394575562-1394575562-5989656430590820352-2789274580-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
舒克和贝塔·我有一个大飞机 - Fighter,http://61.241.131.18/tx.rtmp.huya.com/1423787843-1423787843-6115122222127382528-2847699142-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
川军悍将 - 威猛先生,http://61.241.131.18/tx.rtmp.huya.com/1250011-1250011-5368756364640256-2789274540-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
那些年我们追过的港片女神? - 苦瓜老姨,http://61.241.131.18/tx.rtmp.huya.com/1449698962-1449698962-6226409630835146752-2789274564-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【宝lian灯】二舅子：我太难了 - 美少女咸儿,http://61.241.131.18/tx.rtmp.huya.com/1340763124-1340763124-5758533769262792704-2777026902-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
胭脂雪中缘起缘灭 - 心疼得抱住胖胖的自己,http://61.241.131.18/tx.rtmp.huya.com/1394575548-1394575548-5989656370461278208-2789274552-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【南拳北腿】主题曲是真的好听啊！ - 是大宝贝呀,http://61.241.131.18/tx.rtmp.huya.com/1199561226091-1199561226091-5434639045542019072-2399122575638-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
《状王宋世杰》第二部·张达明大战黄子华 - 一起来埋堆,http://61.241.131.18/tx.rtmp.huya.com/1199561462555-1199561462555-5435654650688700416-2399123048566-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
天地争霸美猴王粤语版 - 我叫山鸡哥,http://61.241.131.18/tx.rtmp.huya.com/1199561277686-1199561277686-5434860644379656192-2399122678828-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
秀才遇到兵-演喜剧的陈豪，我可以！ - Amy姐,http://61.241.131.18/tx.rtmp.huya.com/1199561176240-1199561176240-5434424937127346176-2399122475936-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【秋香怒点唐伯虎】不要啊！ 秋香姐！ - TVB古装大片,http://61.241.131.18/tx.rtmp.huya.com/1199563481163-1199563481163-5444324506032144384-2399127085782-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【TVB】惹下穴债，住进难民营！ - TVB浪姐,http://61.241.131.18/tx.rtmp.huya.com/1199563478721-1199563478721-5444314017722007552-2399127080898-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
婆媳间传统和现代的碰撞 - 包租婆不停水,http://61.241.131.18/tx.rtmp.huya.com/1099531752762-1099531752762-86436156702457856-2199063628980-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
平安谷之诡谷传说 平安谷的妇仇者联盟 - 油麻地糖水铺,http://61.241.131.18/tx.rtmp.huya.com/1199561245453-1199561245453-5434722204698804224-2399122614362-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
铁嘴银牙-陈小春爆笑公堂 - 我叫Laughing哥,http://61.241.131.18/tx.rtmp.huya.com/1199561277694-1199561277694-5434860678739394560-2399122678844-10057-A-0-1
【TVB】爱是一道光，X到你发慌 - 粤爱看港片,http://61.241.131.18/tx.rtmp.huya.com/1199563478540-1199563478540-5444313240332926976-2399127080536-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
慈善超人合集 演技进阶史 - 喧嚣的夏风,http://61.241.131.18/tx.rtmp.huya.com/1081939992-1081939992-4646896881874501632-2164003440-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【周星星】星爷经典不间断 - 周星星,http://61.241.131.18/tx.rtmp.huya.com/1394575534-1394575534-5989656310331736064-2789274524-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
大家好 我曾小咸又回来啦 - 武林萌主唐小姐,http://61.241.131.18/tx.rtmp.huya.com/1388474069-1388474069-5963450717699047424-2777071594-10057-A-0-1-imgplus.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
极限挑战·04崇明岛生死时速 - SMG最强大脑,http://61.241.131.18/tx.rtmp.huya.com/1423782086-1423782086-6115097496000659456-2847687628-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
上海皇帝2-看陆月生最终结局 - 虎牙八点档,http://61.241.131.18/tx.rtmp.huya.com/1524439855-1524439855-6547419321943982080-3049003166-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
来看小姐姐跳舞~ - 杀马特死神,http://61.241.131.18/tx.rtmp.huya.com/1423782031-1423782031-6115097259777458176-2847687518-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【虎牙影院】李焕英循环放映~ - 虎牙影院,http://61.241.131.18/tx.rtmp.huya.com/1524418085-1524418085-6547325820505948160-3048959626-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【龙men镖局】白展堂的儿子那么大啦 - 柯冉冉,http://61.241.131.18/tx.rtmp.huya.com/1449698121-1449698121-6226406018767650816-2847687516-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【极品新娘】豆腐西施嫁给痴心憨夫 - 傻妞,http://61.241.131.18/tx.rtmp.huya.com/1394575549-1394575549-5989656374756245504-2789274554-10057-A-0-1-imgplus.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
夏雪夏雨夏冰雹 - 种瓜得弟弟,http://61.241.131.18/tx.rtmp.huya.com/1250011-1250011-5368756364640256-2847687508-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
RM 刘在石李光洙跑男 - 维达人,http://61.241.131.18/tx.rtmp.huya.com/1250011-1250011-5368756364640256-2777071322-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【医馆笑传】陈赫x张子萱 oh天长地久 - 加班狗,http://61.241.131.18/tx.rtmp.huya.com/1449698185-1449698185-6226406293645557760-2847687566-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
搞笑的一家人 - No1常在心,http://61.241.131.18/tx.rtmp.huya.com/1394565211-1394565211-5989611973384339456-2789253878-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
傅艺伟版封神演义 - 我要在你头上暴扣,http://61.241.131.18/tx.rtmp.huya.com/1524418108-1524418108-6547325919290195968-3048959672-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
一代经典星爷，难以超越 - 莫小辰,http://61.241.131.18/tx.rtmp.huya.com/1449698986-1449698986-6226409733914361856-2847687634-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
大江 王凯杨烁董子健 经典好剧 - 大侠,http://61.241.131.18/tx.rtmp.huya.com/1250011-1250011-5368756364640256-3049003162-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
超哥.what are you弄啥哩 - 红茶妹妹,http://61.241.131.18/tx.rtmp.huya.com/1388457235-1388457235-5963378416219586560-2777037926-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【五福星】每天都要快乐哦 - 樹袋熊小九九,http://61.241.131.18/tx.rtmp.huya.com/1356780980-1356780980-5827329936934830080-2713685416-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
历年贺岁档 笑就完事儿了 - 浮生没有若梦,http://61.241.131.18/tx.rtmp.huya.com/1524418118-1524418118-6547325962239868928-3048959692-10057-A-0-1-imgplus.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
笑傲帮 顶尖笑匠再登舞台 - SMG开怀时刻,http://61.241.131.18/tx.rtmp.huya.com/1449380946-1449380946-6225043762515542016-2847687614-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
歪果喜剧人也超有意思 - 四大裁子之首,http://61.241.131.18/tx.rtmp.huya.com/1524434111-1524434111-6547394651651833856-3048991678-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
美食纪录片·饿了吗？ - -若凌Provence-,http://61.241.131.18/tx.rtmp.huya.com/1423787851-1423787851-6115122256487120896-2847699158-10057-A-0-1-imgplus.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
粤语专场 经典喜剧片 - 飙车的老司机,http://61.241.131.18/tx.rtmp.huya.com/1448686695-1448686695-6222061977175326720-2847687574-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我去过的那些地方和我们没了的地方 - 葱花,http://61.241.131.18/tx.rtmp.huya.com/1449588790-1449588790-6225936445698211840-2847699106-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【许氏三杰】快来 就差你了 - 科技这样玩,http://61.241.131.18/tx.rtmp.huya.com/1524434070-1524434070-6547394475558174720-3048991596-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
喜剧脱口秀 笑傲江湖 - SMG爆笑舞台,http://61.241.131.18/tx.rtmp.huya.com/1423787824-1423787824-6115122140523003904-2847699104-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
港剧经典：成奎安喜剧合集 - 笙歌,http://61.241.131.18/tx.rtmp.huya.com/1423787870-1423787870-6115122338091499520-2847699196-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
你能猜到结局吗？ - 邻家少女,http://61.241.131.18/tx.rtmp.huya.com/1423782037-1423782037-6115097285547261952-2847687530-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
浓浓当年情 - -小癲,http://61.241.131.18/tx.rtmp.huya.com/1524439823-1524439823-6547419184505028608-3049003102-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【喜剧专场】我们一起找乐子 - 小怪兽、,http://61.241.131.18/tx.rtmp.huya.com/1524434089-1524434089-6547394557162553344-3048991634-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
今晚80后脱口秀162我的父亲母亲下 - SMG吐槽担当,http://61.241.131.18/tx.rtmp.huya.com/1423787862-1423787862-6115122303731761152-2847699180-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
够劲，就是中国功夫 - 初心,http://61.241.131.18/tx.rtmp.huya.com/1448738174-1448738174-6222283077796757504-2847699112-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
黄渤合集·影帝秀 - yoo,http://61.241.131.18/tx.rtmp.huya.com/1448737849-1448737849-6222281681932386304-2847687520-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
中国西部刑侦大案纪实 - 苏仨,http://61.241.131.18/tx.rtmp.huya.com/1524418094-1524418094-6547325859160653824-3048959644-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
童年神剧·马小玲的大长腿 - 假装,http://61.241.131.18/tx.rtmp.huya.com/1449698104-1449698104-6226405945753206784-2847699140-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【杨门女将电影系列】女儿当自强 - 羞涩的茄子,http://61.241.131.18/tx.rtmp.huya.com/1448737814-1448737814-6222281531608530944-2777037662-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
梦立方·益智闯关秀 - SMG梦想成真,http://61.241.131.18/tx.rtmp.huya.com/1524434092-1524434092-6547394570047455232-3048991640-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
中?国?新?相?亲?·大?型?男?女?口?嗨?现?场 - SMG胖月老,http://61.241.131.18/tx.rtmp.huya.com/1449574865-1449574865-6225876638278615040-2847699130-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
喜剧合家欢，开心一整天！ - 牙缝多了根青菜,http://61.241.131.18/tx.rtmp.huya.com/1420969427-1420969427-6103017217580859392-2847687524-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
迪迦奥特曼 - 嫣然,http://61.241.131.18/tx.rtmp.huya.com/1524418101-1524418101-6547325889225424896-3048959658-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
周星星粤语经典版~ - Yummy,http://61.241.131.18/tx.rtmp.huya.com/1250011-1250011-5368756364640256-2777036638-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
贝爷上线 开饭啦开饭啦 - 来瓶肥宅水,http://61.241.131.18/tx.rtmp.huya.com/1099531752750-1099531752750-86436105162850304-2199063628956-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
河东狮吼-关咏荷的绝世美颜 - 万千星辉来吹水,http://61.241.131.18/tx.rtmp.huya.com/1199563493628-1199563493628-5444378042799489024-2399127110712-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
ri本整人可真有一套 - 狂野女孩i了吗,http://61.241.131.18/tx.rtmp.huya.com/1099531752754-1099531752754-86436122342719488-2199063628964-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
哥哥 大家都很想你 - 老雷,http://61.241.131.18/tx.rtmp.huya.com/1448738325-1448738325-6222283726336819200-3048991600-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
成龙经典武打动作片 - 偷心大盗ヽ龍宝,http://61.241.131.18/tx.rtmp.huya.com/1394565191-1394565191-5989611887484993536-2789253838-10057-A-0-1-imgplus.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
刘德华电影_经典系列 - 安逗和黑仔,http://61.241.131.18/tx.rtmp.huya.com/1394575547-1394575547-5989656366166310912-2789274550-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
李连杰系列 武打高产王 - 核桃姐姐,http://61.241.131.18/tx.rtmp.huya.com/1394565196-1394565196-5989611908959830016-2789253848-10057-A-0-1-imgplus.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
经典好片这里都有，往里进~ - 逗比宝宝,http://61.241.131.18/tx.rtmp.huya.com/1394575551-1394575551-5989656383346180096-2789274558-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【警匪】不会演戏的警察不是好卧底 - 学妹爱学长,http://61.241.131.18/tx.rtmp.huya.com/1423782050-1423782050-6115097341381836800-2847687556-10057-A-0-1-imgplus.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【黑帮大片】山鸡哥重现江湖 - 蓶1淳爷,http://61.241.131.18/tx.rtmp.huya.com/1388472589-1388472589-5963444361147449344-2777068634-10057-A-0-1-imgplus.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
经典高智商犯罪片 - 小牡蛎,http://61.241.131.18/tx.rtmp.huya.com/1423787865-1423787865-6115122316616663040-2847699186-10057-A-0-1-imgplus.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
杰森·斯坦森:郭达是你吗 - 超人的归来,http://61.241.131.18/tx.rtmp.huya.com/1099531752779-1099531752779-86436229716901888-2199063629014-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
怀玉格格 湾湾版还珠格格 - 吞针主播,http://61.241.131.18/tx.rtmp.huya.com/1423782052-1423782052-6115097349971771392-2847687560-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
黑帮斗争 黑与白的对峙，情与义的泯灭 - 麋鹿,http://61.241.131.18/tx.rtmp.huya.com/1394575541-1394575541-5989656340396507136-2789274538-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
港产搞笑·只有善良的人才看的到！！！ - 实力拔萝卜,http://61.241.131.18/tx.rtmp.huya.com/1524418070-1524418070-6547325756081438720-3048959596-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
周润发电影 小马哥归来 - 开船老湿基,http://61.241.131.18/tx.rtmp.huya.com/1394565192-1394565192-5989611891779960832-2789253840-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【科幻系列】硬核浪漫 - Fight、Girl,http://61.241.131.18/tx.rtmp.huya.com/1423782061-1423782061-6115097388626477056-2847687578-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【吴京】京哥看了都说赞 - 替你挨过揍的朋友,http://61.241.131.18/tx.rtmp.huya.com/1524434090-1524434090-6547394561457520640-3048991636-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
甄子丹 我要打十个 - 主播小贞,http://61.241.131.18/tx.rtmp.huya.com/1423787820-1423787820-6115122123343134720-2847699096-10057-A-0-1-imgplus.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
小时代1 - 我是一颗小虎牙,http://61.241.131.18/tx.rtmp.huya.com/1099531752790-1099531752790-86436276961542144-2199063629036-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
来啊！一起打爆丧尸啊！ - 还我瓢瓢拳,http://61.241.131.18/tx.rtmp.huya.com/1099531752771-1099531752771-86436195357163520-2199063628998-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
治愈佳片吹散心中的小确丧 - 皮皮皮卡卡皮卡丘,http://61.241.131.18/tx.rtmp.huya.com/1099531752785-1099531752785-86436255486705664-2199063629026-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
da宋提刑官·古代刑侦力作 - 一只大懒虫,http://61.241.131.18/tx.rtmp.huya.com/73821423-73821423-317060597529182208-2710090468-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
世界末日会到来吗？ - 我是一颗小虎牙,http://61.241.131.18/tx.rtmp.huya.com/1099531752786-1099531752786-86436259781672960-2199063629028-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
天雷滚滚 这恐怖片我看笑了 - 妖孽CC,http://61.241.131.18/tx.rtmp.huya.com/1449698763-1449698763-6226408776136654848-2847699120-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
科学怪物 - 艾薇宝贝de宝贝,http://61.241.131.18/tx.rtmp.huya.com/1099531752749-1099531752749-86436100867883008-2199063628954-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
过瘾！这些无限循环电影，烧脑停不下来！ - 北岛的诗,http://61.241.131.18/tx.rtmp.huya.com/1388457186-1388457186-5963378205766189056-2777037828-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
太空混战 | 毁灭吧，地球 - 西九龙冠希哥,http://61.241.131.18/tx.rtmp.huya.com/1099531752772-1099531752772-86436199652130816-2199063629000-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
徐老怪·狄仁杰之四大天王 - 元芳看不到,http://61.241.131.18/tx.rtmp.huya.com/1394575536-1394575536-5989656318921670656-2789274528-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
Han国高分动作片 刺激过瘾 - 长岛冰茶-,http://61.241.131.18/tx.rtmp.huya.com/1423782047-1423782047-6115097328496934912-2847687550-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
谍战系列，刺激过瘾 - 个人向,http://61.241.131.18/tx.rtmp.huya.com/1449580415-1449580415-6225900475347107840-2847699190-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
怪兽打架x异形世界：爽就完事了 - 梁非凡吃点啥,http://61.241.131.18/tx.rtmp.huya.com/1099531752770-1099531752770-86436191062196224-2199063628996-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
《情深深雨濛濛》书桓走的第一天，想他 - -惟美,http://61.241.131.18/tx.rtmp.huya.com/1449580358-1449580358-6225900230533971968-2847687552-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
文成公主进藏 - 骚年跟我来听歌,http://61.241.131.18/tx.rtmp.huya.com/1448738217-1448738217-6222283262480351232-2847699222-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
病毒类灾难电影 - Eric次元宝贝,http://61.241.131.18/tx.rtmp.huya.com/1099531752747-1099531752747-86436092277948416-2199063628950-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
电ju惊魂系列 好怕怕 - 胖次过肩摔,http://61.241.131.18/tx.rtmp.huya.com/1423782074-1423782074-6115097444461051904-2847687604-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
虚假！活在这种世界里。。。 - 我是一颗小虎牙,http://61.241.131.18/tx.rtmp.huya.com/1099531752791-1099531752791-86436281256509440-2199063629038-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
测试 - 状元及第粥,http://61.241.131.18/tx.rtmp.huya.com/1099531752774-1099531752774-86436208242065408-2199063629004-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【国产青春爱情】致青春 - 性感大妈,http://61.241.131.18/tx.rtmp.huya.com/1524439836-1524439836-6547419240339603456-3049003128-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
神hua·穿越过去泡韩妞 - 来听歌呀,http://61.241.131.18/tx.rtmp.huya.com/1423782085-1423782085-6115097491705692160-2847687626-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
孙悟空·90后都懂~ - 铁血真汉子,http://61.241.131.18/tx.rtmp.huya.com/1250011-1250011-5368756364640256-2789253862-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
动作大片·入股不亏！ - 萌美美,http://61.241.131.18/tx.rtmp.huya.com/1449698649-1449698649-6226408286510383104-2847699168-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
最新 最hot 大大大片 - 阿汤哥的影迷,http://61.241.131.18/tx.rtmp.huya.com/1099531752778-1099531752778-86436225421934592-2199063629012-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
萧峰、虚竹、段誉的江湖生涯 - 迷失,http://61.241.131.18/tx.rtmp.huya.com/1524434083-1524434083-6547394531392749568-3048991622-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
警匪犯罪·现在我想做一个好人 - 阿森木木木,http://61.241.131.18/tx.rtmp.huya.com/1449581589-1449581589-6225905517638713344-3048959636-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
徐峥合集·笑一个呗 - 酒窝储存机,http://61.241.131.18/tx.rtmp.huya.com/1524434085-1524434085-6547394539982684160-3048991626-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
贞子重生 - 我是一颗小虎牙,http://61.241.131.18/tx.rtmp.huya.com/1099531752789-1099531752789-86436272666574848-2199063629034-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
利箭特战队出击！ - 一片青青草原,http://61.241.131.18/tx.rtmp.huya.com/1423787882-1423787882-6115122389631107072-2847699220-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
值得一看！You jump，I jump！ - 千与千寻的思考,http://61.241.131.18/tx.rtmp.huya.com/1099531752783-1099531752783-86436246896771072-2199063629022-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
杰森斯坦森硬汉动作片 - 里昂保护的玛蒂达,http://61.241.131.18/tx.rtmp.huya.com/1099531752784-1099531752784-86436251191738368-2199063629024-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
张卫健与郭晋安闯荡江湖的奇异之事 - 暴走君丶阿罪,http://61.241.131.18/tx.rtmp.huya.com/1394575546-1394575546-5989656361871343616-2789274548-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【赛车电影】秋名山我来了 - 昔日女神柳清茶-,http://61.241.131.18/tx.rtmp.huya.com/1354978385-1354978385-5819587850361896960-2710080226-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
好莱坞挑大梁的史皇威尔 - 周星星梦里的朱茵,http://61.241.131.18/tx.rtmp.huya.com/1099531752780-1099531752780-86436234011869184-2199063629016-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
古今大战僵尸情 - 我是一颗小虎牙,http://61.241.131.18/tx.rtmp.huya.com/1099531752788-1099531752788-86436268371607552-2199063629032-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
瞬间炸裂！超燃开场 - 阿飞,http://61.241.131.18/tx.rtmp.huya.com/1423787819-1423787819-6115122119048167424-2847699094-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
这才是赛车哇 - 炙恋兽兽,http://61.241.131.18/tx.rtmp.huya.com/1448731701-1448731701-6222255276473450496-2789274560-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
魔法世界，经费在燃烧的大制作！ - 喜来乐狮子头,http://61.241.131.18/tx.rtmp.huya.com/1099531752773-1099531752773-86436203947098112-2199063629002-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
反转又反转！高智商的集合了 - 大铁锅炖大大鹅,http://61.241.131.18/tx.rtmp.huya.com/1099531752768-1099531752768-86436182472261632-2199063628992-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【命案十三宗】十三宗真实案件 - 小蘑菇,http://61.241.131.18/tx.rtmp.huya.com/1449588725-1449588725-6225936166525337600-3048959678-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
看时紧张到手出汗的救援电影 - 鲨手不太冷的影迷,http://61.241.131.18/tx.rtmp.huya.com/1099531752777-1099531752777-86436221126967296-2199063629010-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 辰乐-NCTDREAM,http://61.241.131.18/tx.rtmp.huya.com/2493730193-2493730193-10710489623982768128-4987583842-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 志晟-NCTDREAM,http://61.241.131.18/tx.rtmp.huya.com/2487318442-2487318442-10682951363127672832-4974760340-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 渽民-NCTDREAM,http://61.241.131.18/tx.rtmp.huya.com/2487318471-2487318471-10682951487681724416-4974760398-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 仁俊-NCTDREAM,http://61.241.131.18/tx.rtmp.huya.com/2487406583-2487406583-10683329925840109568-4974936622-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - EXO-世勋,http://61.241.131.18/tx.rtmp.huya.com/2295245222-2295245222-9858003164790259712-4590613900-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【SM超级偶像联赛】SUNNY接受惩罚 惹人喜爱 - 少女时代-Sunny,http://61.241.131.18/tx.rtmp.huya.com/1447745616-1447745616-6218020073647374336-4917028504-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
SM偶像联赛少女时代特辑第一期-泰妍（下） - 少女时代-泰妍,http://61.241.131.18/tx.rtmp.huya.com/1447745595-1447745595-6218019983453061120-4916946746-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 帝努-NCTDREAM,http://61.241.131.18/tx.rtmp.huya.com/2493730640-2493730640-10710491543833149440-4987584736-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
主播爱吃鸡-明星篇伯贤世勋篇06期：伯贤毒圈盲狙暴击，世勋98k千里杀敌 - E,http://61.241.131.18/tx.rtmp.huya.com/1421004395-1421004395-6103167403997265920-4590089046-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - WayV-刘扬扬,http://61.241.131.18/tx.rtmp.huya.com/1099531768096-1099531768096-86502015730974720-2199063659648-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
黄金搭档 双炫登场 - NUEST-旼炫,http://61.241.131.18/tx.rtmp.huya.com/1099531728481-1099531728481-86331870601543680-2199063580418-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
R1SE何洛洛 - R1SE-何洛洛,http://61.241.131.18/tx.rtmp.huya.com/1099531742285-1099531742285-86391158330097664-2199063608026-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
SM超级偶像联赛-希澈与你在一起 - SuperJunior-希澈,http://61.241.131.18/tx.rtmp.huya.com/1099531728477-1099531728477-86331853421674496-2199063580410-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【回放】SJ-银赫 心心念念不说再见 - SuperJunior-银赫,http://61.241.131.18/tx.rtmp.huya.com/1099531728478-1099531728478-86331857716641792-2199063580412-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
黄金搭档 双炫登场 - NUEST-JR,http://61.241.131.18/tx.rtmp.huya.com/1099531728480-1099531728480-86331866306576384-2199063580416-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - WayV-钱锟,http://61.241.131.18/tx.rtmp.huya.com/1099531768091-1099531768091-86501994256138240-2199063659638-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
R1SE少年_收官之战 - R1SE-张颜齐,http://61.241.131.18/tx.rtmp.huya.com/1099531742286-1099531742286-86391162625064960-2199063608028-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【回放】SM超级偶像联赛-灿烈与你在一起 - EXO-灿烈,http://61.241.131.18/tx.rtmp.huya.com/1099531728479-1099531728479-86331862011609088-2199063580414-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【回放】 WayV-董思成御风少年 - WayV-董思成,http://61.241.131.18/tx.rtmp.huya.com/1099531768092-1099531768092-86501998551105536-2199063659640-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
R1SE-赵磊 - R1SE-赵磊,http://61.241.131.18/tx.rtmp.huya.com/1099531742287-1099531742287-86391166920032256-2199063608030-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【TVB】杨家将！男女大战，血汗淋漓！ - TVBaby,http://61.241.131.18/tx.rtmp.huya.com/1199563479615-1199563479615-5444317857422770176-2399127082686-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
水浒无间道-张智霖的现代版水浒 - 小喇叭佩囍,http://61.241.131.18/tx.rtmp.huya.com/1199563461114-1199563461114-5444238396232826880-2399127045684-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
荃加福禄寿探案·太短了太短了！不过瘾！ - 石敢当本当,http://61.241.131.18/tx.rtmp.huya.com/1199561181108-1199561181108-5434445845028143104-2399122485672-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
情事缉私档案-郭晋安郭蔼明的爱恨情仇 - TVB追剧小能手,http://61.241.131.18/tx.rtmp.huya.com/1199563491137-1199563491137-5444367344035954688-2399127105730-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【倚天屠龙记】梁朝伟版张无忌 - 嫩模下厨房,http://61.241.131.18/tx.rtmp.huya.com/1199561276760-1199561276760-5434856667239940096-2399122676976-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【先生贵性】缘分冥冥中连在一起 - 娥姐来了,http://61.241.131.18/tx.rtmp.huya.com/1199561276781-1199561276781-5434856757434253312-2399122677018-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【骑呢大状】散漫公子变身著名状师 - 港剧影视汇,http://61.241.131.18/tx.rtmp.huya.com/1199564061580-1199564061580-5446817378065186816-2399128246616-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
食为奴·王祖蓝的嘴万绮雯的腿 - 香港刑侦实录,http://61.241.131.18/tx.rtmp.huya.com/1199563479466-1199563479466-5444317217472643072-2399127082388-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
律政新人王-林峯胡杏儿的律政CP - TV八哥,http://61.241.131.18/tx.rtmp.huya.com/1199563492830-1199563492830-5444374615415586816-2399127109116-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【TVB】霸霸去哪了？？？ - 港剧日日见,http://61.241.131.18/tx.rtmp.huya.com/1199563459301-1199563459301-5444230609457119232-2399127042058-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
爱·回家，经典之作 - TVB爱情故事,http://61.241.131.18/tx.rtmp.huya.com/1199563478941-1199563478941-5444314962614812672-2399127081338-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
宝芝林 刘德华蓝洁瑛青涩古装剧 - 杨过的挂耳染,http://61.241.131.18/tx.rtmp.huya.com/1199561179116-1199561179116-5434437289453289472-2399122481688-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
降魔的-高能 都市司机化身降魔大师 - 鸡公碗,http://61.241.131.18/tx.rtmp.huya.com/1199561278783-1199561278783-5434865355958779904-2399122681022-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
心慌?心郁?逐个捉 平凡小镇暗藏杀机 - 为所欲为的微笑,http://61.241.131.18/tx.rtmp.huya.com/1199561218716-1199561218716-5434607370158211072-2399122560888-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
决战玄武门·黄日华翁梦玲射雕原班人马 - 采茶大师,http://61.241.131.18/tx.rtmp.huya.com/1199561153241-1199561153241-5434326157174505472-2399122429938-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【TVB港片】你开马自达肯定塞车！ - 港片看不停,http://61.241.131.18/tx.rtmp.huya.com/1199563491091-1199563491091-5444367146467459072-2399127105638-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
憨夫成龙-郭晋安演傻子的不归路 - 港剧连连看,http://61.241.131.18/tx.rtmp.huya.com/1199563489752-1199563489752-5444361395506249728-2399127102960-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【飞虎队】Calling 飞虎队！ - 经典港片轮播,http://61.241.131.18/tx.rtmp.huya.com/1199563479483-1199563479483-5444317290487087104-2399127082422-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【天龙八部】我最爱的黄日华版 - 堆堆看港剧,http://61.241.131.18/tx.rtmp.huya.com/1199563995848-1199563995848-5446535061274886144-2399128115152-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【qia同学少年】风华正茂 - 痞子帅叔叔,http://61.241.131.18/tx.rtmp.huya.com/1250011-1250011-5368756364640256-2789274572-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是谢飞机 别扒拉我 - 我爱黑科技,http://61.241.131.18/tx.rtmp.huya.com/1524439828-1524439828-6547419205979865088-3049003112-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
许三多军营成长史 - 领带哥,http://61.241.131.18/tx.rtmp.huya.com/1394575555-1394575555-5989656400526049280-2789274566-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
狄仁杰：元芳 你怎么看？ - 昵称违规-QQFbPxwM1A,http://61.241.131.18/tx.rtmp.huya.com/1423787855-1423787855-6115122273666990080-2847699166-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
火凤凰女子特战队 - 母胎solo二百年,http://61.241.131.18/tx.rtmp.huya.com/1524418114-1524418114-6547325945059999744-3048959684-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
秀cai遇着兵 - 會唱歌的小野貓,http://61.241.131.18/tx.rtmp.huya.com/1423782025-1423782025-6115097234007654400-2847687506-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
童年回忆 六组的案子太多了 - yao不能停,http://61.241.131.18/tx.rtmp.huya.com/1524418106-1524418106-6547325910700261376-3048959668-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【经典】陈道明版康熙 - 四次元先生,http://61.241.131.18/tx.rtmp.huya.com/1524439831-1524439831-6547419218864766976-3049003118-10057-A-0-1-imgplus.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【欢le颂】22楼姐妹花 - 西红柿,http://61.241.131.18/tx.rtmp.huya.com/1524418105-1524418105-6547325906405294080-3048959666-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【七仙女】惊天地泣鬼神的传奇爱情故事 - 荒野达人,http://61.241.131.18/tx.rtmp.huya.com/1423787884-1423787884-6115122398221041664-2847699224-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
大宅men 白家老号百草厅 - Mr-傀儡,http://61.241.131.18/tx.rtmp.huya.com/1423787821-1423787821-6115122127638102016-2847699098-10057-A-0-1-imgplus.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
葛二蛋成长之路 - 茱麗葉,http://61.241.131.18/tx.rtmp.huya.com/1524439832-1524439832-6547419223159734272-3049003120-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
穿越千年之恋、人妖之恋 - 呆萌小岳岳,http://61.241.131.18/tx.rtmp.huya.com/1394565206-1394565206-5989611951909502976-2789253868-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【国产美人】总有一款是你的菜 - 六宫,http://61.241.131.18/tx.rtmp.huya.com/1524434097-1524434097-6547394591522291712-3048991650-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
喜欢是放肆，爱是克制 - 脑壳不太好,http://61.241.131.18/tx.rtmp.huya.com/1524434084-1524434084-6547394535687716864-3048991624-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【咱们结婚吧】高圆圆 黄海波 通宵看剧不能停 - 扫地僧,http://61.241.131.18/tx.rtmp.huya.com/1250011-1250011-5368756364640256-2789253858-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
冯小刚合集·国产佳作 - 超能力是放pi,http://61.241.131.18/tx.rtmp.huya.com/1423782077-1423782077-6115097457345953792-2847687610-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
黄金配角廖启智 翟sir走好 - 十八里铺大当家,http://61.241.131.18/tx.rtmp.huya.com/1099531752756-1099531752756-86436130932654080-2199063628968-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
精忠岳飞，南征北战 - 持枪者-土豆哥,http://61.241.131.18/tx.rtmp.huya.com/1250011-1250011-5368756364640256-2777027178-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
想去你家吃一口饭，就一口 - 冰火岛一霸,http://61.241.131.18/tx.rtmp.huya.com/1099531752757-1099531752757-86436135227621376-2199063628970-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
史诗级战zheng电影，真的刺激！ - 一只梦幻小萌虎,http://61.241.131.18/tx.rtmp.huya.com/1099531752751-1099531752751-86436109457817600-2199063628958-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
真相只有一个，凶手就是你 - 雅痞不是帅,http://61.241.131.18/tx.rtmp.huya.com/1423787848-1423787848-6115122243602219008-2847699152-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
杨幂扮演王昭君出塞 - 兜兜з,http://61.241.131.18/tx.rtmp.huya.com/1420736865-1420736865-6102018371396567040-2847687618-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【我de团长我的团】超燃抗战 - 小猪猪,http://61.241.131.18/tx.rtmp.huya.com/1394575538-1394575538-5989656327511605248-2789274532-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
杰外动画经典轮播 - 小当家动漫社,http://61.241.131.18/tx.rtmp.huya.com/1199522059586-1199522059586-5266420187468398592-2399044242628-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 徐大sao,http://61.241.131.18/tx.rtmp.huya.com/1279526634640-1279526634640-16842060248003903488-2559053392736-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 盛世-兴哥赶海【户外】,http://61.241.131.18/tx.rtmp.huya.com/2752-2752-11819749998592-2399073217026-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
动物世界【自然传奇】 - 麥l佳佳,http://61.241.131.18/tx.rtmp.huya.com/1199589619721-1199589619721-5556588757806743552-2399179362898-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 老罗,http://61.241.131.18/tx.rtmp.huya.com/1864967650-1864967650-8009975064847974400-3730058756-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 蔡成功,http://61.241.131.18/tx.rtmp.huya.com/2331938156-2331938156-10015598116314546176-4663999768-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 卢克,http://61.241.131.18/tx.rtmp.huya.com/1641342496-1641342496-7049512341855010816-3282808448-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 纳豆,http://61.241.131.18/tx.rtmp.huya.com/1509536009-1509536009-6483407790789361664-3019195474-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 元气,http://61.241.131.18/tx.rtmp.huya.com/1199542272202-1199542272202-5353232712155004928-2399084667860-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 贝利少年,http://61.241.131.18/tx.rtmp.huya.com/2243824463-2243824463-9637152686549762048-4487772382-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 小煮君,http://61.241.131.18/tx.rtmp.huya.com/2291045556-2291045556-9839965736666136576-4582214568-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - plan,http://61.241.131.18/tx.rtmp.huya.com/1766581613-1766581613-7587410253549928448-3533286682-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 陈年,http://61.241.131.18/tx.rtmp.huya.com/1259526585546-1259526585546-4729479765717680128-2519053294548-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 小浩,http://61.241.131.18/tx.rtmp.huya.com/1759798565-1759798565-7558277284222730240-3519720586-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 小文哥吃吃吃,http://61.241.131.18/tx.rtmp.huya.com/1863319167-1863319167-8002894884274962432-3726761790-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
一株小麦，变化出扎根在每个人记忆里的味道 - 李子柒,http://61.241.131.18/tx.rtmp.huya.com/1199512837905-1199512837905-5226813369159254016-2399025799266-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
加料100元的手抓饼长什么样的？老板：不想给你放饼里了！ - 记录美食的蛋黄派,http://61.241.131.18/tx.rtmp.huya.com/1449320044-1449320044-6224782190417281024-4693281080-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
冬至羊肉汤 - 山药视频,http://61.241.131.18/tx.rtmp.huya.com/1199511962590-1199511962590-5223053919860555776-2399024048636-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 非洲飞哥,http://61.241.131.18/tx.rtmp.huya.com/1199578878725-1199578878725-5510456531260276736-2399157880906-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
味美量大的口袋馍馍 装满热乎的炸串 一个吃不够！（珍惜粮食） - 梨涡少女min,http://61.241.131.18/tx.rtmp.huya.com/1099531728506-1099531728506-86331977975726080-2199063580468-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 田野上的繁荣,http://61.241.131.18/tx.rtmp.huya.com/1199579660392-1199579660392-5513813765461639168-2399159444240-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
刘三三的美食分享 - 我是三三呀,http://61.241.131.18/tx.rtmp.huya.com/1199579638223-1199579638223-5513718550331654144-2399159399902-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 山村胖哥,http://61.241.131.18/tx.rtmp.huya.com/1279517866516-1279517866516-16804401442176630784-2559035856488-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]

乡村食叔,http://61.241.131.18/tx.rtmp.huya.com/1199568026142-1199568026142-5463845042198151168-2399136175740-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
胖猴仔,http://61.241.131.18/tx.rtmp.huya.com/1199547262878-1199547262878-5374667502359937024-2399094649212-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
v_huya_1199530538005 - 密子君Mires,http://61.241.131.18/tx.rtmp.huya.com/1199530538005-1199530538005-5302834719795183616-2399061199466-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
试吃819元一只的东涛鸡，爪子有手腕这么粗，啃起来太过瘾了！ - 吃货小伟,http://61.241.131.18/tx.rtmp.huya.com/1199514161081-1199514161081-5232496366806106112-2399028445618-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
厨师长分享：黑山羊的身体结构以及每个部位的吃法 - 美食作家王刚,http://61.241.131.18/tx.rtmp.huya.com/1199541480983-1199541480983-5349834452426031104-2399083085422-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 穿毛裤的小拉泽,http://61.241.131.18/tx.rtmp.huya.com/1199566702727-1199566702727-5458161018054115328-2399133528910-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
花都兄弟 - 花都兄弟,http://61.241.131.18/tx.rtmp.huya.com/1199563023392-1199563023392-5442358394558087168-2399126170240-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
v_huya_1199532224439 - 探海渔人,http://61.241.131.18/tx.rtmp.huya.com/1199532224439-1199532224439-5310077898672046080-2399064572334-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 大蒙乡味,http://61.241.131.18/tx.rtmp.huya.com/1199531854446-1199531854446-5308488790837297152-2399063832348-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【Boki 】三明治 - Boki的搬运工,http://61.241.131.18/tx.rtmp.huya.com/2752-2752-11819749998592-2399146151840-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
冲出亚马逊的食肉兽 - 巴西精神小伙,http://61.241.131.18/tx.rtmp.huya.com/1099531729636-1099531729636-86336831288770560-2199063582728-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
v_huya_2385973811 - 原始美食与生活,http://61.241.131.18/tx.rtmp.huya.com/1449283960-1449283960-6224627210817372160-4772071078-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 搜罗大千万象奇葩美食,http://61.241.131.18/tx.rtmp.huya.com/1199576827143-1199576827143-5501645053665214464-2399153777742-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【YES小哥】深夜泡泡 吃货日记 - YES小哥,http://61.241.131.18/tx.rtmp.huya.com/1199514313264-1199514313264-5233149987814113280-2399028749984-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 越南阿晴,http://61.241.131.18/tx.rtmp.huya.com/1824002663-1824002663-7834031785401909248-3648128782-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
小伙自己在家做韩式拌饭，有韩剧那味儿了！ - Cram阿强,http://61.241.131.18/tx.rtmp.huya.com/2752-2752-11819749998592-4680145130-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
一个肘子做道凉拌猪肘，加入黄瓜凉拌，一顿饭一个肘子没压力 - 百味大彭,http://61.241.131.18/tx.rtmp.huya.com/1199524328285-1199524328285-5276164175477866496-2399048780026-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 林肉肉肉,http://61.241.131.18/tx.rtmp.huya.com/1199547248525-1199547248525-5374605856694337536-2399094620506-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
1 - 盗月社食遇记,http://61.241.131.18/tx.rtmp.huya.com/1199564802263-1199564802263-5449998587326889984-2399129727982-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
胖妹做3斤脆皮五花肉，色泽诱人，一咬嘎嘣脆，味道果然名不虚传 - 陈说美食,http://61.241.131.18/tx.rtmp.huya.com/2752-2752-11819749998592-2399147056830-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
null - 在下李灿,http://61.241.131.18/tx.rtmp.huya.com/2290122840-2290122840-9836002701622640640-4580369136-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
1 - 大师的菜,http://61.241.131.18/tx.rtmp.huya.com/1199545570494-1199545570494-5367398768427663360-2399091264444-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
东北妹子在福建厦门吃椰蛋，热心小伙多次来聊天，内心有点小激动 - 小厨娘美食记,http://61.241.131.18/tx.rtmp.huya.com/2752-2752-11819749998592-2399148428432-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
中国吃货妹妹花38元吃甜品自助，一人不限量随便吃，轻松吃回本 - 吃货圆圈圈,http://61.241.131.18/tx.rtmp.huya.com/2752-2752-11819749998592-2399147075626-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 敬汉卿,http://61.241.131.18/tx.rtmp.huya.com/1420865226-1420865226-6102569677693648896-2131475328-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 绵羊料理,http://61.241.131.18/tx.rtmp.huya.com/1199512455246-1199512455246-5225169861268733952-2399025033948-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 清然小厨,http://61.241.131.18/tx.rtmp.huya.com/1199576842155-1199576842155-5501709529714262016-2399153807766-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
阿平赶海抓了条一米长的海龙，又遇见了条大红勇鱼 - 渔民阿平,http://61.241.131.18/tx.rtmp.huya.com/2752-2752-11819749998592-2399150918000-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
二哥小虎牙,http://live
一香在草地里捡的地皮菜，用来炒鸡蛋和做汤，口感清脆爽滑 - 五阿哥美食记,http://61.241.131.18/tx.rtmp.huya.com/2270184154-2270184154-9750366697327427584-4540491764-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
霸哥、怀念、菊花《嗯！真香》第二期 - 嗯！真香,http://61.241.131.18/tx.rtmp.huya.com/1099531739647-1099531739647-86379828206370816-2199063602750-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 哈尔滨新东方烹饪学校,http://61.241.131.18/tx.rtmp.huya.com/1199529181709-1199529181709-5297009472831488000-2399058486874-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
这个“水晶锅包肉”的难度不亚于“水晶咕咾肉”复刻经典 - 东北厨子大鹏,http://61.241.131.18/tx.rtmp.huya.com/1199558447427-1199558447427-5422704774535446528-2399117018310-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
最近打算多出去吃一吃，从苏州走起 - 大E特吃,http://61.241.131.18/tx.rtmp.huya.com/1199557944544-1199557944544-5420544908496732160-2399116012544-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【溅本君】真·天蓬元帅，巨型猪耳朵你想吃吗 - 溅本尊,http://61.241.131.18/tx.rtmp.huya.com/1199532481685-1199532481685-5311182761829072896-2399065086826-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
v_huya_1199533390788 - 渝乡味小哥,http://61.241.131.18/tx.rtmp.huya.com/1199533390788-1199533390788-5315087329482768384-2399066905032-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 主厨农国栋,http://61.241.131.18/tx.rtmp.huya.com/1199539191412-1199539191412-5340000819859161088-2399078506280-10057-A-0-1
1 - 衣谷水原egg,http://61.241.131.18/tx.rtmp.huya.com/1199564868139-1199564868139-5450281522592481280-2399129859734-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
试吃24元一斤的无花果，味道甘甜，真的不开花就结果吗？ - 恰饭橘,http://61.241.131.18/tx.rtmp.huya.com/1199526545712-1199526545712-5285687951924133888-2399053214880-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
1 - 大强食堂,http://61.241.131.18/tx.rtmp.huya.com/1199566140554-1199566140554-5455746503404421120-2399132404564-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
连续使用变白神器28天，真的能白下来吗？感觉自己上当了 - 波靖仔,http://61.241.131.18/tx.rtmp.huya.com/1199566319104-1199566319104-5456513369815121920-2399132761664-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
天空飘着大雪，3个人坐在山头吃火锅，体验过的都后悔了 - 丹霞春姐,http://61.241.131.18/tx.rtmp.huya.com/1199532617570-1199532617570-5311766383460089856-2399065358596-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
乡村瑶哥户外美食 - 乡村瑶哥,http://61.241.131.18/tx.rtmp.huya.com/1199532433820-1199532433820-5310977183219449856-2399064991096-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
丈母娘来家，喷香哥炖鸡炸蒸鱼做六个菜，与妹夫喝酒，全家真高兴 - 我的幸福小生活,http://61.241.131.18/tx.rtmp.huya.com/1199571716432-1199571716432-5479694717060907008-2399143556320-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
拉布拉多犬 朵拉？你疯了吗？敢跟铲屎官抢? - 大壮和朵拉,http://61.241.131.18/tx.rtmp.huya.com/1199572287938-1199572287938-5482149316640374784-2399144699332-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
10斤重的金枪鱼头，有多大？炊二锅 弄点泡椒红焖，一家人吃过瘾 - 乡村美食炊二,http://61.241.131.18/tx.rtmp.huya.com/1199571758123-1199571758123-5479873778542444544-2399143639702-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
表妹做的辣椒炒牛肉可好吃了，你喜欢表妹还是喜欢吃她做的菜 - 广西婷表妹,http://61.241.131.18/tx.rtmp.huya.com/2752-2752-11819749998592-2399147336544-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
v_huya_1199575647814 - 石神v,http://61.241.131.18/tx.rtmp.huya.com/1199575647814-1199575647814-5496579874178990080-2399151419084-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
130个八爪鱼爆炒一脸盆，爆头一个一个，口感爽脆下酒一流 - 阿胖山,http://61.241.131.18/tx.rtmp.huya.com/2752-2752-11819749998592-2399146922728-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 吃不胖的杨肉串,http://61.241.131.18/tx.rtmp.huya.com/1199573923497-1199573923497-5489173989056053248-2399147970450-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 女胖胖,http://61.241.131.18/tx.rtmp.huya.com/1199516239078-1199516239078-5241421295962292224-2399032601612-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
v_huya_1199575776420 - 渤海二蛋,http://61.241.131.18/tx.rtmp.huya.com/2752-2752-11819749998592-2399151676296-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
海南户外赶海抓大货 - 小诗哥vlog,http://61.241.131.18/tx.rtmp.huya.com/1199531624429-1199531624429-5307500875344773120-2399063372314-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
这东西老张船上随便吃管饱，老渔民道出内幕，营养价值超高 - 渔农老张,http://61.241.131.18/tx.rtmp.huya.com/1199531827023-1199531827023-5308371009949138944-2399063777502-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
帝王蟹吃到吐，最后只能拿去给人类的好朋友 - 涛哥爱海钓,http://61.241.131.18/tx.rtmp.huya.com/1199532324568-1199532324568-5310507949452427264-2399064772592-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
油焖大虎虾，肉质甜美Q弹，这样吃海鲜太爽了 - 探野,http://61.241.131.18/tx.rtmp.huya.com/1199531668702-1199531668702-5307691026431868928-2399063460860-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
养了六个月的鱼鹰，刚下水就抓到一条5斤大货，小梁和老罗笑坏了 - 鸬鹚兄弟,http://61.241.131.18/tx.rtmp.huya.com/1199531712012-1199531712012-5307877041465458688-2399063547480-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
东北大哥另类的冰上钓鱼，引发网友热议：真有才 - 渔客阚哥,http://61.241.131.18/tx.rtmp.huya.com/1199532350155-1199532350155-5310617844780630016-2399064823766-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
v_admin_1259519911642 - 温温的露台生活,http://61.241.131.18/tx.rtmp.huya.com/1259519911642-1259519911642-4700815566301036544-2519039946740-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
100块钱学的断手魔术，给大家揭秘一下 - 我是孙少奇,http://61.241.131.18/tx.rtmp.huya.com/2752-2752-11819749998592-2399143116314-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
v_huya_1199575773659 - 南澳岛记录员彪哥,http://61.241.131.18/tx.rtmp.huya.com/1199575773659-1199575773659-5497120374338355200-2399151670774-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 老三找找筷子,http://61.241.131.18/tx.rtmp.huya.com/157616959-157616959-676959684199972864-315357374-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 川香烧烤妹,http://61.241.131.18/tx.rtmp.huya.com/1199576187436-1199576187436-5498897533021192192-2399152498328-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 海岛老二,http://61.241.131.18/tx.rtmp.huya.com/1199578011120-1199578011120-5506730196159430656-2399156145696-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 渔人乡仔,http://61.241.131.18/tx.rtmp.huya.com/1199538362796-1199538362796-5336441941238218752-2399076849048-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 胖子阿谦,http://61.241.131.18/tx.rtmp.huya.com/1199578125205-1199578125205-5507220187503394816-2399156373866-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 胖三疯,http://61.241.131.18/tx.rtmp.huya.com/1735907268-1735907268-7455664944948707328-3471937992-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 赶海二哥,http://61.241.131.18/tx.rtmp.huya.com/1199578405824-1199578405824-5508425436931031040-2399156935104-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 万仔是个大吃货,http://61.241.131.18/tx.rtmp.huya.com/2292418826-2292418826-9845863886404714496-4584961108-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 小渔村阿兴,http://61.241.131.18/tx.rtmp.huya.com/1199552137579-1199552137579-5395604183732715520-2399104398614-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 饼子李,http://61.241.131.18/tx.rtmp.huya.com/1199578817315-1199578817315-5510192777318629376-2399157758086-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 240斤的胖妈,http://61.241.131.18/tx.rtmp.huya.com/1199549311807-1199549311807-5383467585406763008-2399098747070-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 承越-三德子美食,http://61.241.131.18/tx.rtmp.huya.com/1183465386-1183465386-5082945128818016256-2367054228-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 小钟Johnny,http://61.241.131.18/tx.rtmp.huya.com/1199578964635-1199578964635-5510825511900676096-2399158052726-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
早上6点就开始排队的御梁坊红糖馒头，以及开了13年的五嫂粽子 - p孃驾到尝美食,http://61.241.131.18/tx.rtmp.huya.com/1199532707611-1199532707611-5312153106610388992-2399065538678-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
1 - 黄掌勺,http://61.241.131.18/tx.rtmp.huya.com/1449292920-1449292920-6224665693724344320-4474753278-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
农村山塘水清鱼多，大叔蚯蚓挂钩，上的全是土货 - 杰哥野钓,http://61.241.131.18/tx.rtmp.huya.com/1199527779808-1199527779808-5290988353884258304-2399055683072-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
超小厨三斤猪肉剁馅，自制30颗四川大刀丸子，夫妻俩吃肉喝汤过瘾 - 超小厨,http://61.241.131.18/tx.rtmp.huya.com/1199532390544-1199532390544-5310791314214748160-2399064904544-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 馋人老田,http://61.241.131.18/tx.rtmp.huya.com/1199578511940-1199578511940-5508881201680613376-2399157147336-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 怪蛋求生影视,http://61.241.131.18/tx.rtmp.huya.com/1199572992684-1199572992684-5485176177662361600-2399146108824-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
大梅小镇 - 大梅小镇,http://61.241.131.18/tx.rtmp.huya.com/1199522968979-1199522968979-5270326000662609920-2399046061414-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 味小五,http://61.241.131.18/tx.rtmp.huya.com/1199521888190-1199521888190-5265684047253733376-2399043899836-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 桃子姐姐,http://61.241.131.18/tx.rtmp.huya.com/1199512459284-1199512459284-5225187204346675200-2399025042024-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 章鱼,http://61.241.131.18/tx.rtmp.huya.com/1845012268-1845012268-7924267351778787328-3690147992-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
1 - 铭哥说美食,http://61.241.131.18/tx.rtmp.huya.com/1199566177608-1199566177608-5455905649122607104-2399132478672-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
v_huya_1199528126258 - 小农乡,http://61.241.131.18/tx.rtmp.huya.com/1199528126258-1199528126258-5292476345303957504-2399056375972-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
1 - 乡野小静,http://61.241.131.18/tx.rtmp.huya.com/1199531687268-1199531687268-5307770766794686464-2399063497992-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
芹菜吃了30年，这种做法第一次见，越吃越过瘾，做法简单 - 居安小农,http://61.241.131.18/tx.rtmp.huya.com/1199531673448-1199531673448-5307711410346655744-2399063470352-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
1 - 食贫道,http://61.241.131.18/tx.rtmp.huya.com/1199555330838-1199555330838-5409319126705373184-2399110785132-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
直播做山药饼 - 二姐美食,http://61.241.131.18/tx.rtmp.huya.com/1199531454998-1199531454998-5306773174740844544-2399063033452-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 乡味老段,http://61.241.131.18/tx.rtmp.huya.com/1199560479291-1199560479291-5431431563965366272-2399121082038-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 大熊迷你厨房,http://61.241.131.18/tx.rtmp.huya.com/1199568484605-1199568484605-5465814125789577216-2399137092666-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
灵魂美食 - 灵魂美食,http://61.241.131.18/tx.rtmp.huya.com/1199518845971-1199518845971-5252617816141463552-2399037815398-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 小星星本鑫,http://61.241.131.18/tx.rtmp.huya.com/1199576899775-1199576899775-5501957005729857536-2399153923006-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
1 - 湘妹洋子,http://61.241.131.18/tx.rtmp.huya.com/1199556125061-1199556125061-5412730288516104192-2399112373578-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 你好小凌哥,http://61.241.131.18/tx.rtmp.huya.com/1199560091477-1199560091477-5429765915518435328-2399120306410-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
1 - 劲面堂,http://61.241.131.18/tx.rtmp.huya.com/1199555081486-1199555081486-5408248168020180992-2399110286428-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 涛饱饱,http://61.241.131.18/tx.rtmp.huya.com/1199577999289-1199577999289-5506679382401351680-2399156122034-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 王咩阿,http://61.241.131.18/tx.rtmp.huya.com/1299516723568-1299516723568-10465118069347844096-2599033570592-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 杨继伟吃不胖,http://61.241.131.18/tx.rtmp.huya.com/1199526050115-1199526050115-5283559379017138176-2399052223686-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 大辉爱美食,http://61.241.131.18/tx.rtmp.huya.com/1199579897571-1199579897571-5514832441509937152-2399159918598-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 豁牙子大军,http://61.241.131.18/tx.rtmp.huya.com/1199529068195-1199529068195-5296521933913849856-2399058259846-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 乡间小路上,http://61.241.131.18/tx.rtmp.huya.com/1199564878882-1199564878882-5450327663426142208-2399129881220-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 二两红豆,http://61.241.131.18/tx.rtmp.huya.com/1199540356628-1199540356628-5345005384471937024-2399080836712-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - SaM,http://61.241.131.18/tx.rtmp.huya.com/1199548271220-1199548271220-5378998298273120256-2399096665896-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 王硬硬-,http://61.241.131.18/tx.rtmp.huya.com/1199541416572-1199541416572-5349557809287528448-2399082956600-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 几率小王子,http://61.241.131.18/tx.rtmp.huya.com/1199545004023-1199545004023-5364965794008530944-2399090131502-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 小船儿荡起双桨,http://61.241.131.18/tx.rtmp.huya.com/2196727820-2196727820-9434874145113374720-4393579096-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 麻辣铁锅,http://61.241.131.18/tx.rtmp.huya.com/1279520281039-1279520281039-16814771739497070592-2559040685534-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 船长,http://61.241.131.18/tx.rtmp.huya.com/1199533932019-1199533932019-5317411898927349760-2399067987494-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 农村人丶华子,http://61.241.131.18/tx.rtmp.huya.com/1199532172357-1199532172357-5309854208185335808-2399064468170-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 可乐娃子,http://61.241.131.18/tx.rtmp.huya.com/1199557747970-1199557747970-5419700629595488256-2399115619396-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 二蛋,http://61.241.131.18/tx.rtmp.huya.com/761305026-761305026-3269780188950429696-1522733508-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 阿姆斯壮,http://61.241.131.18/tx.rtmp.huya.com/1199571768306-1199571768306-5479917514194419712-2399143660068-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 平底锅,http://61.241.131.18/tx.rtmp.huya.com/1279529302680-1279529302680-16853519392548323328-2559058728816-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 乡村鹅霸,http://61.241.131.18/tx.rtmp.huya.com/1199536479862-1199536479862-5328354801287692288-2399073083180-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 萝卜,http://61.241.131.18/tx.rtmp.huya.com/1279530113937-1279530113937-16857003714831974400-2559060351330-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
美食美酒美好生活 - 贝贝姐又来了,http://61.241.131.18/tx.rtmp.huya.com/1199580836650-1199580836650-5518865755103297536-2399161796756-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 阿苗m,http://61.241.131.18/tx.rtmp.huya.com/1199561233136-1199561233136-5434669303586619392-2399122589728-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 西米当吃八方,http://61.241.131.18/tx.rtmp.huya.com/1199579544651-1199579544651-5513316661651832832-2399159212758-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 小两口村,http://61.241.131.18/tx.rtmp.huya.com/1849197685-1849197685-7942243580913909760-3698518826-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 你的大妈,http://61.241.131.18/tx.rtmp.huya.com/1746272845-1746272845-7500184759167877120-3492669146-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 越南鬼脚七,http://61.241.131.18/tx.rtmp.huya.com/1199562430351-1199562430351-5439811302857900032-2399124984158-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 户外美食小王,http://61.241.131.18/tx.rtmp.huya.com/1199522323982-1199522323982-5267555759641591808-2399044771420-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 草原二蛋,http://61.241.131.18/tx.rtmp.huya.com/1199583396050-1199583396050-5529858294400679936-2399166915556-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 铁蛋儿Tyler,http://61.241.131.18/tx.rtmp.huya.com/1199581901380-1199581901380-5523438735632367616-2399163926216-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 国泰民安,http://61.241.131.18/tx.rtmp.huya.com/699383054-699383054-3003827344306601984-1398889564-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 泰国实习小妹,http://61.241.131.18/tx.rtmp.huya.com/1199582166497-1199582166497-5524577404476981248-2399164456450-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 雪糕,http://61.241.131.18/tx.rtmp.huya.com/1199528449975-1199528449975-5293866699232116736-2399057023406-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 山东梁山,http://61.241.131.18/tx.rtmp.huya.com/1199561775443-1199561775443-5436998494416011264-2399123674342-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 觅食记,http://61.241.131.18/tx.rtmp.huya.com/1279532593188-1279532593188-16867652016795549696-2559065309832-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 陕北的二后生,http://61.241.131.18/tx.rtmp.huya.com/1199578509732-1199578509732-5508871718392823808-2399157142920-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 麻辣好兄弟,http://61.241.131.18/tx.rtmp.huya.com/1199583075220-1199583075220-5528480340043104256-2399166273896-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 樱桃用颜值吃饭,http://61.241.131.18/tx.rtmp.huya.com/1199529218603-1199529218603-5297167931354906624-2399058560662-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 陕北妹子,http://61.241.131.18/tx.rtmp.huya.com/1259530635088-1259530635088-4746872416171458560-2519061393632-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 小贝,http://61.241.131.18/tx.rtmp.huya.com/2322321364-2322321364-9974294309182111744-4644766184-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 泰国小渣渣,http://61.241.131.18/tx.rtmp.huya.com/1199559735573-1199559735573-5428237319477919744-2399119594602-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 俄罗斯虎妞,http://61.241.131.18/tx.rtmp.huya.com/2257869275-2257869275-9697474694768230400-4515862006-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 泷川香菜,http://61.241.131.18/tx.rtmp.huya.com/1199546748355-1199546748355-5372457642901897216-2399093620166-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - Jungle,http://61.241.131.18/tx.rtmp.huya.com/1199562031892-1199562031892-5438099934484103168-2399124187240-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 花喵,http://61.241.131.18/tx.rtmp.huya.com/2370595539-2370595539-10181630312048492544-4741314534-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 怼哥,http://61.241.131.18/tx.rtmp.huya.com/1659595070-1659595070-7127906550252830720-3319313596-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 巧克力,http://61.241.131.18/tx.rtmp.huya.com/1259528160050-1259528160050-4736242208905101312-2519056443556-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 阿星,http://61.241.131.18/tx.rtmp.huya.com/2289298022-2289298022-9832460135287488512-4578719500-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 阿三,http://61.241.131.18/tx.rtmp.huya.com/1833738150-1833738150-7875845383677542400-3667599756-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 余多多,http://61.241.131.18/tx.rtmp.huya.com/1199567615308-1199567615308-5462080523604066304-2399135354072-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 阿追,http://61.241.131.18/tx.rtmp.huya.com/969742733-969742733-4165013323768659968-1939608922-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 嘴嘴,http://61.241.131.18/tx.rtmp.huya.com/1279529554188-1279529554188-16854599611183005696-2559059231832-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 嘴嘴,http://61.241.131.18/tx.rtmp.huya.com/1590312690-1590312690-6830340993963786240-3180748836-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 橘子,http://61.241.131.18/tx.rtmp.huya.com/631188993-631188993-2710936082530172928-1262501442-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 努力努力,http://61.241.131.18/tx.rtmp.huya.com/2251528377-2251528377-9670240745230958592-4503180210-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 骚洋来了,http://61.241.131.18/tx.rtmp.huya.com/1199546669535-1199546669535-5372119113579626496-2399093462526-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 卡特妹妹,http://61.241.131.18/tx.rtmp.huya.com/2334325838-2334325838-10025853132417794048-4668775132-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 吃货,http://61.241.131.18/tx.rtmp.huya.com/1199554929000-1199554929000-5407593245637083136-2399109981456-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 吃货,http://61.241.131.18/tx.rtmp.huya.com/1199560563574-1199560563574-5431793556693975040-2399121250604-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 罗西,http://61.241.131.18/tx.rtmp.huya.com/1548681932-1548681932-6651538249846095872-3097487320-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 气气,http://61.241.131.18/tx.rtmp.huya.com/2355477865-2355477865-10116700396626903040-4711079186-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 软软软吖,http://61.241.131.18/tx.rtmp.huya.com/1199539867021-1199539867021-5342902538419044352-2399079857498-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 熊二美食记,http://61.241.131.18/tx.rtmp.huya.com/1199578118558-1199578118558-5507191638855778304-2399156360572-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
美食博主小十七 - 小十七1,http://61.241.131.18/tx.rtmp.huya.com/1199577997503-1199577997503-5506671711589761024-2399156118462-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 我好哇塞,http://61.241.131.18/tx.rtmp.huya.com/1279515017100-1279515017100-16792163293643931648-2559030157656-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 渝子楠,http://61.241.131.18/tx.rtmp.huya.com/1299518683237-1299518683237-10473534783613829120-2599037489930-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 逛吃小猪猪,http://61.241.131.18/tx.rtmp.huya.com/1797311818-1797311818-7719395479024304128-3594747092-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 荒也解说,http://61.241.131.18/tx.rtmp.huya.com/1623301965-1623301965-6972028851207536640-3246727386-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - Clip大叔,http://61.241.131.18/tx.rtmp.huya.com/1199573468048-1199573468048-5487217850496057344-2399147059552-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
带你吃遍美食 - 觅食迹,http://61.241.131.18/tx.rtmp.huya.com/1199511990125-1199511990125-5223172181785051136-2399024103706-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 王子轩,http://61.241.131.18/tx.rtmp.huya.com/2386186802-2386186802-10248594276736827392-4772497060-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 很美味阿,http://61.241.131.18/tx.rtmp.huya.com/1199559906501-1199559906501-5428971449647890432-2399119936458-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 大傻瓜,http://61.241.131.18/tx.rtmp.huya.com/1259513641831-1259513641831-4673886933103935488-2519027407118-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 一吨重的汪汪汪,http://61.241.131.18/tx.rtmp.huya.com/1259517832659-1259517832659-4691886402307096576-2519035788774-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 炸大葱,http://61.241.131.18/tx.rtmp.huya.com/1199579494020-1199579494020-5513099203162669056-2399159111496-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 虎牙仔的虎牙仔,http://61.241.131.18/tx.rtmp.huya.com/1199576844249-1199576844249-5501718523375779840-2399153811954-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 户外赶海钓鱼,http://61.241.131.18/tx.rtmp.huya.com/1279528142742-1279528142742-16848537496772935680-2559056408940-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 小陆爱吃糖,http://61.241.131.18/tx.rtmp.huya.com/1199546145346-1199546145346-5369867738967703552-2399092414148-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 探索兄弟,http://61.241.131.18/tx.rtmp.huya.com/1199538588512-1199538588512-5337411384076402688-2399077300480-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
大肠刺身 - 炊烟大壮,http://61.241.131.18/tx.rtmp.huya.com/2752-2752-11819749998592-2399147067648-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 吃货??,http://61.241.131.18/tx.rtmp.huya.com/1548048651-1548048651-6648818328661917696-3096220758-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 阿远,http://61.241.131.18/tx.rtmp.huya.com/1787112900-1787112900-7675591459759718400-3574349256-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 荒野王,http://61.241.131.18/tx.rtmp.huya.com/1199583265148-1199583265148-5529296074591698944-2399166653752-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 雪鱼大佬,http://61.241.131.18/tx.rtmp.huya.com/1199554674858-1199554674858-5406501714058543104-2399109473172-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 圆圈,http://61.241.131.18/tx.rtmp.huya.com/1279524182148-1279524182148-16831526875070201856-2559048487752-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - SiO,http://61.241.131.18/tx.rtmp.huya.com/1279529955419-1279529955419-16856322885206147072-2559060034294-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 乡村张三儿,http://61.241.131.18/tx.rtmp.huya.com/1199579472360-1199579472360-5513006174171037696-2399159068176-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 翔翔啊翔翔,http://61.241.131.18/tx.rtmp.huya.com/1199548072558-1199548072558-5378145051480162304-2399096268572-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 光头小强,http://61.241.131.18/tx.rtmp.huya.com/1051355979-1051355979-4515539546259062784-2102835414-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - yo,http://61.241.131.18/tx.rtmp.huya.com/1629196790-1629196790-6997346931798179840-3258517036-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 张小幺,http://61.241.131.18/tx.rtmp.huya.com/1199566266725-1199566266725-5456288403723124736-2399132656906-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 林述述,http://61.241.131.18/tx.rtmp.huya.com/1830072717-1830072717-7860102468816863232-3660268890-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - Boki小姐,http://61.241.131.18/tx.rtmp.huya.com/1199571128093-1199571128093-5477167820296945664-2399142379642-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 保定小老哥,http://61.241.131.18/tx.rtmp.huya.com/2200603900-2200603900-9451521781950054400-4401331256-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 阿菜,http://61.241.131.18/tx.rtmp.huya.com/2450937838-2450937838-10526697858738946048-4901999132-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 太阳,http://61.241.131.18/tx.rtmp.huya.com/2290017735-2290017735-9835551279084994560-4580158926-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 吃瓜小姐姐,http://61.241.131.18/tx.rtmp.huya.com/2255119935-2255119935-9685666369382645760-4510363326-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 想喝奶茶,http://61.241.131.18/tx.rtmp.huya.com/1199546139855-1199546139855-5369844155302281216-2399092403166-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 觅食先生,http://61.241.131.18/tx.rtmp.huya.com/1364255637-1364255637-5859433344298647552-2728634730-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 吃不了鸡小分队,http://61.241.131.18/tx.rtmp.huya.com/2296849390-2296849390-9864893013887549440-4593822236-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 小食光光,http://61.241.131.18/tx.rtmp.huya.com/1199558246435-1199558246435-5421841520468688896-2399116616326-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 川味凉皮,http://61.241.131.18/tx.rtmp.huya.com/1259529568323-1259529568323-4742290695383941120-2519059260102-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 孙大厨,http://61.241.131.18/tx.rtmp.huya.com/1163943576-1163943576-4999099593309290496-2328010608-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 韩国影院,http://61.241.131.18/tx.rtmp.huya.com/1279520792495-1279520792495-16816968426290413568-2559041708446-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 狗不理辉辉,http://61.241.131.18/tx.rtmp.huya.com/2387870976-2387870976-10255827748987600896-4775865408-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 馋,http://61.241.131.18/tx.rtmp.huya.com/1094476139-1094476139-4700739223257350144-2189075734-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 小怪,http://61.241.131.18/tx.rtmp.huya.com/137058457-137058457-588661590455222272-274240370-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 西安,http://61.241.131.18/tx.rtmp.huya.com/1199528381119-1199528381119-5293570964963983360-2399056885694-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 我的样子平平无奇,http://61.241.131.18/tx.rtmp.huya.com/5940048-5940048-25512311896670208-12003552-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 猪肉佬,http://61.241.131.18/tx.rtmp.huya.com/1279512379203-1279512379203-16780833612298715136-2559024881862-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 二又ovo,http://61.241.131.18/tx.rtmp.huya.com/1259527119870-1259527119870-4731774669823148032-2519054363196-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 二花,http://61.241.131.18/tx.rtmp.huya.com/1279529736569-1279529736569-16855382931613417472-2559059596594-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 文哥,http://61.241.131.18/tx.rtmp.huya.com/1860223283-1860223283-7989598163742752768-3720570022-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 小九,http://61.241.131.18/tx.rtmp.huya.com/1199558390994-1199558390994-5422462396646031360-2399116905444-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 胜仔赶海,http://61.241.131.18/tx.rtmp.huya.com/1199579413457-1199579413457-5512753187712401408-2399158950370-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 小棋,http://61.241.131.18/tx.rtmp.huya.com/1574288992-1574288992-6761519735092805632-3148701440-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 大嘴哥,http://61.241.131.18/tx.rtmp.huya.com/2246311137-2246311137-9647832870055575552-4492745730-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 西安美食猫,http://61.241.131.18/tx.rtmp.huya.com/1199575009618-1199575009618-5493838843230552064-2399150142692-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 小陈的饭局,http://61.241.131.18/tx.rtmp.huya.com/1167967958-1167967958-5016384182385901568-2336059372-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 大爷,http://61.241.131.18/tx.rtmp.huya.com/1689712313-1689712313-7257259123983515648-3379548082-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 二饼,http://61.241.131.18/tx.rtmp.huya.com/1771402156-1771402156-7608114328083890176-3542927768-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 野厨子,http://61.241.131.18/tx.rtmp.huya.com/1199590740916-1199590740916-5561404253664182272-2399181605288-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 姥姥,http://61.241.131.18/tx.rtmp.huya.com/1199531799731-1199531799731-5308253791701696512-2399063722918-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 南方小蓉,http://61.241.131.18/tx.rtmp.huya.com/1199578503301-1199578503301-5508844097458143232-2399157130058-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 我想叫大头,http://61.241.131.18/tx.rtmp.huya.com/2306057949-2306057949-9904443473635835904-4612239354-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 女装大佬,http://61.241.131.18/tx.rtmp.huya.com/1798648071-1798648071-7725134641958486016-3597419598-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 我超假的,http://61.241.131.18/tx.rtmp.huya.com/1626766302-1626766302-6986908065324859392-3253656060-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 开饭开饭了,http://61.241.131.18/tx.rtmp.huya.com/1199575916561-1199575916561-5497734133754888192-2399151956578-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 美食博主狗离,http://61.241.131.18/tx.rtmp.huya.com/1279517997411-1279517997411-16804963631920840704-2559036118278-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 花一样的美男,http://61.241.131.18/tx.rtmp.huya.com/1665011589-1665011589-7151170322215993344-3330146634-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 二又呀,http://61.241.131.18/tx.rtmp.huya.com/1199568496528-1199568496528-5465865334684647424-2399137116512-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 柴犬,http://61.241.131.18/tx.rtmp.huya.com/1516070929-1516070929-6511475058471337984-3032265314-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
野厨大叔户外美味 - 大叔,http://61.241.131.18/tx.rtmp.huya.com/1199522306630-1199522306630-5267481233369071616-2399044736716-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 大冬啊,http://61.241.131.18/tx.rtmp.huya.com/1279524787569-1279524787569-16834127138465513472-2559049698594-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 金子,http://61.241.131.18/tx.rtmp.huya.com/74475855-74475855-319871361566638080-149075166-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 老隐蔽,http://61.241.131.18/tx.rtmp.huya.com/1650012427-1650012427-7086749411958587392-3300148310-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 土豪,http://61.241.131.18/tx.rtmp.huya.com/1662746224-1662746224-7141440653627490304-3325615904-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 智贤,http://61.241.131.18/tx.rtmp.huya.com/1279513504026-1279513504026-16785664690297503744-2559027131508-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【二米炊烟】适合这个季节吃的野菜 - 二米炊烟,http://61.241.131.18/tx.rtmp.huya.com/1199533318368-1199533318368-5314776287951192064-2399066760192-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
油淋辣椒 - 老细私房菜,http://61.241.131.18/tx.rtmp.huya.com/1199531586569-1199531586569-5307338267882946560-2399063296594-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
v_huya_1199512905824 - 郑州新东方烹饪学校,http://61.241.131.18/tx.rtmp.huya.com/1199512905824-1199512905824-5227105079043031040-2399025935104-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
杰克辣条的美食视频（珍惜粮食，拒绝浪费） - 杰克辣条,http://61.241.131.18/tx.rtmp.huya.com/1199525963437-1199525963437-5283187099841855488-2399052050330-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
美食 - 夏一味,http://61.241.131.18/tx.rtmp.huya.com/1199527342278-1199527342278-5289109176843239424-2399054808012-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【寿喜烧】 - 香喷喷的小烤鸡,http://61.241.131.18/tx.rtmp.huya.com/1199530063193-1199530063193-5300795417783435264-2399060249842-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
《勇敢的心》千秋家国血未冷 - 热心市民高先生,http://61.241.131.18/tx.rtmp.huya.com/92327913-92327913-396545366842933248-3048991612-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
朱雀青龙寻找玄女召唤神兽 - 斯国一,http://61.241.131.18/tx.rtmp.huya.com/1423782076-1423782076-6115097453050986496-2847687608-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
搜神传 中国神话故事传说 - D3ath-亡魂,http://61.241.131.18/tx.rtmp.huya.com/1394575567-1394575567-5989656452065656832-2789274590-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
真正的男人 - 尐饭团,http://61.241.131.18/tx.rtmp.huya.com/1449584077-1449584077-6225916203517345792-2847687612-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 阿斗归来了,http://61.241.131.18/tx.rtmp.huya.com/94525224-2583571962-11096357083652554752-3503038830-10057-A-0-1-imgplus.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 奥特博物馆V,http://61.241.131.18/tx.rtmp.huya.com/1199599080912-1199599080912-5597224263732953088-2399198285280-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
蜡笔小新·逗比少年欢乐多 - 野原新之助-,http://61.241.131.18/tx.rtmp.huya.com/1423787878-1423787878-6115122372451237888-2847699212-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 亿酷影视,http://61.241.131.18/tx.rtmp.huya.com/1199577563845-1199577563845-5504809164662112256-2399155251146-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 楚门聊电影,http://61.241.131.18/tx.rtmp.huya.com/2322561713-2322561713-9975326600276738048-4645246882-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 扁豆看电影,http://61.241.131.18/tx.rtmp.huya.com/94525224-2703099090-11609722189397360640-4587890396-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
陈翔六点半·更新到281集了 - 陈翔六点半,http://61.241.131.18/tx.rtmp.huya.com/1352054947-1352054947-5807031779760013312-2704233350-10057-A-0-1-imgplus.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
尤里有剧直播间 - 尤里有剧,http://61.241.131.18/tx.rtmp.huya.com/1199531545712-1199531545712-5307162788404133888-2399063214880-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 利世-余小二,http://61.241.131.18/tx.rtmp.huya.com/146501201-146501201-629217867119722496-293125858-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
科幻梦工场 - 科幻梦工场,http://61.241.131.18/tx.rtmp.huya.com/94525224-2682536056-11521404630860824576-3512313440-10057-A-0-1-imgplus.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
豪门绑架案改编电影《金钱世界》 - 亮哥讲电影,http://61.241.131.18/tx.rtmp.huya.com/94525224-2705821608-11621415315170131968-986759016-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
一起看海贼火影解说 - 狗哥吃火锅,http://61.241.131.18/tx.rtmp.huya.com/1199512574006-1199512574006-5225679931584806912-2399025271468-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
恐怖电影找力哥 - 力哥影視,http://61.241.131.18/tx.rtmp.huya.com/1199557791348-1199557791348-5419886936686854144-2399115706152-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 非凡武林,http://61.241.131.18/tx.rtmp.huya.com/1279520922847-1279520922847-16817528283867381760-2559041969150-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
胭脂雪中缘起缘灭 - 心疼得抱住胖胖的自己,http://61.241.131.18/tx.rtmp.huya.com/1394575548-1394575548-5989656370461278208-2789274552-10057-A-0-1-imgplus.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 枫哥影视,http://61.241.131.18/tx.rtmp.huya.com/1199579767212-1199579767212-5514272553868197888-2399159657880-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
成本低、场景单一，这部只拍了12天的小制作电影让多少人拍手叫好 - 止戈电影,http://61.241.131.18/tx.rtmp.huya.com/1199522933703-1199522933703-5270174491396276224-2399045990862-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
路飞带领大家向顶上前进 - 南西视频,http://61.241.131.18/tx.rtmp.huya.com/1199512045291-1199512045291-5223409117950902272-2399024214038-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【斌哥】带你来看《龙珠超》（六） - 斌哥漫说,http://61.241.131.18/tx.rtmp.huya.com/1199516152253-1199516152253-5241048385426817024-2399032427962-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【极品新娘】豆腐西施嫁给痴心憨夫 - 傻妞,http://61.241.131.18/tx.rtmp.huya.com/1394575549-1394575549-5989656374756245504-2789274554-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
倩女幽魂电视剧版 同心生死约看得我哇哇哭 - 鸽宝小改改,http://61.241.131.18/tx.rtmp.huya.com/1449539468-1449539468-6225724609321238528-3048959632-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
1 - 小丑讲电影,http://61.241.131.18/tx.rtmp.huya.com/1199511997436-1199511997436-5223203582290952192-2399024118328-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - DD-解说,http://61.241.131.18/tx.rtmp.huya.com/1199588542242-1199588542242-5551961020739616768-2399177207940-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 缔爵丶小阿杜,http://61.241.131.18/tx.rtmp.huya.com/2293333915-2293333915-9849794163732643840-4586791286-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 大翔看动漫,http://61.241.131.18/tx.rtmp.huya.com/1199598188609-1199598188609-5593391851529830400-2399196500674-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
网球王子·费德勒看了想打人 - 我们都爱笑,http://61.241.131.18/tx.rtmp.huya.com/1423782044-1423782044-6115097315612033024-2847687544-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【经典】陈道明版康熙 - 四次元先生,http://61.241.131.18/tx.rtmp.huya.com/1524439831-1524439831-6547419218864766976-3049003118-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
《毒师》第一季第三集，小八无意间刺激到老白，导致自己领了盒饭 - 阿良说美剧,http://61.241.131.18/tx.rtmp.huya.com/1199526558405-1199526558405-5285742467944022016-2399053240266-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
成龍历险记·社会我阿福乌鸦坐飞机 - 老司机,http://61.241.131.18/tx.rtmp.huya.com/1423787836-1423787836-6115122192062611456-2847699128-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
通讯班快集合·开炮啦 - 勞資ヽ尐爺,http://61.241.131.18/tx.rtmp.huya.com/1394575560-1394575560-5989656422000885760-2789274576-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【猫和老鼠】汤姆和杰瑞的故事 - HelloKitty,http://61.241.131.18/tx.rtmp.huya.com/1423782038-1423782038-6115097289842229248-2847687532-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 荒野求生影视,http://61.241.131.18/tx.rtmp.huya.com/1199528334171-1199528334171-5293369324839370752-2399056791798-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 大鱼爱路飞,http://61.241.131.18/tx.rtmp.huya.com/1199590495159-1199590495159-5560348735386419200-2399181113774-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
null - Adam短发,http://61.241.131.18/tx.rtmp.huya.com/1199532313878-1199532313878-5310462036252033024-2399064751212-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
7分钟看完科幻神作《宇宙“蛋”生》宇宙就是这样一次次被整没的 - 幻海航行,http://61.241.131.18/tx.rtmp.huya.com/1199512401451-1199512401451-5224938813503045632-2399024926358-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 良少聊漫威,http://61.241.131.18/tx.rtmp.huya.com/1199582668017-1199582668017-5526731416475271168-2399165459490-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
新乌龙院之笑闹江湖 - 好尸,http://61.241.131.18/tx.rtmp.huya.com/94525224-2702136290-11605586994884771840-4573721796-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
Yes小哥的美食视频（珍惜粮食，拒绝浪费 - YeShi小哥,http://61.241.131.18/tx.rtmp.huya.com/94525224-2656999522-11411726052477632512-3724460598-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 喝一碗杏仁茶,http://61.241.131.18/tx.rtmp.huya.com/1099531752759-1099531752759-86436143817555968-2199063628974-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【越哥】《百鸟朝凤》 - 越哥说电影,http://61.241.131.18/tx.rtmp.huya.com/94525224-2700236716-11597428386678439936-2112795098-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
大宅men 白家老号百草厅 - Mr-傀儡,http://61.241.131.18/tx.rtmp.huya.com/1423787821-1423787821-6115122127638102016-2847699098-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【中华小当家】看的我口水直流～ - 战斗联盟,http://61.241.131.18/tx.rtmp.huya.com/1449588921-1449588921-6225937008338927616-2789274526-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【小川】《一周不死，全额退款》 - 小川侃电影,http://61.241.131.18/tx.rtmp.huya.com/94525224-2699462070-11594101307442462720-2966491422-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
1 - 酱婶儿电影,http://61.241.131.18/tx.rtmp.huya.com/1199572964477-1199572964477-5485055029519843328-2399146052410-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 咆哮解说黑鑫,http://61.241.131.18/tx.rtmp.huya.com/1199579889224-1199579889224-5514796591417917440-2399159901904-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 鹿哥电影,http://61.241.131.18/tx.rtmp.huya.com/1199572962557-1199572962557-5485046783182635008-2399146048570-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
林正英《僵尸道长》系列等港剧 - 李小哇絮叨叨,http://61.241.131.18/tx.rtmp.huya.com/1199515315044-1199515315044-5237452600151900160-2399030753544-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
2020跨年晚会上唱的这几首歌曲，真是让人很是怀念 - 音乐小石榴,http://61.241.131.18/tx.rtmp.huya.com/1199512344405-1199512344405-5224693802798678016-2399024812266-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 憨憨哥说电影,http://61.241.131.18/tx.rtmp.huya.com/1199578904068-1199578904068-5510565378616459264-2399157931592-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
null - 低调新说,http://61.241.131.18/tx.rtmp.huya.com/1199527050394-1199527050394-5287855544609013760-2399054224244-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 稻谷Movie,http://61.241.131.18/tx.rtmp.huya.com/1199589886067-1199589886067-5557732705166163968-2399179895590-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 光之阿泽V,http://61.241.131.18/tx.rtmp.huya.com/1199598462404-1199598462404-5594567792100638720-2399197048264-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
历年贺岁档 笑就完事儿了 - 浮生没有若梦,http://61.241.131.18/tx.rtmp.huya.com/1524418118-1524418118-6547325962239868928-3048959692-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 熊妹撩电影,http://61.241.131.18/tx.rtmp.huya.com/94525224-2703053314-11609525582974418944-239402834-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 大本有剧,http://61.241.131.18/tx.rtmp.huya.com/1199573055331-1199573055331-5485445244478554112-2399146234118-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
吞咽:人类吞咽万物 - 大聪明和魏乐乐影院,http://61.241.131.18/tx.rtmp.huya.com/1199555769841-1199555769841-5411204630233219072-2399111663138-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
持枪匪徒突袭，每个现场都触目惊心，港式警匪片《非常突然》 - 吾聊电影,http://61.241.131.18/tx.rtmp.huya.com/94525224-2711961022-11647783897516736512-3195245956-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
冷门宝藏片！一具尸体和4个少年的故事，《肖申克的救赎》姊妹片 - 大象放映室,http://61.241.131.18/tx.rtmp.huya.com/1199531762115-1199531762115-5308092232211890176-2399063647686-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
最强的军事武器分析 - 逆火行,http://61.241.131.18/tx.rtmp.huya.com/1420406442-1420406442-6100599215417720832-4563964964-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
《乔我说》海贼王15 - 乔我说动漫频道,http://61.241.131.18/tx.rtmp.huya.com/1199513582384-1199513582384-5230010882116812800-2399027288224-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【权力的游戏】龙妈故事线04-弥林的女王 - 乔我说游戏频道,http://61.241.131.18/tx.rtmp.huya.com/1446420010-1446420010-6212326639229992960-4637074750-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 电影狂人A,http://61.241.131.18/tx.rtmp.huya.com/1447405089-1447405089-6216557521318969344-4349145444-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 小杨说电影,http://61.241.131.18/tx.rtmp.huya.com/1199555968248-1199555968248-5412056781809516544-2399112059952-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
恐怖片：女孩闭着眼睛洗澡，无数蟑螂从天花板上掉下来，瞬间悲剧了 - 恐怖地带,http://61.241.131.18/tx.rtmp.huya.com/1444492216-1444492216-6204046827046567936-4666044768-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 兔八哥说电影,http://61.241.131.18/tx.rtmp.huya.com/1199517696445-1199517696445-5247680639565561856-2399035516346-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 不二说剧,http://61.241.131.18/tx.rtmp.huya.com/1199573065053-1199573065053-5485487000150605824-2399146253562-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
人类濒临消失，地球会自我重生，地球不需要人类拯救《苏美尔》 - EZQ影视,http://61.241.131.18/tx.rtmp.huya.com/1730230272-1730230272-7431282432789184512-3460584000-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
高分爱情电影《意外制造公司》 - 鱼丸说电影,http://61.241.131.18/tx.rtmp.huya.com/1444281068-1444281068-6203139953291952128-4657213132-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 爆裂电影,http://61.241.131.18/tx.rtmp.huya.com/1199576334514-1199576334514-5499529228221153280-2399152792484-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
一部根据真实案件改编的电影，女子口无遮拦，最终招惹杀身之祸 - 鲁班爱看剧,http://61.241.131.18/tx.rtmp.huya.com/1445186641-1445186641-6207029359711092736-4696433912-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
精彩不断，好戏连连，好电影就在这！ - 白丁说电影,http://61.241.131.18/tx.rtmp.huya.com/1199572986735-1199572986735-5485150626901917696-2399146096926-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - CC看动漫,http://61.241.131.18/tx.rtmp.huya.com/1199583882990-1199583882990-5531949685775794176-2399167889436-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【悬疑推理，烧脑破案】 - 噔噔悬疑社,http://61.241.131.18/tx.rtmp.huya.com/1445653515-1445653515-6209034568272445440-4362512954-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 良影解说,http://61.241.131.18/tx.rtmp.huya.com/1199579404459-1199579404459-5512714541596672000-2399158932374-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
刘老师解说《想见你》第三期 - 刘老师说电影,http://61.241.131.18/tx.rtmp.huya.com/1199525477167-1199525477167-5281098586094829568-2399051077790-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
冲啊！四驱兄弟 嘴控大战 - 小爱酱,http://61.241.131.18/tx.rtmp.huya.com/1423782104-1423782104-6115097573310070784-2847687664-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
有才的网友：这个司仪不错，我每次结婚都找他！ - Big笑工坊,http://61.241.131.18/tx.rtmp.huya.com/22303913-22303913-95794576907829248-4413173724-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 书书漫,http://61.241.131.18/tx.rtmp.huya.com/1199588866837-1199588866837-5553355145649061888-2399177857130-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 宅妹,http://61.241.131.18/tx.rtmp.huya.com/1449581164-1449581164-6225903692277612544-2847699154-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 猫哥影视,http://61.241.131.18/tx.rtmp.huya.com/1199559675189-1199559675189-5427977972172718080-2399119473834-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
宇智波斑与千手柱间结婚了？儿时的斑爷是真的可爱呀！ - 猫眼下的鱼,http://61.241.131.18/tx.rtmp.huya.com/1199525077688-1199525077688-5279382836854390784-2399050278832-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 杰克动漫,http://61.241.131.18/tx.rtmp.huya.com/1259512960776-1259512960776-4670961824152158208-2519026045008-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 胖虎噜噜噜,http://61.241.131.18/tx.rtmp.huya.com/1199527202658-1199527202658-5288509513509371904-2399054528772-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
你的小美吖 - 你的小美吖,http://61.241.131.18/tx.rtmp.huya.com/76213110-76213110-327332814976450560-118668432-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 一日壹片,http://61.241.131.18/tx.rtmp.huya.com/1199591048363-1199591048363-5562724728474435584-2399182220182-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
林正英十种角色性格，宗师范儿，又小气又爱耍小聪明 - 青年电影馆,http://61.241.131.18/tx.rtmp.huya.com/1199532722561-1199532722561-5312217316371464192-2399065568578-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
续哥说电影的直播间 - 续哥说电影,http://61.241.131.18/tx.rtmp.huya.com/2188751159-2188751159-9400614646987096064-4377625774-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
1 - 军武直播,http://61.241.131.18/tx.rtmp.huya.com/1299518216864-1299518216864-10471531726831091712-2599036557184-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 柒言绝剧,http://61.241.131.18/tx.rtmp.huya.com/1199577734802-1199577734802-5505543419386134528-2399155593060-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
速看美剧《不死法医11》 - 默爷侃电影,http://61.241.131.18/tx.rtmp.huya.com/1199512504371-1199512504371-5225380851537149952-2399025132198-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
一口毒奶 - 一口毒奶,http://61.241.131.18/tx.rtmp.huya.com/94525224-2705821586-11621415220680851456-2196900372-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
大梦电影 - 大梦电影,http://61.241.131.18/tx.rtmp.huya.com/1199573065336-1199573065336-5485488215626350592-2399146254128-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 我的宝贝baby,http://61.241.131.18/tx.rtmp.huya.com/1449567112-1449567112-6225843339397169152-2847687536-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 寻宝求生,http://61.241.131.18/tx.rtmp.huya.com/1199529566300-1199529566300-5298661278598823936-2399059256056-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
解密周星驰档案：周星驰和他的无厘头世界（2011） - 周星驰吧,http://61.241.131.18/tx.rtmp.huya.com/1199530535515-1199530535515-5302824025326616576-2399061194486-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
1982年经典影片《笔中情》，小白龙演主角，唐僧演配角 - 老电影故事,http://61.241.131.18/tx.rtmp.huya.com/94525224-2685203800-11532862504094924800-2922695320-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
张显宗，我牙疼。 - 涵哥评电影,http://61.241.131.18/tx.rtmp.huya.com/2242935432-2242935432-9633334327479631872-4485994320-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
1 - 皮皮猫影视,http://61.241.131.18/tx.rtmp.huya.com/1199555954240-1199555954240-5411996617907634176-2399112031936-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
刘德华系列，经典电影 - DD-月牙" tvg-logo="https://tx,http://61.241.131.18/tx.rtmp.huya.com/1199583305794-1199583305794-5529470647832412160-2399166735044-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 小邓子解说师,http://61.241.131.18/tx.rtmp.huya.com/1199582002678-1199582002678-5523873807229517824-2399164128812-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
真人电影《大侦探皮卡丘》，带给你不一样的视觉效果，特效震撼 - 小冉看电影,http://61.241.131.18/tx.rtmp.huya.com/1445492508-1445492508-6208343048473018368-4707289134-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
一朵老香菇 - 一朵老香菇,http://61.241.131.18/tx.rtmp.huya.com/94525224-2701809014-11604181355168006144-158309560-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 恐怖电影猪哥,http://61.241.131.18/tx.rtmp.huya.com/1827860411-1827860411-7850600686898118656-3655844278-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
桃白柏 - 桃白柏,http://61.241.131.18/tx.rtmp.huya.com/94525224-2701577876-11603188625017143296-299654480-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 天哥打鬼子,http://61.241.131.18/tx.rtmp.huya.com/1199591052044-1199591052044-5562740538249052160-2399182227544-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
1 - 虎妞说电影,http://61.241.131.18/tx.rtmp.huya.com/1199525415984-1199525415984-5280835807110758400-2399050955424-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【轮播】经典中文单机游戏剧情视频 - SemenixGaming,http://61.241.131.18/tx.rtmp.huya.com/1199514005435-1199514005435-5231827872326352896-2399028134326-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
回家 - 渣子看闹剧,http://61.241.131.18/tx.rtmp.huya.com/95275477-95275477-409205057825800192-173541658-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
v_huya_1199515057776 - 圣逗事,http://61.241.131.18/tx.rtmp.huya.com/1199515057776-1199515057776-5236347642505592832-2399030239008-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
莉莎带你看动漫~ - 莉莎动漫,http://61.241.131.18/tx.rtmp.huya.com/1199591494711-1199591494711-5564641778537070592-2399183112878-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 一目十影,http://61.241.131.18/tx.rtmp.huya.com/1259515146931-1259515146931-4680351288381145088-2519030417318-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 怀旧电影厅,http://61.241.131.18/tx.rtmp.huya.com/1199591050167-1199591050167-5562732476595437568-2399182223790-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 不问影探,http://61.241.131.18/tx.rtmp.huya.com/1199579832187-1199579832187-5514551619368255488-2399159787830-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 照影刑侦组,http://61.241.131.18/tx.rtmp.huya.com/1199596626578-1199596626578-5586682979469492224-2399193376612-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
一部从头爽到爆的科幻动作电影，编剧堪称非常疯狂！ - 万人影视,http://61.241.131.18/tx.rtmp.huya.com/1199512041525-1199512041525-5223392943104065536-2399024206506-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
街访Show - 西哥来了,http://61.241.131.18/tx.rtmp.huya.com/60637426-60637426-260435761583620096-2125253048-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
2007年上映，真实事件改编，四大悬案之一，26年至今未破！ - 老皮讲电影,http://61.241.131.18/tx.rtmp.huya.com/1199512163164-1199512163164-5223915378630983680-2399024449784-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
蛋壳宝宝 - 蛋壳宝宝,http://61.241.131.18/tx.rtmp.huya.com/1199511946075-1199511946075-5222982988475662336-2399024015606-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
黄猿来到了肥皂泡群岛 - 游戏小萌主,http://61.241.131.18/tx.rtmp.huya.com/1199512047498-1199512047498-5223418596943724544-2399024218452-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
彤颜童语 - 彤颜童语,http://61.241.131.18/tx.rtmp.huya.com/1199518994166-1199518994166-5253254308819894272-2399038111788-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 小林讲电影,http://61.241.131.18/tx.rtmp.huya.com/1199514879554-1199514879554-5235582184844165120-2399029882564-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
影片欣赏 - 韩小囧说电影,http://61.241.131.18/tx.rtmp.huya.com/1199527772079-1199527772079-5290955158082027520-2399055667614-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 我是一颗小虎牙,http://61.241.131.18/tx.rtmp.huya.com/1199584803878-1199584803878-5535904869619073024-2399169731212-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 亦寒电影,http://61.241.131.18/tx.rtmp.huya.com/1199583464816-1199583464816-5530153642121756672-2399167053088-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
中国最后一个太监，居然能俘获女神温碧霞！ - 了不起的乌贼君,http://61.241.131.18/tx.rtmp.huya.com/1444264308-1444264308-6203067969640071168-4655558802-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
v_huya_2290275172 - 阿钙扒瞎,http://61.241.131.18/tx.rtmp.huya.com/94525224-2702006072-11605027712833421312-4580673800-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
1 - 马桶吐槽,http://61.241.131.18/tx.rtmp.huya.com/1199512349981-1199512349981-5224717751536320512-2399024823418-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
小东北侃大片直播间 - 小东北侃大片,http://61.241.131.18/tx.rtmp.huya.com/1199552346391-1199552346391-5396501024443727872-2399104816238-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
RGB彩灯提升手机性能实锤了！10G内存的黑鲨Helo手机 - 短的发布会,http://61.241.131.18/tx.rtmp.huya.com/1445190547-1445190547-6207046135853350912-1418039432-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
1 - 顾九撩电影,http://61.241.131.18/tx.rtmp.huya.com/94525224-2711954902-11647757612316884992-4635579152-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 爆米电影,http://61.241.131.18/tx.rtmp.huya.com/1199579039666-1199579039666-5511147767591862272-2399158202788-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
女孩惨死荒野，母亲为爱展开复仇，18岁以下禁止观看！ - Sir说电影,http://61.241.131.18/tx.rtmp.huya.com/1444295617-1444295617-6203202440771141632-4441426180-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 雷舌电影,http://61.241.131.18/tx.rtmp.huya.com/1348951819-1348951819-5793703946484711424-3697487504-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
小伙离家出走,http://61.241.131.18/tx.rtmp.huya.com/1199514472692-1199514472692-5233834725860179968-2399029068840-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
花花与三猫CatLive - 花花与三猫CatLive,http://61.241.131.18/tx.rtmp.huya.com/94525224-2700873164-11600161910024044544-4575941946-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 歪嘴说电影,http://61.241.131.18/tx.rtmp.huya.com/1199565980785-1199565980785-5455060300774506496-2399132085026-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 东方先生i,http://61.241.131.18/tx.rtmp.huya.com/1199524398220-1199524398220-5276464544015712256-2399048919896-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 琪琪影视v,http://61.241.131.18/tx.rtmp.huya.com/1199572986704-1199572986704-5485150493757931520-2399146096864-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 喜仔的动画世界,http://61.241.131.18/tx.rtmp.huya.com/1199523924869-1199523924869-5274431516951183360-2399047973194-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 仕说电影,http://61.241.131.18/tx.rtmp.huya.com/1199577898828-1199577898828-5506247905691828224-2399155921112-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
贝勒电影带你分钟看电影 - 贝勒电影,http://61.241.131.18/tx.rtmp.huya.com/2336539730-2336539730-10035361726154670080-4673202916-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
老炮说电影 - 老炮说电影,http://61.241.131.18/tx.rtmp.huya.com/2250790740-2250790740-9667072618439639040-4501704936-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 西红柿讲电影,http://61.241.131.18/tx.rtmp.huya.com/1199579059037-1199579059037-5511230965403353088-2399158241530-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
1 - 赵非同,http://61.241.131.18/tx.rtmp.huya.com/1199519795094-1199519795094-5256694268386344960-2399039713644-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
娘子陪你看 - 娘子说电影,http://61.241.131.18/tx.rtmp.huya.com/1199517262701-1199517262701-5245817723270725632-2399034648858-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 疯狂解说家,http://61.241.131.18/tx.rtmp.huya.com/1199514945997-1199514945997-5235867555356213248-2399030015450-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 威廉说,http://61.241.131.18/tx.rtmp.huya.com/1199579381226-1199579381226-5512614756621484032-2399158885908-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
速看《食人鱼3D》 - 阿祥说电影,http://61.241.131.18/tx.rtmp.huya.com/1199512004776-1199512004776-5223235107350904832-2399024133008-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
1 - 电影十里廊,http://61.241.131.18/tx.rtmp.huya.com/1199511957710-1199511957710-5223032960420151296-2399024038876-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 沫漾电影,http://61.241.131.18/tx.rtmp.huya.com/94525224-2713073196-11652560648474198016-3664575176-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
社交软件上的变态正在窥探你的一切，6分钟看惊悚恐怖片《索命A - 宇宙无敌韩三金,http://61.241.131.18/tx.rtmp.huya.com/1419693862-1419693862-6097538707621937152-3702724262-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【朱一旦】有钱人的出行方式，涨姿势了！ - 朱一旦的枯燥生活,http://61.241.131.18/tx.rtmp.huya.com/1199556046399-1199556046399-5412392437798666240-2399112216254-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
null - 猎影派,http://61.241.131.18/tx.rtmp.huya.com/94525224-2704830208-11617157284592877568-4596722876-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
男孩遭遇海难，他被一匹黑马救了起来，从此与它相依为命！ - 老吴说电影,http://61.241.131.18/tx.rtmp.huya.com/1444498658-1444498658-6204074495225888768-4665669106-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
少女为了赢得职业比赛，喝下无数罐特殊饮料，结果副作用让她懵了 - 电影充电站,http://61.241.131.18/tx.rtmp.huya.com/1448618888-1448618888-6221770748327886848-2874441594-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
骆驼祥子 - 无比看电影精选,http://61.241.131.18/tx.rtmp.huya.com/1199519786002-1199519786002-5256655218543689728-2399039695460-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 海哥电影,http://61.241.131.18/tx.rtmp.huya.com/1199512951438-1199512951438-5227300989681270784-2399026026332-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 小葛电影,http://61.241.131.18/tx.rtmp.huya.com/1199575844699-1199575844699-5497425488815063040-2399151812854-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 花町馆长,http://61.241.131.18/tx.rtmp.huya.com/1199564706324-1199564706324-5449586532459479040-2399129536104-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
男子被注射未来药剂，身体发生可怕变化《X档案》S4-19 - 可乐撩电影,http://61.241.131.18/tx.rtmp.huya.com/1199524029911-1199524029911-5274882668905889792-2399048183278-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
关灯看大片 - 关灯看大片,http://61.241.131.18/tx.rtmp.huya.com/1421185736-1421185736-6103946257661689856-4601139740-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是晓杰！专注原创视频 - 晓杰侃电影,http://61.241.131.18/tx.rtmp.huya.com/1199512605293-1199512605293-5225814308226596864-2399025334042-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
电影笔记 - 电影笔记,http://61.241.131.18/tx.rtmp.huya.com/1199512037772-1199512037772-5223376824091803648-2399024199000-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
奇幻片：神秘石像 - 电影间谍,http://61.241.131.18/tx.rtmp.huya.com/1421216452-1421216452-6104078181877153792-1962680342-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 左左说电影,http://61.241.131.18/tx.rtmp.huya.com/1259519394758-1259519394758-4698595566425210880-2519038912972-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
狗狗拉雪橇时掉进冰洞，主人却视死不救 - 空空说电影,http://61.241.131.18/tx.rtmp.huya.com/94525224-2700825370-11599956636357099520-4573471418-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
大叔意外变成海贼王，身体能长能短能粗能细，轻松制服美女护士 - 小冷说电影,http://61.241.131.18/tx.rtmp.huya.com/1199511953375-1199511953375-5223014341736923136-2399024030206-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
1 - 电影享不停,http://61.241.131.18/tx.rtmp.huya.com/1199512034946-1199512034946-5223364686514225152-2399024193348-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 泡面微剧场,http://61.241.131.18/tx.rtmp.huya.com/1199514887344-1199514887344-5235615642639400960-2399029898144-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 小歌说电影,http://61.241.131.18/tx.rtmp.huya.com/1199584935178-1199584935178-5536468798825037824-2399169993812-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 港影侦查局,http://61.241.131.18/tx.rtmp.huya.com/1199591041856-1199591041856-5562696781122240512-2399182207168-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
新白娘子传奇，白素贞借机除掉蛤蟆精，顺便让许仙的药铺一炮走红 - 影音炫客,http://61.241.131.18/tx.rtmp.huya.com/1199513491025-1199513491025-5229618498199617536-2399027105506-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
全片就靠美女支撑着，有兴趣的朋友可以看看！ - 正经说电影,http://61.241.131.18/tx.rtmp.huya.com/1199520938771-1199520938771-5261606323698532352-2399042000998-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 鬼哥说电影,http://61.241.131.18/tx.rtmp.huya.com/1199579186042-1199579186042-5511776447724781568-2399158495540-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 小羊观影记录,http://61.241.131.18/tx.rtmp.huya.com/1199583404457-1199583404457-5529894402190737408-2399166932370-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 神奇书包,http://61.241.131.18/tx.rtmp.huya.com/1199583033407-1199583033407-5528300754575556608-2399166190270-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 肥猫观影,http://61.241.131.18/tx.rtmp.huya.com/1199568037059-1199568037059-5463891930356121600-2399136197574-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
海龙带你看龙珠 - 海龙动漫,http://61.241.131.18/tx.rtmp.huya.com/1199591309059-1199591309059-5563844409268633600-2399182741574-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
茶啊二中 - 茶啊二中,http://61.241.131.18/tx.rtmp.huya.com/28596569-28596569-122821328632807424-2633424538-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 佑佑说电影,http://61.241.131.18/tx.rtmp.huya.com/1199579637877-1199579637877-5513717064272969728-2399159399210-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【谍战神剧】张铎演绎终极潜伏！终极无间！ - 吐槽运动,http://61.241.131.18/tx.rtmp.huya.com/1449575331-1449575331-6225878639733374976-2789274584-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
每周不定期更新，喜欢的点点订阅哟~ - 呆萌君,http://61.241.131.18/tx.rtmp.huya.com/98282154-98282154-422118637210435584-3465852224-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【经典】古天乐版·穿越剧鼻祖 - 李大湿,http://61.241.131.18/tx.rtmp.huya.com/1394575539-1394575539-5989656331806572544-2789274534-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是大哥大 - 白泽字幕组,http://61.241.131.18/tx.rtmp.huya.com/1199560287662-1199560287662-5430608523677401088-2399120698780-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
赘婿-麒麟和铁铁的甜蜜爱情 - 马春夏秋冬梅,http://61.241.131.18/tx.rtmp.huya.com/1099531752758-1099531752758-86436139522588672-2199063628972-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【彭德huai】元帅的传奇一生 - 主播黑猫,http://61.241.131.18/tx.rtmp.huya.com/1449574089-1449574089-6225873305383993344-2847687582-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
第85集 我明明被骂了，但却还是忍不住想笑… - 白杨和桔子,http://61.241.131.18/tx.rtmp.huya.com/1199573414793-1199573414793-5486989122012708864-2399146953042-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 少女时代-俞利,http://61.241.131.18/tx.rtmp.huya.com/1099531789957-1099531789957-86595908011032576-2199063703370-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
王宝强-平凡的一生 - 4号流水线的李小花,http://61.241.131.18/tx.rtmp.huya.com/1524418065-1524418065-6547325734606602240-3048959586-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
红红火火 贺岁合家欢剧场 - 这很不同,http://61.241.131.18/tx.rtmp.huya.com/1524439827-1524439827-6547419201684897792-3049003110-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
纪连海说清朝名臣 - 嘤嘤嘤,http://61.241.131.18/tx.rtmp.huya.com/1250011-1250011-5368756364640256-2777027388-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【陪你看电影】找个小姐姐看经典，24小时在线滴滴！ - 【周星星】24小时放映厅,http://61.241.131.18/tx.rtmp.huya.com/1099531728510-1099531728510-86331995155595264-2199063580476-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【现场铁证】王劲松带你还原罪案真相！ - 小亮亮,http://61.241.131.18/tx.rtmp.huya.com/1449545371-1449545371-6225749962513186816-2789274568-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 木子李说故事,http://61.241.131.18/tx.rtmp.huya.com/1033849718-1033849718-4440350727788822528-2067822892-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
西游记·六学经典文体两开花 - 三不好學生,http://61.241.131.18/tx.rtmp.huya.com/1420294575-1420294575-6100118750311219200-3048991588-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - NCT127-泰一,http://61.241.131.18/tx.rtmp.huya.com/1099531789959-1099531789959-86595916600967168-2199063703374-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
超新星联赛-贝汯璘 - 贝汯璘,http://61.241.131.18/tx.rtmp.huya.com/1199582843683-1199582843683-5527485896200290304-2399165810822-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
美剧《血族》 - 白泽字幕2号,http://61.241.131.18/tx.rtmp.huya.com/1199562247002-1199562247002-5439023824899145728-2399124617460-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
孙红雷电影 大哥来了 - 我的朋友陈白露小姐,http://61.241.131.18/tx.rtmp.huya.com/43460312-43460312-186660618713956352-2847687638-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
5.16日16点 黄霄雲的音乐茶话会 - 黄霄雲,http://61.241.131.18/tx.rtmp.huya.com/1199540156392-1199540156392-5344145377400455168-2399080436240-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到周星驰贴吧的直播间 - 周星驰贴吧,http://61.241.131.18/tx.rtmp.huya.com/1199574747361-1199574747361-5492712457992404992-2399149618178-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【陪你看电影】经典警匪片小姐姐24小时在线陪看 - Dae陪你看-动作系列,http://61.241.131.18/tx.rtmp.huya.com/1199548705079-1199548705079-5380861708489195520-2399097533614-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【重播】Casper卡斯柏音乐吃播趴 - Casper卡斯柏,http://61.241.131.18/tx.rtmp.huya.com/1199532831224-1199532831224-5312684020402749440-2399065785904-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 小驴影视,http://61.241.131.18/tx.rtmp.huya.com/1199574948434-1199574948434-5493576059951513600-2399150020324-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
态度往期回放 - 【态度】官方节目,http://61.241.131.18/tx.rtmp.huya.com/1099531752873-1099531752873-86436633443827712-2199063629202-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
这个圣诞节，你许下了什么心愿？ - 奇妙博物馆,http://61.241.131.18/tx.rtmp.huya.com/5123-5123-22003117457408-2399113128206-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
回放：虎牙艺能星舞台 第一二期精彩节目 - 虎牙音乐,http://61.241.131.18/tx.rtmp.huya.com/2333177621-2333177621-10020921577954082816-4666478698-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
艺起声乐欢迎你 - 艺起声乐,http://61.241.131.18/tx.rtmp.huya.com/523151417-523151417-2246918226871058432-1046426290-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
郭其城直播回放 - 郭其城,http://61.241.131.18/tx.rtmp.huya.com/1199533413133-1199533413133-5315183300526997504-2399066949722-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
三口看电影 - 非同说电影,http://61.241.131.18/tx.rtmp.huya.com/1199526542419-1199526542419-5285673808596828160-2399053208294-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
淘宝双12贺促档大片上映！沈腾替罗永浩打工 - 淘宝电影制片厂,http://61.241.131.18/tx.rtmp.huya.com/1388451796-1388451796-5963355055892463616-2777027048-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 烟波草雀,http://61.241.131.18/tx.rtmp.huya.com/1099531789962-1099531789962-86595929485869056-2199063703380-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
《楚留香之盗帅觉醒》郭品超神仙颜值，俘获康宁芳心，羡慕了 - 影弟追影,http://61.241.131.18/tx.rtmp.huya.com/1199572143233-1199572143233-5481527813397807104-2399144409922-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【重播】《鬓边》十九师姐来虎牙啦~ - 演员方安娜,http://61.241.131.18/tx.rtmp.huya.com/1199539781556-1199539781556-5342535469039091712-2399079686568-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【重播】李嘉格的宅家KTV - 李嘉格是谁,http://61.241.131.18/tx.rtmp.huya.com/1199539642845-1199539642845-5341939709830496256-2399079409146-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【18点】《反贪风暴5》电影票+周边派送 - 虎牙观影团,http://61.241.131.18/tx.rtmp.huya.com/1524434075-1524434075-6547394497033011200-3048991606-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
糖水桃手绘动漫画画教程 - 糖水桃,http://61.241.131.18/tx.rtmp.huya.com/1199573588085-1199573588085-5487733405485367296-2399147299626-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
5.18日14点 倪秋云宅家唱跳秀 - 云儿,http://61.241.131.18/tx.rtmp.huya.com/1199540113602-1199540113602-5343961595749859328-2399080350660-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【重播】管轩老师深度讲解《厨戏痞》 - 演员管轩,http://61.241.131.18/tx.rtmp.huya.com/1199558641787-1199558641787-5423539544379097088-2399117407030-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
v_huya_1199576228143 - 龙小七a,http://61.241.131.18/tx.rtmp.huya.com/1199576228143-1199576228143-5499072368254910464-2399152579742-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
一个神经魔术师的vlog日记 - 火皇皇THREEH,http://61.241.131.18/tx.rtmp.huya.com/1199574962777-1199574962777-5493637662667440128-2399150049010-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - PENTAGON-高信源,http://61.241.131.18/tx.rtmp.huya.com/1099531773739-1099531773739-86526252231426048-2199063670934-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
v_huya_1199513205060 - 1905电影网,http://61.241.131.18/tx.rtmp.huya.com/1199513205060-1199513205060-5228390287876816896-2399026533576-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【最佳搭档】光头神探搞笑探案 - 陌离-小欣,http://61.241.131.18/tx.rtmp.huya.com/1448738224-1448738224-6222283292545122304-2789253866-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
貂妹电影—当幸福来敲门 - 貂妹电影,http://61.241.131.18/tx.rtmp.huya.com/2300495830-2300495830-9880554354434375680-4601115116-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 王北欧来了快跑,http://61.241.131.18/tx.rtmp.huya.com/1199573352290-1199573352290-5486720673671806976-2399146828036-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【重播】你的王冠逸来了，请签收 - 王冠逸Lawrence,http://61.241.131.18/tx.rtmp.huya.com/1199540071379-1199540071379-5343780249345720320-2399080266214-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【重播】魏宏宇与你相约深夜酒馆 - 魏宏宇WHY,http://61.241.131.18/tx.rtmp.huya.com/1199576903198-1199576903198-5501971707402911744-2399153929852-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【斌哥】破面十刃再次来现世！织姬被强行带走！15 - 斌哥漫说2,http://61.241.131.18/tx.rtmp.huya.com/1099531752809-1099531752809-86436358565920768-2199063629074-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
恐怖惊悚电影《木乃伊》！这才叫盗墓题材的电影 - 亮哥讲电影2,http://61.241.131.18/tx.rtmp.huya.com/1099531752810-1099531752810-86436362860888064-2199063629076-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 扁豆看电影2,http://61.241.131.18/tx.rtmp.huya.com/1099531752811-1099531752811-86436367155855360-2199063629078-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 狗哥吃火锅2,http://61.241.131.18/tx.rtmp.huya.com/1099531752812-1099531752812-86436371450822656-2199063629080-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
飞姐的观影报告，欢迎来看！ - 飞姐说电影,http://61.241.131.18/tx.rtmp.huya.com/1199573520971-1199573520971-5487445153050263552-2399147165398-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
搞笑视频大合集 - 沙雕影视逗你笑,http://61.241.131.18/tx.rtmp.huya.com/1199574923827-1199574923827-5493470373691260928-2399149971110-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
超新星联赛-赵瑾尧 - 赵瑾尧,http://61.241.131.18/tx.rtmp.huya.com/1199583161857-1199583161857-5528852443124727808-2399166447170-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到李咪饭直播间 - 李咪饭,http://61.241.131.18/tx.rtmp.huya.com/1199575951325-1199575951325-5497883443997966336-2399152026106-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
1 - 豆豆先生MrPea,http://61.241.131.18/tx.rtmp.huya.com/1199537946634-1199537946634-5334654539058380800-2399076016724-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
快来看奥特曼与小怪兽们的沙雕日常 - 神行大宝,http://61.241.131.18/tx.rtmp.huya.com/1199566321478-1199566321478-5456523566067482624-2399132766412-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是爆笑剧社，欢迎来到我的直播间 - 爆笑剧社,http://61.241.131.18/tx.rtmp.huya.com/1391381950-1391381950-5975939971494707200-2782887356-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【一起看】TALENT格雷万印象之夜颁奖礼 - 【娱乐虎星球】印象之夜,http://61.241.131.18/tx.rtmp.huya.com/1099531752865-1099531752865-86436599084089344-2199063629186-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
v_huya_1199574150350 - 走哪吃哪,http://61.241.131.18/tx.rtmp.huya.com/1199574150350-1199574150350-5490148315272052736-2399148424156-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【重播】徐圣恩虎牙首秀 做客深夜酒馆 - PB徐圣恩,http://61.241.131.18/tx.rtmp.huya.com/1199575658516-1199575658516-5496625838918991872-2399151440488-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间！ - 沙雕剧情梗中梗,http://61.241.131.18/tx.rtmp.huya.com/1199574937026-1199574937026-5493527062964600832-2399149997508-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
三口看电影 - 三口看电影,http://61.241.131.18/tx.rtmp.huya.com/1419932657-1419932657-6098564324337385472-4517672010-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【楚汉传奇】陈道明版刘邦 - 靠谱女青年高小婷,http://61.241.131.18/tx.rtmp.huya.com/1250011-1250011-5368756364640256-2789253854-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
战狼出击，火爆来袭 - Dae-奶桃-招接待歌手,http://61.241.131.18/tx.rtmp.huya.com/2295595343-2295595343-9859506923034902528-4591314142-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【大秦帝国】第三部崛起 - 舞王驾到,http://61.241.131.18/tx.rtmp.huya.com/1394575568-1394575568-5989656456360624128-2789274592-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【重播】娱乐大王牌往期正片 - 娱乐大王牌,http://61.241.131.18/tx.rtmp.huya.com/59301475-59301475-254697895729561600-3249804308-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
yzl的直播间 - 西环习,http://61.241.131.18/tx.rtmp.huya.com/1279520356502-1279520356502-16815095850614128640-2559040836460-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
63岁老奶奶演唱花再开，瞬间治愈了小心脏 - 白泽字幕1号,http://61.241.131.18/tx.rtmp.huya.com/1199562244544-1199562244544-5439013267869532160-2399124612544-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
水浒后传21可爱版吴京 - 虎牙影视厅,http://61.241.131.18/tx.rtmp.huya.com/2293368312-2293368312-9849941897722724352-4586860080-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【重播】芒种原唱赵方婧--宅家音乐会 - 赵方婧wimi,http://61.241.131.18/tx.rtmp.huya.com/1448061803-1448061803-6219378086471794688-3020642988-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到舒克影视梗的直播间 - 舒克影视梗,http://61.241.131.18/tx.rtmp.huya.com/1199573448927-1199573448927-5487135726426390528-2399147021310-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到校长谈恋爱的直播间 - 校长谈恋爱,http://61.241.131.18/tx.rtmp.huya.com/418619137-418619137-1797955502894743552-837361730-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间 - 韦支书野狼团,http://61.241.131.18/tx.rtmp.huya.com/1199575624660-1199575624660-5496480428506218496-2399151372776-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
群雄逐鹿，窃符救赵 - 张医生,http://61.241.131.18/tx.rtmp.huya.com/1394575537-1394575537-5989656323216637952-2789274530-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 光头强老师,http://61.241.131.18/tx.rtmp.huya.com/1199575778792-1199575778792-5497142420405485568-2399151681040-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎大家来看我的直播间 - 调酒师-扬扬,http://61.241.131.18/tx.rtmp.huya.com/1466594883-1466594883-6298977058965946368-2933313222-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到我的直播间！ - 沙雕梗叔叔,http://61.241.131.18/tx.rtmp.huya.com/1199574927961-1199574927961-5493488129086062592-2399149979378-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
null - 酒后探真言,http://61.241.131.18/tx.rtmp.huya.com/1099531728484-1099531728484-86331883486445568-2199063580424-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
香gang贺岁片爆笑来袭 - 是红鲤鱼绿鲤鱼与驴,http://61.241.131.18/tx.rtmp.huya.com/1099531752755-1099531752755-86436126637686784-2199063628966-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
直播回放 - PENTAGON-WOOSEOK,http://61.241.131.18/tx.rtmp.huya.com/1099531773723-1099531773723-86526183511949312-2199063670902-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
你最喜欢哪位网红女神呢，快召唤出来 - 仕玲沙画,http://61.241.131.18/tx.rtmp.huya.com/1199573603924-1199573603924-5487801433472368640-2399147331304-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
【经典电视剧】寻秦记 Part 2 - 方头人讲故事,http://61.241.131.18/tx.rtmp.huya.com/1444264131-1444264131-6203067209430859776-2884953448-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
南昌校厂东9号谢谢订阅。不定时户外直播 - 校厂东九号,http://61.241.131.18/tx.rtmp.huya.com/1449668638-1449668638-6226279390246862848-2382707714-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
PGC节目主流测试 - 大呲花w,http://61.241.131.18/tx.rtmp.huya.com/1199535464684-1199535464684-5323994644978073600-2399071052824-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
null - 大学Z课堂,http://61.241.131.18/tx.rtmp.huya.com/1332350287-1332350287-5722400909481213952-2544613050-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
欢迎来到左手的扑克v的直播间 - 左手的扑克v,http://61.241.131.18/tx.rtmp.huya.com/1199540686927-1199540686927-5346424007874838528-2399081497310-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - NCT127-道英,http://61.241.131.18/tx.rtmp.huya.com/1099531789958-1099531789958-86595912305999872-2199063703372-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 搞笑007,http://61.241.131.18/tx.rtmp.huya.com/1199576237065-1199576237065-5499110687953125376-2399152597586-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
我是一颗小虎牙 - 鹿眸精彩对局,http://61.241.131.18/tx.rtmp.huya.com/1099531786608-1099531786608-86581524165558272-2199063696672-10057-A-0-1.m3u8?%E5%85%B3%E6%B3%A8%E5%BE%AE%E4%BF%A1%E5%85%AC%E4%BC%97%E5%8F%B7[%E6%99%B4%E5%9B%AD]
👶少儿,#genre#
金鹰卡通,http://59.44.10.113:9901/tsfile/live/1063_1.m3u8
金鹰卡通,http://39.134.115.163:8080/PLTV/88888910/224/3221225721/index.m3u8
金鹰卡通,http://183.207.249.5:80/PLTV/4/224/3221226303/index.m3u8?
动漫秀场,http://39.135.55.105:6610/PLTV/88888888/224/3221227071/index.m3u8?servicetype=1
动漫秀场,http://59.44.10.113:9901/tsfile/live/1086_1.m3u8
动漫秀场,http://112.25.47.24/gitv_live/G_DONGMANXC/G_DONGMANXC.m3u8
哈哈炫动,http://shbu.live.bestvcdn.com.cn:8080/live/program/live/hhxdhd/4000000/mnf.m3u8
哈哈炫动,http://39.135.138.59:18890/PLTV/88888910/224/3221225720/index.m3u8
北京少儿,http://111.59.189.40:8445/tsfile/live/1015_1.m3u8
北京少儿,http://221.179.136.150:443/PLTV/88888888/224/3221226558/1.m3u8
南京少兒,http://live.nbs.cn/channels/njtv/sepd/m3u8:500k/live.m3u8
浙江少兒,http://hw-m-l.cztv.com/channels/lantian/channel08/1080p.m3u8?k=1a7559a51eeb880b021619a07f463ac4&t=1577153787
福州少儿,http://live.zohi.tv/video/s10001-sepd-4/index.m3u8
深圳少儿,http://ye23.win/iptv/sztv.php?id=7
嘉佳卡通,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221226193/index.m3u8
优漫卡通,http://183.207.249.15:80/PLTV/4/224/3221225933/index.m3u8?
动画乐园,http://211.94.219.178:18080/PLTV/68/224/3221226406/index.m3u8
中华小当家,http://106.53.212.251/daili/bili.php?id=655291
樱桃小丸子,http://106.53.212.251/daili/bili.php?id=11765640
蜡笔小新,http://106.53.212.251/daili/bili.php?id=11579951
猫和老鼠,http://121.51.14.14/tx.hls.huya.com/src/1423782038-1423782038-6115097289842229248-2847687532-10057-A-0-1.m3u8
小猪佩奇,http://baiducdncmn2.inter.iqiyi.com/tslive/c53_lb_78_1080P_t10/c53_lb_78_1080P_t10.m3u8
海绵宝宝,http://121.51.14.14/tx.hls.huya.com/src/1423782096-1423782096-6115097538950332416-2847687648-10057-A-0-1_2000.m3u8
童年经典,http://118.26.120.23:55336/tslive/c57_lb_211_600_t10/c57_lb_211_600_t10.m3u8?key=0f2a06793124310bce6ba95fc0ac76131
玩具乐园,http://118.26.120.37:55336/tslive/c54_lb_175_600_t10/c54_lb_175_600_t10.m3u8?key=051d9240247766709d65dde3fcd5cd7bb
猫和老鼠,http://118.26.120.23:55336/tslive/c52_lb_83_600_t10/c52_lb_83_600_t10.m3u8?key=0b292c335e5837e94e2f0ba45f46717fa
怀旧动画,http://118.26.120.36:55336/tslive/c53_lb_86_600_t10/c53_lb_86_600_t10.m3u8?key=0b292c335e5837e943a226d3c381f872a
巧虎,http://118.26.120.37:55336/tslive/c55_lb_135_600_t10/c55_lb_135_600_t10.m3u8?key=0f2a06793124310bcefefdf4e48b17f9a
小猪佩寄,http://118.26.120.23:55336/tslive/c53_lb_78_600_t10/c53_lb_78_600_t10.m3u8?key=0b292c335e5837e94a815c2c45ffe0057
宝宝课堂,http://118.26.120.23:55336/tslive/c57_lb_225_600_t10/c57_lb_225_600_t10.m3u8?key=0b292c335e5837e94abaa8d3135e83ce3
宝宝巴士,http://118.26.120.35:55336/tslive/c55_lb_153_720P_t10/c55_lb_153_720P_t10.m3u8?key=0b292c335e5837e947f9409c59228f3e6
奥特曼,http://118.26.120.35:55336/tslive/c57_lb_210_600_t10/c57_lb_210_600_t10.m3u8?key=0b292c335e5837e94abe4b846218bbc95
喜羊羊,http://118.26.120.23:55336/tslive/c55_lb_91_1080P_t10/c55_lb_91_1080P_t10.m3u8?key=0b292c335e5837e943e554ef181bdcec1
名贞探柯南,http://118.26.120.23:55336/tslive/c54_lb_157_600_t10/c54_lb_157_600_t10.m3u8?key=0b292c335e5837e948e91dd5d11efa525
动画电影,http://118.26.120.36:55336/tslive/c51_lb_118_600_t10/c51_lb_118_600_t10.m3u8?key=0b292c335e5837e94f25985f7c35b1efe
动画小天地,http://118.26.120.34:55336/tslive/c55_lb_139_600_t10/c55_lb_139_600_t10.m3u8?key=0f2a06793124310bc475d77d809f3ab51
儿童乐园,http://118.26.120.23:55336/tslive/c57_lb_215_600_t10/c57_lb_215_600_t10.m3u8?key=0b292c335e5837e943410c2bfa7a7387e
儿歌大全,http://118.26.120.23:55336/tslive/c57_lb_242_600_t10/c57_lb_242_600_t10.m3u8?key=0f2a06793124310bc8499ebf63370c51a
倒霉熊,http://118.26.120.37:55336/tslive/c54_lb_140_600_t10/c54_lb_140_600_t10.m3u8?key=0f2a06793124310bccc587b5da61b57da
亲子启蒙,http://118.26.120.23:55336/tslive/c57_lb_213_600_t10/c57_lb_213_600_t10.m3u8?key=0f2a06793124310bc21adebc9f02a9735
倒霉特熊,https://newcntv.qcloudcdn.com/asp/hls/1200/0303000a/3/default/87f87ba569c147e3805f80e4844d2de9/1200.m3u8
雲朵妈妈,https://newcntv.qcloudcdn.com/asp/hls/1200/0303000a/3/default/d8ad434c6b08421a927557a4d98da65c/1200.m3u8
反转星球,https://newcntv.qcloudcdn.com/asp/hls/1200/0303000a/3/default/3ccdecc7d6e341c1920ad4eac5d82f38/1200.m3u8
熊大熊二,https://newcntv.qcloudcdn.com/asp/hls/1200/0303000a/3/default/1733da751de64e6e910abda889d87a26/1200.m3u8
熊大过年,https://newcntv.qcloudcdn.com/asp/hls/1200/0303000a/3/default/7ae265653fe149069c3b53e31caaf060/1200.m3u8
狮子王國,https://newcntv.qcloudcdn.com/asp/hls/850/0303000a/3/default/c2e7e767f3144bed959ef20b8b961fe5/850.m3u8
😊堆堆,#genre#
埋堆堆1,http://txtest-xp2p.p2p.huya.com/src/1199561277675-1199561277675-5434860597135015936-2399122678806-10057-A-0-1.xs
埋堆堆2,http://txtest-xp2p.p2p.huya.com/src/1199563477578-1199563477578-5444309108574388224-2399127078612-10057-A-0-1.xs
埋堆堆3,http://txtest-xp2p.p2p.huya.com/src/1199561226091-1199561226091-5434639045542019072-2399122575638-10057-A-0-1.xs
埋堆堆4,http://txtest-xp2p.p2p.huya.com/src/1199563478941-1199563478941-5444314962614812672-2399127081338-10057-A-0-1.xs
埋堆堆5,http://txtest-xp2p.p2p.huya.com/src/1199563995872-1199563995872-5446535164354101248-2399128115200-10057-A-0-1.xs
埋堆堆6,http://txtest-xp2p.p2p.huya.com/src/1199563484986-1199563484986-5444340925692116992-2399127093428-10057-A-0-1.xs
埋堆堆7,http://txtest-xp2p.p2p.huya.com/src/1199561181108-1199561181108-5434445845028143104-2399122485672-10057-A-0-1.xs
埋堆堆8,http://txtest-xp2p.p2p.huya.com/src/1199563481163-1199563481163-5444324506032144384-2399127085782-10057-A-0-1.xs
埋堆堆9,http://txtest-xp2p.p2p.huya.com/src/1199563491091-1199563491091-5444367146467459072-2399127105638-10057-A-0-1.xs
埋堆堆10,http://txtest-xp2p.p2p.huya.com/src/1199563479466-1199563479466-5444317217472643072-2399127082388-10057-A-0-1.xs
埋堆堆11,http://txtest-xp2p.p2p.huya.com/src/1199561179151-1199561179151-5434437439777144832-2399122481758-10057-A-0-1.xs
埋堆堆12,http://txtest-xp2p.p2p.huya.com/src/1199561223711-1199561223711-5434628823519854592-2399122570878-10057-A-0-1.xs
埋堆堆13,http://txtest-xp2p.p2p.huya.com/src/1199561223732-1199561223732-5434628913714167808-2399122570920-10057-A-0-1.xs
埋堆堆14,http://txtest-xp2p.p2p.huya.com/src/1199561245453-1199561245453-5434722204698804224-2399122614362-10057-A-0-1.xs
埋堆堆15,http://txtest-xp2p.p2p.huya.com/src/1199563479551-1199563479551-5444317582544863232-2399127082558-10057-A-0-1.xs
埋堆堆16,http://txtest-xp2p.p2p.huya.com/src/1199564003640-1199564003640-5446568527660056576-2399128130736-10057-A-0-1.xs
埋堆堆17,http://txtest-xp2p.p2p.huya.com/src/1199561217760-1199561217760-5434603264169476096-2399122558976-10057-A-0-1.xs
埋堆堆18,http://txtest-xp2p.p2p.huya.com/src/1199563995848-1199563995848-5446535061274886144-2399128115152-10057-A-0-1.xs
埋堆堆19,http://txtest-xp2p.p2p.huya.com/src/1199563478721-1199563478721-5444314017722007552-2399127080898-10057-A-0-1.xs
埋堆堆20,http://txtest-xp2p.p2p.huya.com/src/1199561185548-1199561185548-5434464914682937344-2399122494552-10057-A-0-1.xs
埋堆堆21,http://txtest-xp2p.p2p.huya.com/src/1199564062365-1199564062365-5446820749614514176-2399128248186-10057-A-0-1.xs
埋堆堆22,http://txtest-xp2p.p2p.huya.com/src/1199563478540-1199563478540-5444313240332926976-2399127080536-10057-A-0-1.xs
埋堆堆23,http://txtest-xp2p.p2p.huya.com/src/1199563493375-1199563493375-5444376956172763136-2399127110206-10057-A-0-1.xs
埋堆堆24[848476],http://txtest-xp2p.p2p.huya.com/src/1199561181026-1199561181026-5434445492840824832-2399122485508-10057-A-0-1.xs
埋堆堆25,http://txtest-xp2p.p2p.huya.com/src/1199561158071-1199561158071-5434346901866545152-2399122439598-10057-A-0-1.xs
埋堆堆26,http://txtest-xp2p.p2p.huya.com/src/1199561182641-1199561182641-5434452429213007872-2399122488738-10057-A-0-1.xs
埋堆堆27,http://txtest-xp2p.p2p.huya.com/src/1199561177177-1199561177177-5434428961511702528-2399122477810-10057-A-0-1.xs
埋堆堆28,http://txtest-xp2p.p2p.huya.com/src/1199561462555-1199561462555-5435654650688700416-2399123048566-10057-A-0-1.xs
埋堆堆29,http://txtest-xp2p.p2p.huya.com/src/1199563479615-1199563479615-5444317857422770176-2399127082686-10057-A-0-1.xs
埋堆堆30[848476],http://txtest-xp2p.p2p.huya.com/src/1199561277686-1199561277686-5434860644379656192-2399122678828-10057-A-0-1.xs
埋堆堆31,http://txtest-xp2p.p2p.huya.com/src/1199561391895-1199561391895-5435351168299565056-2399122907246-10057-A-0-1.xs
埋堆堆32,http://txtest-xp2p.p2p.huya.com/src/1199563491137-1199563491137-5444367344035954688-2399127105730-10057-A-0-1.xs
埋堆堆33,http://txtest-xp2p.p2p.huya.com/src/1199563459301-1199563459301-5444230609457119232-2399127042058-10057-A-0-1.xs
埋堆堆34,http://txtest-xp2p.p2p.huya.com/src/1199563459301-1199563459301-5444230609457119232-2399127042058-10057-A-0-1.xs
埋堆堆35,http://txtest-xp2p.p2p.huya.com/src/1199561277694-1199561277694-5434860678739394560-2399122678844-10057-A-0-1.xs
埋堆堆36,http://txtest-xp2p.p2p.huya.com/src/1199561178473-1199561178473-5434434527789318144-2399122480402-10057-A-0-1.xs
埋堆堆37,http://txtest-xp2p.p2p.huya.com/src/1199564000752-1199564000752-5446556123794505728-2399128124960-10057-A-0-1.xs
埋堆堆38,http://txtest-xp2p.p2p.huya.com/src/1199561179116-1199561179116-5434437289453289472-2399122481688-10057-A-0-1.xs
埋堆堆39,http://txtest-xp2p.p2p.huya.com/src/1199561276781-1199561276781-5434856757434253312-2399122677018-10057-A-0-1.xs
埋堆堆40,http://txtest-xp2p.p2p.huya.com/src/1199563483195-1199563483195-5444333233405689856-2399127089846-10057-A-0-1.xs
埋堆堆41,http://txtest-xp2p.p2p.huya.com/src/1199561240999-1199561240999-5434703074914467840-2399122605454-10057-A-0-1.xs
埋堆堆42,http://txtest-xp2p.p2p.huya.com/src/1199561276760-1199561276760-5434856667239940096-2399122676976-10057-A-0-1.xs
埋堆堆43,http://txtest-xp2p.p2p.huya.com/src/1199564061580-1199564061580-5446817378065186816-2399128246616-10057-A-0-1.xs
埋堆堆44,http://txtest-xp2p.p2p.huya.com/src/1199561241049-1199561241049-5434703289662832640-2399122605554-10057-A-0-1.xs
埋堆堆45,http://txtest-xp2p.p2p.huya.com/src/1199561218716-1199561218716-5434607370158211072-2399122560888-10057-A-0-1.xs
埋堆堆46,http://txtest-xp2p.p2p.huya.com/src/1199563489752-1199563489752-5444361395506249728-2399127102960-10057-A-0-1.xs
埋堆堆47,http://txtest-xp2p.p2p.huya.com/src/1199561244004-1199561244004-5434715981291192320-2399122611464-10057-A-0-1.xs
埋堆堆48,http://txtest-xp2p.p2p.huya.com/src/1199564060588-1199564060588-5446813117457629184-2399128244632-10057-A-0-1.xs
埋堆堆49,http://txtest-xp2p.p2p.huya.com/src/1199563481280-1199563481280-5444325008543318016-2399127086016-10057-A-0-1.xs
埋堆堆50,http://txtest-xp2p.p2p.huya.com/src/1199561153241-1199561153241-5434326157174505472-2399122429938-10057-A-0-1.xs
埋堆堆51,http://txtest-xp2p.p2p.huya.com/src/1199561277724-1199561277724-5434860807588413440-2399122678904-10057-A-0-1.xs
埋堆堆52,http://txtest-xp2p.p2p.huya.com/src/1199561463578-1199561463578-5435659044440244224-2399123050612-10057-A-0-1.xs
埋堆堆53,http://txtest-xp2p.p2p.huya.com/src/1199564067003-1199564067003-5446840669672833024-2399128257462-10057-A-0-1.xs
埋堆堆54,http://txtest-xp2p.p2p.huya.com/src/1199563478867-1199563478867-5444314644787232768-2399127081190-10057-A-0-1.xs
埋堆堆55,http://txtest-xp2p.p2p.huya.com/src/1199561219773-1199561219773-5434611909938642944-2399122563002-10057-A-0-1.xs
埋堆堆56,http://txtest-xp2p.p2p.huya.com/src/1199563486009-1199563486009-5444345319443660800-2399127095474-10057-A-0-1.xs
埋堆堆57,http://txtest-xp2p.p2p.huya.com/src/1199561276763-1199561276763-5434856680124841984-2399122676982-10057-A-0-1.xs
埋堆堆58,http://txtest-xp2p.p2p.huya.com/src/1199561176260-1199561176260-5434425023026692096-2399122475976-10057-A-0-1.xs
埋堆堆59,http://txtest-xp2p.p2p.huya.com/src/1199561462555-1199561462555-5435654650688700416-2399123048566-10057-A-0-1.xs
埋堆堆60,http://txtest-xp2p.p2p.huya.com/src/1199563479466-1199563479466-5444317217472643072-2399127082388-10057-A-0-1.xs
埋堆堆61,http://txtest-xp2p.p2p.huya.com/src/1199561153167-1199561153167-5434325839346925568-2399122429790-10057-A-0-1.xs
埋堆堆63,http://txtest-xp2p.p2p.huya.com/src/1199561182641-1199561182641-5434452429213007872-2399122488738-10057-A-0-1.xs
埋堆堆64,http://txtest-xp2p.p2p.huya.com/src/1199561177177-1199561177177-5434428961511702528-2399122477810-10057-A-0-1.xs
埋堆堆65,http://txtest-xp2p.p2p.huya.com/src/1199563564801-1199563564801-5444683728506847232-2399127253058-10057-A-0-1.xs
埋堆堆66,http://txtest-xp2p.p2p.huya.com/src/1199563488528-1199563488528-5444356138466279424-2399127100512-10057-A-0-1.xs
埋堆堆67[848*476],http://txtest-xp2p.p2p.huya.com/src/1199561181026-1199561181026-5434445492840824832-2399122485508-10057-A-0-1.xs
埋堆堆68,http://txtest-xp2p.p2p.huya.com/src/1199561158071-1199561158071-5434346901866545152-2399122439598-10057-A-0-1.xs

👍NewTv,#genre#
NewTV爱情喜剧,http://39.135.55.105:6610/PLTV/88888888/224/3221225877/index.m3u8?servicetype=1
NewTV超级电视剧,http://39.134.115.163:8080/PLTV/88888910/224/3221225625/index.m3u8
NewTV超级体育,http://39.135.138.58:18890/PLTV/88888888/224/3221225622/index.m3u8
NewTV超级体育,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225767/index.m3u8
NewTV超级综艺,http://39.135.138.58:18890/PLTV/88888888/224/3221225620/index.m3u8
NewTV超级综艺,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225768/index.m3u8
NewTV潮妈辣婆 4M1080,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225708/index.m3u8
NewTV潮妈辣婆,http://39.135.55.105:6610/PLTV/88888888/224/3221226107/index.m3u8?servicetype=1
NewTV东北热剧,http://39.135.138.58:18890/PLTV/88888888/224/3221226202/index.m3u8
NewTV东北热剧,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221226202/index.m3u8
NewTV动作电影,http://39.135.55.105:6610/PLTV/88888888/224/3221225879/index.m3u8?servicetype=1
NewTV古装剧场 4M1080,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225678/index.m3u8
NewTV古装剧场,http://39.135.55.105:6610/PLTV/88888888/224/3221225880/index.m3u8?servicetype=1
NewTV海外剧场 4M1080,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225712/index.m3u8
NewTV欢乐剧场,http://39.135.138.58:18890/PLTV/88888888/224/3221226210/index.m3u8
NewTV欢乐剧场,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221226210/index.m3u8
NewTV家庭剧场,http://111.40.196.9/PLTV/88888888/224/3221225626/index.m3u8
NewTV家庭剧场,http://39.135.55.105:6610/PLTV/88888888/224/3221225882/index.m3u8?servicetype=1
NewTV家庭剧场,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225713/index.m3u8
NewTV金牌综艺,http://111.40.196.9/PLTV/88888888/224/3221225650/index.m3u8
NewTV金牌综艺,http://39.135.55.105:6610/PLTV/88888888/224/3221225884/index.m3u8?servicetype=1
NewTV金牌综艺,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225711/index.m3u8
NewTV惊悚悬疑,http://39.135.55.105:6610/PLTV/88888888/224/3221225885/index.m3u8?servicetype=1
NewTV精品大剧 4M1080,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225714/index.m3u8
NewTV精品大剧,http://39.135.55.105:6610/PLTV/88888888/224/3221225889/index.m3u8?servicetype=1
NewTV精品纪录 2.5M1080,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225710/index.m3u8
NewTV精品纪录,http://39.135.55.105:6610/PLTV/88888888/224/3221225888/index.m3u8?servicetype=1
NewTV精品体育 4M1080,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225709/index.m3u8
NewTV精品体育,http://39.135.55.105:6610/PLTV/88888888/224/3221225886/index.m3u8?servicetype=1
NewTV精品综合,http://111.40.196.9/PLTV/88888888/224/3221225632/index.m3u8
NewTV军旅剧场 4M1080,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225669/index.m3u8
NewTV军旅剧场,http://39.135.55.105:6610/PLTV/88888888/224/3221225887/index.m3u8?servicetype=1
NewTV军事评论,http://111.40.196.9/PLTV/88888888/224/3221225634/index.m3u8
NewTV军事评论,http://39.135.55.105:6610/PLTV/88888888/224/3221225890/index.m3u8?servicetype=1
NewTV军事评论,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225757/index.m3u8
NewTV明星大片,http://39.135.55.105:6610/PLTV/88888888/224/3221225893/index.m3u8?servicetype=1
NewTV明星大片,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225716/index.m3u8
NewTV农业致富,http://111.40.196.9/PLTV/88888888/224/3221225636/index.m3u8
NewTV农业致富,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225670/index.m3u8
NewTV武搏世界,http://111.40.196.9/PLTV/88888888/224/3221225664/index.m3u8
NewTV武搏世界,http://39.135.55.105:6610/PLTV/88888888/224/3221225895/index.m3u8?servicetype=1
NewTV武搏世界,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225656/index.m3u8
NewTV炫舞未来,http://39.135.138.58:18890/PLTV/88888888/224/3221225707/index.m3u8
NewTV炫舞未来,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225707/index.m3u8
NewTV怡伴健康 4M1080,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225666/index.m3u8
NewTV怡伴健康,http://39.135.55.105:6610/PLTV/88888888/224/3221225883/index.m3u8?servicetype=1
NewTV中国功夫,http://111.40.196.9/PLTV/88888888/224/3221225678/index.m3u8
NewTV中国功夫,http://39.135.55.105:6610/PLTV/88888888/224/3221225896/index.m3u8?servicetype=1
NewTV中国功夫,http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225660/index.m3u8

📼轮播,#genre#
MIGU古天乐影院,http://117.148.179.176/PLTV/88888888/224/3221231645/index.m3u8
MIGU成龙作品集,http://117.148.179.163/PLTV/88888888/224/3221231687/index.m3u8
MIGU张国荣影院,http://117.148.179.177/PLTV/88888888/224/3221231790/index.m3u8
MIGU高分影院,http://117.148.179.182/PLTV/88888888/224/3221231699/index.m3u8
MIGU周润发影院,http://117.148.179.177/PLTV/88888888/224/3221231709/index.m3u8
MIGU怀旧老片,http://117.148.179.146/PLTV/88888888/224/3221231513/index.m3u8
MIGU周星驰影院,http://117.148.179.153/PLTV/88888888/224/3221231562/index.m3u8
MIGU午夜失眠剧场,http://117.148.179.141/PLTV/88888888/224/3221231516/index.m3u8
MIGU吴京作品集,http://117.148.179.183/PLTV/88888888/224/3221231564/index.m3u8
MIGU云上电影院,http://117.148.179.176/PLTV/88888888/224/3221231565/index.m3u8
MIGU每日科幻电影,http://117.148.179.160/PLTV/88888888/224/3221231568/index.m3u8
MIGU葛优作品集,http://117.148.179.139/PLTV/88888888/224/3221231754/index.m3u8
MIGU刘德华影院,http://117.148.179.154/PLTV/88888888/224/3221231757/index.m3u8
MIGU僵尸剧场,http://117.148.179.165/PLTV/88888888/224/3221231742/index.m3u8
MIGU刘亦菲影视展播,http://117.148.179.165/PLTV/88888888/224/3221231787/index.m3u8
MIGUTVB剧场,http://117.148.179.157/PLTV/88888888/224/3221231733/index.m3u8
MIGU金庸频道,http://117.148.179.132/PLTV/88888888/224/3221231477/index.m3u8
MIGU新片放映厅,http://117.148.179.160/PLTV/88888888/224/3221231640/index.m3u8
MIGU试胆大会,http://117.148.179.166/PLTV/88888888/224/3221231672/index.m3u8
MIGU高能烧脑时刻,http://117.148.179.169/PLTV/88888888/224/3221231504/index.m3u8
MIGU杨幂作品集,http://117.148.179.183/PLTV/88888888/224/3221231556/index.m3u8
MIGU4K剧场,http://117.148.179.161/PLTV/88888888/224/3221231624/index.m3u8
MIGU爱情公寓,http://117.148.179.160/PLTV/88888888/224/3221231583/index.m3u8
MIGU军旅剧场,http://117.148.179.145/PLTV/88888888/224/3221231585/index.m3u8
MIGUSNH48剧场公演,http://117.148.179.139/PLTV/88888888/224/3221231622/index.m3u8
MIGU红色谍战剧场,http://117.148.179.169/PLTV/88888888/224/3221231627/index.m3u8
MIGU神探狄仁杰,http://117.148.179.139/PLTV/88888888/224/3221231634/index.m3u8
MIGU黄金剧场,http://117.148.179.183/PLTV/88888888/224/3221231637/index.m3u8
MIGU追剧少女,http://117.148.179.179/PLTV/88888888/224/3221231643/index.m3u8
MIGU古龙作品集,http://117.148.179.160/PLTV/88888888/224/3221231657/index.m3u8
MIGU经典贺岁片,http://117.148.179.159/PLTV/88888888/224/3221231679/index.m3u8
MIGU每日荐影,http://117.148.179.162/PLTV/88888888/224/3221231727/index.m3u8
MIGU武侠剧场,http://117.148.179.160/PLTV/88888888/224/3221231763/index.m3u8
周润发影院,http://112.74.200.9:88/tv000000/m3u8.php?/migu/639526984
古龙作品集,http://112.74.200.9:88/tv000000/m3u8.php?/migu/639528313
周星驰影院,http://112.74.200.9:88/tv000000/m3u8.php?/migu/623338112
成龙作品集,http://112.74.200.9:88/tv000000/m3u8.php?/migu/707671890
张国荣影院,http://112.74.200.9:88/tv000000/m3u8.php?/migu/707689526
郭富城影院,http://112.74.200.9:88/tv000000/m3u8.php?/migu/639528330
刘德华影院,http://112.74.200.9:88/tv000000/m3u8.php?/migu/659315648
金庸频道,http://112.74.200.9:88/tv000000/m3u8.php?/migu/625774640
新片放映厅,http://112.74.200.9:88/tv000000/m3u8.php?/migu/619495952
高分影院,http://112.74.200.9:88/tv000000/m3u8.php?/migu/627198191
欢笑剧场,http://112.74.200.9:88/tv000000/m3u8.php?/migu/623674859
盗墓,http://112.74.200.9:88/tv000000/m3u8.php?/migu/625525181
经典影视速看,http://112.74.200.9:88/tv000000/m3u8.php?/migu/627198751
试胆大会,http://112.74.200.9:88/tv000000/m3u8.php?/migu/637483721
高能烧脑时刻,http://112.74.200.9:88/tv000000/m3u8.php?/migu/625542365
杨幂影院,http://112.74.200.9:88/tv000000/m3u8.php?/migu/625542372
刘亦菲影视展播,http://112.74.200.9:88/tv000000/m3u8.php?/migu/639528386
咪咕云上电影院,http://112.74.200.9:88/tv000000/m3u8.php?/migu/625703337
咪咕暑期剧场[852480],http://112.74.200.9:88/tv000000/m3u8.php?/migu/627198692
黄金剧场,http://112.74.200.9:88/tv000000/m3u8.php?/migu/625155140
军旅剧场,http://112.74.200.9:88/tv000000/m3u8.php?/migu/625643517
少林剧场,http://112.74.200.9:88/tv000000/m3u8.php?/migu/625526423
高清大片,http://112.74.200.9:88/tv000000/m3u8.php?/migu/629943678
古天乐影院,http://112.74.200.9:88/tv000000/m3u8.php?/migu/627198610
热剧联播,http://112.74.200.9:88/tv000000/m3u8.php?/migu/629943613
喜剧联盟,http://112.74.200.9:88/tv000000/m3u8.php?/migu/637444830
僵尸剧场,http://112.74.200.9:88/tv000000/m3u8.php?/migu/627033504
深夜失眠剧场,http://112.74.200.9:88/tv000000/m3u8.php?/migu/625759558
神探狄仁杰,http://112.74.200.9:88/tv000000/m3u8.php?/migu/625574493
经典贺岁片,http://112.74.200.9:88/tv000000/m3u8.php?/migu/625774662
每日科幻电影,http://112.74.200.9:88/tv000000/m3u8.php?/migu/625204865
追剧少女,http://112.74.200.9:88/tv000000/m3u8.php?/migu/617432318
九品芝麻官,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3000/772/806/3000772806/media/3000772806_5007936463_56.mp4
国产凌凌漆,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5102/246/404/5102246404/media/5102246404_5010775029_56.mp4
大内密探零零发,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3008/060/310/3008060310/media/3008060310_5010015837_56.mp4
百变星君,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3008/060/201/3008060201/media/3008060201_5010281061_56.mp4
新喜剧之王[1702720],http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5102/164/641/5102164641/media/5102164641_5008640673_56.mp4
唐伯虎点秋香,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3000/749/847/3000749847/media/3000749847_5008064728_56.mp4
家有喜事[1290720],http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3000/749/609/3000749609/media/3000749609_5007812178_56.mp4
赌侠1,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3000/773/032/3000773032/media/3000773032_5008078893_56.mp4
赌侠2,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3003/325/487/3003325487/media/3003325487_5007936432_56.mp4
整蛊专家,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3005/714/518/3005714518/media/3005714518_5008026369_56.mp4
97家有喜事,http://hlsmgspdl.miguvideo.com:8080/depository_wx/asset/zhengshi/3003/202/807/3003202807/media/3003202807_5008153265_56.mp4
望夫成龙[1330720],http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3008/060/090/3008060090/media/3008060090_5009503734_56.mp4
功夫,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5103/094/406/5103094406/media/5103094406_5010338342_56.mp4
义胆群英,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5102/335/046/5102335046/media/5102335046_5008092127_56.mp4
逃学威龙2[1288721],http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3000/812/953/3000812953/media/3000812953_5008704896_56.mp4
逃学威龙,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3000/812/356/3000812356/media/3000812356_5010754957_56.mp4
风雨同路,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3008/242/441/3008242441/media/3008242441_5010757141_56.mp4
霹雳先锋[1340720],http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3008/060/421/3008060421/media/3008060421_5010098029_56.mp4
龙在江湖,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5102/747/338/5102747338/media/5102747338_5007904517_56.mp4
赌侠1999,http://hlsmgspdl.miguvideo.com:8080/depository_wx/asset/zhengshi/3008/081/561/3008081561/media/3008081561_5008436231_56.mp4
赌侠大战拉斯韦加斯,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5100/161/724/5100161724/media/5100161724_5008134652_56.mp4
拆弹专家2,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5102/239/218/5102239218/media/5102239218_5009740014_56.mp4
解救吾先生,http://hlsmgspdl.miguvideo.com:8080/depository_wx/asset/zhengshi/3009/414/915/3009414915/media/3009414915_5008281103_56.mp4
扫毒2：天地对决,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5102/226/277/5102226277/media/5102226277_5007471064_56.mp4
无间道[1662720],http://hlsmgspdl.miguvideo.com:8080/depository_sjq/asset/zhengshi/3006/997/475/3006997475/media/3006997475_5005388141_56.mp4
富贵兵团,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5102/744/026/5102744026/media/5102744026_5007785649_56.mp4
刀剑笑,http://hlsmgspdl.miguvideo.com:8080/depository_wx/asset/zhengshi/3012/394/882/3012394882/media/3012394882_5008454747_56.mp4
天若有情[640336],http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5100/135/048/5100135048/media/5100135048_5007950312_455.mp4
新上海滩,http://hlsmgspdl.miguvideo.com:8080/depository_wx/asset/zhengshi/3008/081/608/3008081608/media/3008081608_5008525655_56.mp4
至尊三十六计,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3005/715/543/3005715543/media/3005715543_5008451389_56.mp4
风暴,http://hlsmgspdl.miguvideo.com:8080/depository_wx/asset/zhengshi/3005/004/540/3005004540/media/3005004540_5008243276_56.mp4
醉拳2[1282721],http://hlsmgspdl.miguvideo.com:8080/depository_sjq/asset/zhengshi/1003/564/004/1003564004/media/1003564004_1015152488_56.mp4
红番区,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5100/178/304/5100178304/media/5100178304_5007090905_56.mp4
龙牌之谜[1345720],http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5102/366/817/5102366817/media/5102366817_5008085464_56.mp4
解忧杂货店[1736720],http://hlsmgspdl.miguvideo.com:8080/depository_wx/asset/zhengshi/5101/049/700/5101049700/media/5101049700_5008223818_56.mp4
机器之血[1736720],http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5100/178/014/5100178014/media/5100178014_5010510591_56.mp4
天将雄师[1600720],http://hlsmgspdl.miguvideo.com:8080/depository_wx/asset/zhengshi/3006/707/981/3006707981/media/3006707981_5008523585_56.mp4
警察故事2013,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5100/184/904/5100184904/media/5100184904_5008131542_56.mp4
十二生肖,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3002/076/865/3002076865/media/3002076865_5008090286_56.mp4
功夫之王[1682720],http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5100/174/147/5100174147/media/5100174147_5008700930_56.mp4
玻璃樽[1696720],http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3004/303/336/3004303336/media/3004303336_5010483712_56.mp4
火烧岛,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5102/744/295/5102744295/media/5102744295_5010118194_56.mp4
尖峰时刻[1764720],http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5100/137/361/5100137361/media/5100137361_5010131688_56.mp4
尖峰时刻2,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5100/137/274/5100137274/media/5100137274_5010142292_56.mp4
尖峰时刻3,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5100/137/908/5100137908/media/5100137908_5010138808_56.mp4
奇迹,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5101/006/862/5101006862/media/5101006862_5006152065_56.mp4
快餐车,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5100/162/985/5100162985/media/5100162985_5008068617_56.mp4
奇谋妙计五福星,http://hlsmgspdl.miguvideo.com:8080/depository_wx/asset/zhengshi/5100/162/298/5100162298/media/5100162298_5008436328_56.mp4
一招半式闯江湖,http://hlsmgspdl.miguvideo.com:8080/depository_wx/asset/zhengshi/5100/158/041/5100158041/media/5100158041_5008429840_56.mp4
蛇鹤八步,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5100/162/701/5100162701/media/5100162701_5010731179_56.mp4
剑花烟雨江南[1570720],http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5100/126/128/5100126128/media/5100126128_5010011570_56.mp4
少林门,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5100/162/688/5100162688/media/5100162688_5006371790_56.mp4
风雨双流星[720300],http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5100/100/958/5100100958/media/5100100958_5009411659_455.mp4
刁手怪招[1718720],http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3012/039/608/3012039608/media/3012039608_5009715880_56.mp4
少林木人巷,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5100/162/693/5100162693/media/5100162693_5009033515_56.mp4
飞渡卷云山,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5100/162/078/5100162078/media/5100162078_5006914097_56.mp4
新冷血十三鹰,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3012/045/599/3012045599/media/3012045599_5007931742_56.mp4
神威宝刀[1578720],http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5103/006/129/5103006129/media/5103006129_5010999140_56.mp4
花木兰,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5103/261/380/5103261380/media/5103261380_5009642551_56.mp4
龙门飞甲,http://hlsmgspdl.miguvideo.com:8080/depository_sp/asset/zhengshi/5100/035/480/5100035480/media/5100035480_5003348161_56.mp4
敢死队3,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3001/014/382/3001014382/media/3001014382_5007171996_56.mp4
敢死队2,http://hlsmgspdl.miguvideo.com:8080/depository_wx/asset/zhengshi/3000/264/900/3000264900/media/3000264900_5008233425_56.mp4
木乃伊3,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5103/312/978/5103312978/media/5103312978_5009492642_56.mp4
霍元甲[1838720],http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5102/635/094/5102635094/media/5102635094_5010527799_56.mp4
宇宙追缉令,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5102/223/025/5102223025/media/5102223025_5009772120_56.mp4
杀手之王,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5100/162/624/5100162624/media/5100162624_5010779010_56.mp4
黄飞鸿之西域雄狮,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3007/972/115/3007972115/media/3007972115_5010281199_56.mp4
冒险王,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3007/972/027/3007972027/media/3007972027_5008079071_56.mp4
给爸爸的信,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5100/162/083/5100162083/media/5100162083_5008853515_56.mp4
鼠胆龙威,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5102/595/246/5102595246/media/5102595246_5010268899_56.mp4
倚天屠龙记之魔教教主,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5103/142/842/5103142842/media/5103142842_5010205635_56.mp4
黄飞鸿铁鸡斗蜈蚣[1290720],http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5102/987/752/5102987752/media/5102987752_5007884361_56.mp4
黄飞鸿92之龙行天下,http://hlsmgspdl.miguvideo.com:8080/depository_wx/asset/zhengshi/3007/972/144/3007972144/media/3007972144_5008180820_56.mp4
精武小英雄,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5102/744/129/5102744129/media/5102744129_5007324287_56.mp4
金三角群英会,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5102/072/720/5102072720/media/5102072720_5009412197_56.mp4
超级女警[1298720],http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5101/006/718/5101006718/media/5101006718_5009895426_56.mp4
伦文叙老点柳先开,http://hlsmgspdl.miguvideo.com:8080/depository_wx/asset/zhengshi/5102/744/848/5102744848/media/5102744848_5008303659_56.mp4
黑道少林[956482],http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5102/744/363/5102744363/media/5102744363_5008129127_56.mp4
最佳拍档之大显神通[1510720],http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5100/166/530/5100166530/media/5100166530_5010511972_56.mp4
铁掌旋风腿[1428720],http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5101/005/046/5101005046/media/5101005046_5010724010_56.mp4
新碧血剑,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5102/957/392/5102957392/media/5102957392_5007387992_56.mp4
新天龙八部之天山童姥,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3007/140/997/3007140997/media/3007140997_5008082739_56.mp4
笑傲江湖[1320721],http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5100/165/939/5100165939/media/5100165939_5010058557_56.mp4
真三国无双[1662720],http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5102/035/291/5102035291/media/5102035291_5009924720_56.mp4
神迹之上古传奇[1646720],http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5101/067/074/5101067074/media/5101067074_5009905253_56.mp4
杨门女将之军令如山,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5101/033/353/5101033353/media/5101033353_5007556779_56.mp4
神奇侠侣,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3009/324/151/3009324151/media/3009324151_5008070419_56.mp4
武林怪兽,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5101/066/428/5101066428/media/5101066428_5010425415_56.mp4
金刚川,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5103/216/139/5103216139/media/5103216139_5009073231_56.mp4
神谕通天[1361720],http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5101/025/438/5101025438/media/5101025438_5008088709_56.mp4
降龙传说,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5100/075/015/5100075015/media/5100075015_5008154709_56.mp4
唐山大地震[1702720],http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3009/885/275/3009885275/media/3009885275_5007884869_56.mp4
西游记之女儿国[1702720],http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5100/082/946/5100082946/media/5100082946_5008155337_56.mp4
新英雄本色,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3007/141/088/3007141088/media/3007141088_5008458065_56.mp4
破戒[1624720],http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5101/059/109/5101059109/media/5101059109_5004391252_56.mp4
咸鱼翻生,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5101/058/327/5101058327/media/5101058327_5008290828_56.mp4
人蛇欲血战之与蛇共舞,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5101/058/465/5101058465/media/5101058465_5008692300_56.mp4
白蛇：缘起[1736720],http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5102/110/357/5102110357/media/5102110357_5007857852_56.mp4
忠烈杨家将,http://hlsmgspdl.miguvideo.com:8080/depository_wx/asset/zhengshi/3010/940/314/3010940314/media/3010940314_5008237105_56.mp4
黑豹天下,http://hlsmgspdl.miguvideo.com:8080/depository_wx/asset/zhengshi/5102/744/287/5102744287/media/5102744287_5008443663_56.mp4
长城[1920720],http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5100/058/172/5100058172/media/5100058172_5007954328_56.mp4
白发魔女传,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3006/200/760/3006200760/media/3006200760_5008202052_56.mp4
白发魔女2,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3002/179/846/3002179846/media/3002179846_5002662006_56.mp4
悟空传[1723720],http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5100/069/457/5100069457/media/5100069457_5005265459_56.mp4
现代豪侠传,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5102/744/470/5102744470/media/5102744470_5006371688_56.mp4
风云雄霸天下,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3007/135/724/3007135724/media/3007135724_5005522575_56.mp4
叶问3,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3013/597/653/3013597653/media/3013597653_5010159744_56.mp4
叶问4[1282720],http://hlsmgspdl.miguvideo.com:8080/depository_wx/asset/zhengshi/5102/238/742/5102238742/media/5102238742_5008552845_56.mp4
Office有鬼,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5100/072/716/5100072716/media/5100072716_5007219857_56.mp4
灵幻天师,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5102/310/502/5102310502/media/5102310502_5006349093_56.mp4
灵幻至尊,http://hlsmgspdl.miguvideo.com:8080/depository_wx/asset/zhengshi/5102/310/340/5102310340/media/5102310340_5008517065_56.mp4
新僵尸先生[720426],http://hlsmgspdl.miguvideo.com:8080/depository_wx/asset/zhengshi/5102/310/337/5102310337/media/5102310337_5008501286_455.mp4
妖魔道,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5102/744/146/5102744146/media/5102744146_5009500402_56.mp4
倩女幽魂2011版,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3009/323/802/3009323802/media/3009323802_5010199118_56.mp4
倩女幽魂2：人间道,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3002/056/981/3002056981/media/3002056981_5008078692_56.mp4
倩女幽魂3：道道道,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5100/162/306/5100162306/media/5100162306_5007835917_56.mp4
恐怖游泳馆,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3009/124/506/3009124506/media/3009124506_5009447936_56.mp4
五福星撞鬼,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5103/094/417/5103094417/media/5103094417_5008118085_56.mp4
反贪风暴,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3000/916/429/3000916429/media/3000916429_5010453538_56.mp4
反贪风暴2,http://hlsmgspdl.miguvideo.com:8080/depository/asset/zhengshi/5100/065/108/5100065108/media/5100065108_5001178481_56.mp4
反贪风暴3,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5102/000/965/5102000965/media/5102000965_5010067044_56.mp4
反贪风暴4,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5102/219/103/5102219103/media/5102219103_5009593491_56.mp4
廉政风云[1702720],http://hlsmgspdl.miguvideo.com:8080/depository_wx/asset/zhengshi/5102/163/260/5102163260/media/5102163260_5008144274_56.mp4
雷洛传2,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3005/665/114/3005665114/media/3005665114_5006010229_56.mp4
李洛夫奇案,http://hlsmgspdl.miguvideo.com:8080/depository_wx/asset/zhengshi/5102/073/752/5102073752/media/5102073752_5008201035_56.mp4
追龙赴会,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5103/429/489/5103429489/media/5103429489_5010155842_56.mp4
侠路相逢,http://hlsmgspdl.miguvideo.com:8080/depository_wx/asset/zhengshi/5102/175/658/5102175658/media/5102175658_5008197776_56.mp4
小时代4：灵魂尽头,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3008/244/031/3008244031/media/3008244031_5010057905_56.mp4
我是证人[1702720],http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3010/290/686/3010290686/media/3010290686_5008123948_56.mp4
攀登者[1736720],http://hlsmgspdl.miguvideo.com:8080/depository_wx/asset/zhengshi/5102/223/478/5102223478/media/5102223478_5008138032_56.mp4
最爱[1340720],http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5100/038/454/5100038454/media/5100038454_5009498516_56.mp4
青春奇侠[1482720],http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5102/743/965/5102743965/media/5102743965_5010947424_56.mp4
画中仙,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5100/162/690/5100162690/media/5100162690_5008959309_56.mp4
追日,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5102/744/015/5102744015/media/5102744015_5007221471_56.mp4
灵狐,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5102/744/116/5102744116/media/5102744116_5006383628_56.mp4
铁血娇娃,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3001/011/605/3001011605/media/3001011605_5009926886_56.mp4
恋爱中的城市[1754720],http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5101/020/713/5101020713/media/5101020713_5007766121_56.mp4
无限复活,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5100/165/880/5100165880/media/5100165880_5010059031_56.mp4
危险关系[1678720],http://hlsmgspdl.miguvideo.com:8080/depository_wx/asset/zhengshi/3011/052/517/3011052517/media/3011052517_5008240910_56.mp4
极速天使,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5101/023/313/5101023313/media/5101023313_5008123150_56.mp4
非诚勿扰,http://hlsmgspdl.miguvideo.com:8080/depository_wx/asset/zhengshi/3009/885/389/3009885389/media/3009885389_5008226280_56.mp4
奇门遁甲,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5100/174/892/5100174892/media/5100174892_5008087095_56.mp4
替身杀手,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5100/172/059/5100172059/media/5100172059_5010392091_56.mp4
义盖云天[1024576],http://hlsmgspdl.miguvideo.com:8080/depository_wx/asset/zhengshi/5100/098/717/5100098717/media/5100098717_5008306119_56.mp4
前任3,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5100/179/817/5100179817/media/5100179817_5008841674_56.mp4
火舞风云,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3005/729/617/3005729617/media/3005729617_5009741050_56.mp4
冰封：重生之门,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3000/264/444/3000264444/media/3000264444_5005361206_56.mp4
特殊身份,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3004/175/202/3004175202/media/3004175202_5007217152_56.mp4
苏乞儿,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5102/751/127/5102751127/media/5102751127_5008113344_56.mp4
铁马骝11,http://hlsmgspdl.miguvideo.com:8080/depository_wx/asset/zhengshi/5102/744/199/5102744199/media/5102744199_5008457698_56.mp4
赌圣11,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3007/418/867/3007418867/media/3007418867_5008002030_56.mp4
马戏小子,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5102/744/674/5102744674/media/5102744674_5007596740_56.mp4
如火威龙,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5102/744/678/5102744678/media/5102744678_5006991485_56.mp4
高压线,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5102/744/475/5102744475/media/5102744475_5007216659_56.mp4
刀火线,http://hlsmgspdl.miguvideo.com:8080/depository_sp/asset/zhengshi/3004/054/231/3004054231/media/3004054231_5003561180_56.mp4
八佰,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5102/203/087/5102203087/media/5102203087_5008816302_56.mp4
新花木兰,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5103/261/913/5103261913/media/5103261913_5008919556_56.mp4
钟馗伏魔：雪妖魔灵,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/3006/465/247/3006465247/media/3006465247_5008377218_56.mp4
小白龙情海翻,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5100/100/022/5100100022/media/5100100022_5007756373_56.mp4
杜十娘,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5101/028/058/5101028058/media/5101028058_5004406333_56.mp4
荞麦疯长全网[1707*720],http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5102/258/995/5102258995/media/5102258995_5008562543_56.mp4
烈火男儿之金斧头,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5102/757/807/5102757807/media/5102757807_5006400373_56.mp4
烈火男儿之隐患,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5102/757/716/5102757716/media/5102757716_5008056279_56.mp4
烈火男儿之荣誉,http://hlsmgspdl.miguvideo.com:8080/depository_yqv/asset/zhengshi/5102/755/893/5102755893/media/5102755893_5007887143_56.mp4

💘慢摇,#genre#
今日热歌DJ《如果爱还在》,https://vd2.bdstatic.com/mda-mhhf5mr00yyhpfjs/1080p/cae_h264/1629284581057661229/mda-mhhf5mr00yyhpfjs.mp4
推荐9首DJ舞曲,https://vd2.bdstatic.com/mda-mhig1c3sw223mx8p/1080p/cae_h264/1629380139191731149/mda-mhig1c3sw223mx8p.mp4
动感DJ《苦了累了听听歌》,https://vd4.bdstatic.com/mda-mhqekuf2r91v08dt/1080p/cae_h264/1629888246186602728/mda-mhqekuf2r91v08dt.mp4
车载必备DJ《殇雪》,https://vd3.bdstatic.com/mda-mhve4gb9hi8cstzk/1080p/cae_h264/1630319514896018158/mda-mhve4gb9hi8cstzk.mp4
DJ《心在跳情在烧》,https://vd4.bdstatic.com/mda-mhwf07t27w3gi1y7/1080p/cae_h264/1630406994590156367/mda-mhwf07t27w3gi1y7.mp4
郭镐鸣《野摩托》,https://vd3.bdstatic.com/mda-mekfm7wu6f4rtt99/1080p/cae_h264/1621595318412084671/mda-mekfm7wu6f4rtt99.mp4
DJ版《真的为你哭了》,https://vd2.bdstatic.com/mda-me5chwexudvzcayg/fhd/cae_h264_nowatermark/1620297137821103617/mda-me5chwexudvzcayg.mp4
海来阿木《浪子心》DJ沈念版,https://vd3.bdstatic.com/mda-mgr9s5pv0jeqbcm8/1080p/cae_h264/1627298307874491239/mda-mgr9s5pv0jeqbcm8.mp4
DJ版《三月里的小雨》,https://vd2.bdstatic.com/mda-mgwegh0bzv4cy6cb/1080p/cae_h264/1627727251470197083/mda-mgwegh0bzv4cy6cb.mp4
DJ版《望爱却步》,https://vd4.bdstatic.com/mda-mh3ei4sg2jypty79/1080p/cae_h264/1628072927342489970/mda-mh3ei4sg2jypty79.mp4
《唱着情歌流着泪》,https://vd3.bdstatic.com/mda-mhwaejanf0ie6b8j/1080p/cae_h264/1630409563129833732/mda-mhwaejanf0ie6b8j.mp4
《爱你到最后一刻》,https://vd3.bdstatic.com/mda-mhr9c7q9xzgy1812/1080p/cae_h264/1630062648077583523/mda-mhr9c7q9xzgy1812.mp4
伤感DJ《等》,https://vd2.bdstatic.com/mda-mhq92a7nafrh8dma/1080p/cae_h264/1629977686796490849/mda-mhq92a7nafrh8dma.mp4
DJ《我们不再是从前》,https://vd2.bdstatic.com/mda-mhne550wq5m66zvj/1080p/cae_h264/1629803514331462220/mda-mhne550wq5m66zvj.mp4
DJ舞曲《让我做你的眼睛》,https://vd2.bdstatic.com/mda-mhaargrart2qrkdz/1080p/cae_h264/1629630942996744682/mda-mhaargrart2qrkdz.mp4
DJ版《时间会知道你好不好》,https://vd3.bdstatic.com/mda-mhairve7gvye1192/1080p/cae_h264/1629457148988604256/mda-mhairve7gvye1192.mp4
DJ版《爱不得忘不舍》,https://vd3.bdstatic.com/mda-mh8j8egnj8idbvd8/1080p/cae_h264/1629367979662473678/mda-mh8j8egnj8idbvd8.mp4
DJ版《蜜雪冰城》,https://vd3.bdstatic.com/mda-mhbae2pwwxhyxjcz/1080p/cae_h264/1628767594518574030/mda-mhbae2pwwxhyxjcz.mp4
DJ版《夜难眠》,https://vd3.bdstatic.com/mda-mh5hwg99vtp777bj/1080p/cae_h264/1628420576290088489/mda-mh5hwg99vtp777bj.mp4
《无味》 DJ版,https://vd3.bdstatic.com/mda-mgqiagirsmmpuarm/1080p/cae_h264/1627218846577884242/mda-mgqiagirsmmpuarm.mp4
DJ版《原谅你的谎》,https://vd4.bdstatic.com/mda-mhacxx5vhr2we882/1080p/cae_h264/1628673933350116053/mda-mhacxx5vhr2we882.mp4
DJ《等爱》,https://vd2.bdstatic.com/mda-mfhh1e0hwq212rrt/sc/h264/1623988905898256147/mda-mfhh1e0hwq212rrt.mp4
DJ《醉过多少回》,https://vd4.bdstatic.com/mda-megp46e98a4f2b9g/sc/h264/1621239560364992817/mda-megp46e98a4f2b9g.mp4
DJ小鱼儿 - 如果你真的要离开 (DJ加快版),https://vd4.bdstatic.com/mda-mfh4rq9drsza8gf9/1080p/cae_h264/1623987066817324460/mda-mfh4rq9drsza8gf9.mp4
DJ情歌《爱情迷了路》,https://vd4.bdstatic.com/mda-mdbrb7fns70avrmt/1080p/cae_h264/1618222287/mda-mdbrb7fns70avrmt.mp4
《忘川彼岸DJ》,https://vd2.bdstatic.com/mda-md2eyfntemujuft5/1080p/cae_h264/1617446472/mda-md2eyfntemujuft5.mp4
DJ音乐舞曲《一千个轮回》,https://vd4.bdstatic.com/mda-mdu1939m1muvhme3/1080p/cae_h264/1619662287022848524/mda-mdu1939m1muvhme3.mp4
DJ 最美不过你的微笑,https://vd4.bdstatic.com/mda-mhs2qjdmkjz2rb7g/sc/cae_h264/1630029534870787600/mda-mhs2qjdmkjz2rb7g.mp4
DJ 流浪兄弟,https://vd2.bdstatic.com/mda-mhrdtax1km0idkc5/1080p/cae_h264/1629972852606533219/mda-mhrdtax1km0idkc5.mp4
车载DJ《多年以后》,https://vd3.bdstatic.com/mda-mhqekuegbh6112js/1080p/cae_h264/1629891559415737083/mda-mhqekuegbh6112js.mp4
红尘只是个过客,https://vd2.bdstatic.com/mda-mhq68s6g444n437t/hd/cae_h264/1629865742325435508/mda-mhq68s6g444n437t.mp4
百花香(抖音DJ版),https://vd4.bdstatic.com/mda-mdsd1z3wbqeeyumq/fhd/cae_h264_nowatermark/1620021906658368673/mda-mdsd1z3wbqeeyumq.mp4
经典老歌DJ舞曲七首,https://vd2.bdstatic.com/mda-mhwbtsnrmm6v6x5r/sc/cae_h264/1630403250895754314/mda-mhwbtsnrmm6v6x5r.mp4
韩可可《错位时空》DJ版,https://vd3.bdstatic.com/mda-mgciytzb45z6z8yj/1080p/cae_h264/1626183756603775947/mda-mgciytzb45z6z8yj.mp4
忘记你需要多久(DJ小鱼儿版),https://vd2.bdstatic.com/mda-mc1sm1r5s9azchjv/v1-cae/1080p/mda-mc1sm1r5s9azchjv.mp4
抖音热歌《大风吹+夜夜夜漫长》,https://vdse.bdstatic.com//13da18e12728e9d7849f6589a3070b4c.mp4
2021年最火伤感音乐,https://vdse.bdstatic.com//6d39df48360bdb12f73800397c4a6c02.mp4
2021热门伤感DJ,https://vdse.bdstatic.com//06b4e9b185b843e694e4d20e9b0a0aac.mp4
6首DJ情歌,https://vdse.bdstatic.com//e0ad4d203cd7d7ffa943544c8d2ddbd3.mp4
几首比较火的DJ情歌,https://vdse.bdstatic.com//4d7e8fe409b2ba9e08b179de8e146fa3.mp4
精选6首DJ情歌,https://vdse.bdstatic.com//2ead9cf04f5e9e3a99eea79534c3c104.mp4
酒吧DJ舞曲,https://vdse.bdstatic.com//5208fb24e1d76b0e81f992e91537f086.mp4
花都开了你来不来DJ,https://vd3.bdstatic.com/mda-mdee523swbezmsin/480p/h264/1618480997/mda-mdee523swbezmsin.mp4

🎤唱歌,#genre#
烟雨人间,http://mobi.kuwo.cn/tmevideo/tme1257648.mp4
阿果吉曲,http://mobi.kuwo.cn/tmevideo/tme1257695.mp4
阿果吉曲,http://mobi.kuwo.cn/tmevideo/tme1257647.mp4
你的万水千山,http://mobi.kuwo.cn/tmevideo/tme1257697.mp4
人生如歌,http://mobi.kuwo.cn/tmevideo/tme1257678.mp4
孤独的王,http://mobi.kuwo.cn/tmevideo/tme1257703.mp4
作酒,http://mobi.kuwo.cn/tmevideo/tme16186338.mp4
逃之夭夭,http://mobi.kuwo.cn/tmevideo/tme12155598.mp4
两个世界,http://mobi.kuwo.cn/tmevideo/tme1932603.mp4
闽南语歌曲联播,http://mobi.kuwo.cn/tmevideo/tme12155588.mp4
阿衣莫,http://mobi.kuwo.cn/tmevideo/tme7020227.mp4
归来是故乡,http://mobi.kuwo.cn/tmevideo/tme1700466.mp4
叹这一生,http://mobi.kuwo.cn/tmevideo/tme1662018.mp4
叹这一生,http://mobi.kuwo.cn/tmevideo/tme2033087.mp4
最亲的人,http://mobi.kuwo.cn/tmevideo/tme2152057.mp4
最亲的人,http://mobi.kuwo.cn/tmevideo/tme1658520.mp4
大风吹,http://vdown2.kuwo.cn/resource//t5/0/eTNBMFltlx07LI3bUVOg01041201VIsY0E010.mp4
醉倾城,http://videosc.kuwo.cn/UAA-4hndfVc5V6DJX0EvslAUBBI=/lhXcbl-l_ujsig79B4Ez5jT7tBNB
西海情歌,http://vdown.kuwo.cn/resource//t4/6/86/TbCpJTdV4o0.mp4
得意的笑,http://vdown.kuwo.cn/resource//t4/22/49/ZAlSw_dVq1Q.mp4
你不来我不老,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgnLzE4gUoxaHkBg.mp4
远走高飞,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgn-zL9QUo4L7HJQ.mp4
酒醉的蝴蝶,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgjvvL9QUo3cjNuQY.mp4
情火,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgwfvL9QUoyKDRhQI.mp4
别知己,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAg9sG2-AUo4MTLmAQ.mp4
缘分一道桥,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgw4vG4gUozNe3-QM.mp4
不一样的美,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgmfvL9QUolKvHtQE.mp4
成都,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgx5ei5wUoqOfenwE.mp4
狂狼,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgsK2M5gUosN7C7QQ.mp4
野花香,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAg3oaO9wUo4J6WwQU.mp4
老猫-都说,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAghPbQ7AUohPLwrAM.mp4
拥抱着你离去,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAg2bGM5gUo_NXfoAI.mp4
沙漠骆驼,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgjbGM5gUon8K7eQ.mp4
在唱等你那么久,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAg68u04wUoqKv6igY.mp4
藕断丝连,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAg2-PE4gUogNfRyAM.mp4
歌在飞,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgl4XG4gUo2IDXsAM.mp4
火火的爱,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgzsXE4gUorZf38wc.mp4
爱火,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAg_8PE4gUo5KSp4gU.mp4
闯天涯,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgsZ-V4gUo8dCz8wE.mp4
火红的萨日朗,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgnaLV4gUop5aBpQY.mp4
你牛什么牛,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAg3drE4gUo05Sr5AI.mp4
云朵-我的楼兰,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAg88K74gUohZWCnwQ.mp4
后来,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAg9_qv4gUo4vCgPQ.mp4
兄弟难当,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAg97nE4gUooPX7tQU.mp4
水云涧,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgvLrE4gUon5qCgAU.mp4
套马杆,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgnLvE4gUo8NTRJA.mp4
草原情哥哥,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAg26rA4gUou4uf7AU.mp4
没有你陪伴我真的好孤单,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgpPqtggYozbG1SQ.mp4
火辣辣的情歌,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgsaTA4gUohOr5ngc.mp4
柔柔的眼波柔柔的你,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAg9dvx9wUowK2B3AY.mp4
一曲相思,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAg4oDG4gUo69_8zAQ.mp4
死心塌地去爱你,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgwtjx9wUonPWg5QU.mp4
我们不一样,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAg4Nfx9wUojcTB7Qc.mp4
小苹果,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgy6fE4gUoksb_nwQ.mp4
公虾米,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgnMOv5wUouMCstQQ.mp4
等到山花开,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAggcOv5wUo4pShggc.mp4
美美哒,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAg4cm74gUo4OSj9gU.mp4
十八姑娘一朵花,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgzL_v5wUowL3FvAM.mp4
一生所爱,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgk9aq4gUogIDbxwQ.mp4
半阳一曲相思,https://vdse.bdstatic.com//e547b08ce3afad200eec374f3c4ee450.mp4?authorization=bce-auth-v1%2F40f207e648424f47b2e3dfbb1014b1a5%2F2020-01-31T13%3A00%3A56Z%2F-1%2Fhost
站着等你三千年,https://vdse.bdstatic.com//967f216dea39a6f3ccb44884a219f8ff.mp4?authorization=bce-auth-v1%2F40f207e648424f47b2e3dfbb1014b1a5%2F2019-12-14T02%3A12%3A33Z%2F
贴身侍卫,http://em.21dtv.com/songs/60110002.mkv
红尘里的花,http://em.21dtv.com/songs/60110001.mkv
家乡,http://em.21dtv.com/songs/60110000.mkv
化蝶随你飞,http://em.21dtv.com/songs/60110003.mkv
为爱停留,http://em.21dtv.com/songs/60110006.mkv
寂寞的夜里想起你,http://em.21dtv.com/songs/60110004.mkv
别说谁离不开谁,http://em.21dtv.com/songs/60110007.mkv
微世界,http://em.21dtv.com/songs/60110005.mkv
忘掉你的美,http://em.21dtv.com/songs/60110008.mkv
摆古,http://em.21dtv.com/songs/60110009.mkv
舞动快乐,http://em.21dtv.com/songs/60110011.mkv
租爱,http://em.21dtv.com/songs/60110010.mkv
策马扬鞭,http://em.21dtv.com/songs/60110013.mkv
我们都没错,http://em.21dtv.com/songs/60110015.mkv
谢谢我的我,http://em.21dtv.com/songs/60110016.mkv
国家,http://em.21dtv.com/songs/60110020.mkv
尘缘情歌,http://em.21dtv.com/songs/60110018.mkv
我的爱你并不在乎,http://em.21dtv.com/songs/60110019.mkv
小小,http://em.21dtv.com/songs/60110021.mkv
恋爱转机,http://em.21dtv.com/songs/60110022.mkv
我的自卑感,http://em.21dtv.com/songs/60110023.mkv
平凡的梦,http://em.21dtv.com/songs/60110024.mkv
解开,http://em.21dtv.com/songs/60110025.mkv
爱在心里,http://em.21dtv.com/songs/60110026.mkv
新年,http://em.21dtv.com/songs/60110027.mkv
飞天神韵,http://em.21dtv.com/songs/60110028.mkv
分手的那一夜,http://em.21dtv.com/songs/60110030.mkv
等你回来,http://em.21dtv.com/songs/60110031.mkv
酥手愿,http://em.21dtv.com/songs/60110033.mkv
八戒八戒我的郎,http://em.21dtv.com/songs/60110032.mkv
错爱,http://em.21dtv.com/songs/60110035.mkv
牵过的手,http://em.21dtv.com/songs/60110029.mkv
曾经拥有的那些年,http://em.21dtv.com/songs/60110036.mkv
迪迪娜,http://em.21dtv.com/songs/60110037.mkv
绽放的玫瑰,http://em.21dtv.com/songs/60110038.mkv
念念,http://em.21dtv.com/songs/60110040.mkv
傍晚,http://em.21dtv.com/songs/60110039.mkv
思念她,http://em.21dtv.com/songs/60110041.mkv
寂寞钢琴手,http://em.21dtv.com/songs/60110042.mkv
不爱就滚开,http://em.21dtv.com/songs/60110043.mkv
寂寞空虚冷,http://em.21dtv.com/songs/60110045.mkv
中国山水画,http://em.21dtv.com/songs/60110044.mkv
旗袍的诱惑,http://em.21dtv.com/songs/60110046.mkv
草原汉子,http://em.21dtv.com/songs/60110047.mkv
草蜢-失恋阵线联盟,http://vodcdn.video.taobao.com/oss/ali-video/bbae2fc164d9517913ed5a9117f8455b/video.m3u8
草蜢-忘情森巴舞,http://vodcdn.video.taobao.com/oss/ali-video/a30020a6cd9ce2a8b387e029f9c5365c/video.m3u8
草蜢-半点心,http://vodcdn.video.taobao.com/oss/ali-video/68fc953ff930412784dada5eb79d0821/1461058499/video.m3u8.m3u8
草蜢-宝贝对不起,http://bizcommon.alicdn.com/l2nDqpMmn6DGHnWzZQA/RQdMfitGKCINh4BPzc9%40%40sd.m3u8
陈倩倩-婴儿,http://vodcdn.video.taobao.com/oss/ali-video/4fc8d043456c092c392483bd293d0ee3/video.m3u8
王菲-爱与痛的边缘,http://vodcdn.video.taobao.com/oss/ali-video/f5e79c70df75bdccf2714ed788764f58/video.m3u8
王菲-如风,http://vodcdn.video.taobao.com/oss/ali-video/f176658a3f974aecd5ce3df456092835/video.m3u8
王菲-执迷不悔,http://vodcdn.video.taobao.com/oss/ali-video/15bf7da88b44048edaabe73d6b17c00b/video.m3u8
陈慧娴-千千阙歌,http://vodcdn.video.taobao.com/oss/ali-video/8f45a35108ebe1b1951d2936007e3cd0/video.m3u8
陈慧娴-归来吧,http://vodcdn.video.taobao.com/oss/ali-video/c89589fd5809cf6e2f1a4d7a52023733/video.m3u8
陈慧娴-孤单背影,http://vodcdn.video.taobao.com/oss/ali-video/092bc3fac8ea013544a1dda61de41e58/video.m3u8
陈慧娴-红茶馆,http://vodcdn.video.taobao.com/oss/ali-video/22ecb463b2e44875b1fa78090d0ffd4e/1460015776/video.m3u8.m3u8
陈慧娴-跳舞街,http://vodcdn.video.taobao.com/oss/ali-video/5e463c16339f3dd6839e6a7d2074915c/video.m3u8
黄凯芹-相爱很难,http://vodcdn.video.taobao.com/oss/ali-video/11b6273898b6a1b1da34e646264cd036/video.m3u8
梁朝伟-一天一天爱恋,http://vodcdn.video.taobao.com/oss/ali-video/d8c74bd184d05f8cf1cbd4bbd7307f79/video.m3u8
巫启贤-只因你伤心,http://vodcdn.video.taobao.com/oss/ali-video/c28acbe36530da595b04161855bba004/video.m3u8
巫启贤-太傻,http://vodcdn.video.taobao.com/oss/ali-video/e6f2953419f904065dc2ce38efc85515/video.m3u8
彭佳慧-无法割舍,http://vodcdn.video.taobao.com/oss/ali-video/8be8f7d28d4f2c7ce759d431f0d3181b/video.m3u8
彭佳慧-回味,http://vodcdn.video.taobao.com/oss/ali-video/6801f707771eacdb5264f8bb20e4d599/video.m3u8
叶倩文-潇洒走一回,http://vodcdn.video.taobao.com/oss/ali-video/371d75312720e701b5f3988d46cdf4ef/video.m3u8
叶倩文-伤逝,http://vodcdn.video.taobao.com/oss/ali-video/9f6ad7cd057bc2cf21d1c5a6cc57eed7/video.m3u8
叶倩文-曾经心痛,http://vodcdn.video.taobao.com/oss/ali-video/0ea34400f2502a94ee14aea506e0042b/video.m3u8
叶倩文-我的爱对你说,http://bizcommon.alicdn.com/l2nDqpMmn6DGHnWzZQA/7xXG24i7EbZtCTOtSnh%40%40sd.m3u8
张智霖-片片枫叶情,http://vodcdn.video.taobao.com/oss/ali-video/1d02cf8794a542c930fbf210c0a4e3e7/video.m3u8
张智霖-现代爱情故事,http://vodcdn.video.taobao.com/oss/ali-video/864b1ca28cb8b566e2989775ae737de7/video.m3u8
毛宁-晚秋,http://vodcdn.video.taobao.com/oss/ali-video/95751adaad64e6ca860b18f4855cd94d/video.m3u8
毛宁-蓝蓝的夜蓝蓝的梦,http://vodcdn.video.taobao.com/oss/ali-video/6d5a8c2e7667e3d6138246a45571d1f7/video.m3u8
毛宁/杨钰莹-心雨,http://vodcdn.video.taobao.com/oss/ali-video/0191a1eb6017684a3641a51d32c9633a/video.m3u8
杨钰莹-轻轻告诉你,http://vodcdn.video.taobao.com/oss/ali-video/1905c60363f40cea52f342ec59132da0/video.m3u8
杨钰莹-我不想说,http://vodcdn.video.taobao.com/oss/ali-video/cc97a07de2cac88c025590ef874253fc/video.m3u8
杨钰莹-等你一万年,http://vodcdn.video.taobao.com/oss/ali-video/e1e0b88e5c6d40d7176f353d41aac985/video.m3u8
杨钰莹-红彤彤的春天,http://vodcdn.video.taobao.com/oss/ali-video/31fcc5242ffc9a00a5a62d89b21c0bea/video.m3u8
吕方-朋友别哭,http://bizcommon.alicdn.com/l2nDqpMmn6DGHnWzZQA/qgljCDKewD8vEgOMrrt%40%40sd.m3u8
吕方-多爱你一天,http://vodcdn.video.taobao.com/oss/ali-video/dcd97358c3e72377932aa883727320f9/video.m3u8
范玮琪-到不了,http://vodcdn.video.taobao.com/oss/taobao-ugc/fa0717711bea440094da793d11790f26/1492758270/video.m3u8.m3u8
范玮琪-可不可以不勇敢,http://vodcdn.video.taobao.com/oss/taobao-ugc/281fad47bf534456b587495a8edf0d7a/1530774215/video.m3u8.m3u8
孟庭苇-冬季到台北来看雨,http://bizcommon.alicdn.com/l2nDqpMmn6DGHnWzZQA/Pd8qTC385qKJVXaXcKj%40%40hd.m3u8
孟庭苇-真的还是假的,http://bizcommon.alicdn.com/l2nDqpMmn6DGHnWzZQA/vhJvCIZiDOz7f6VTCON%40%40hd.m3u8
孟庭苇-风中有朵雨做的云,http://bizcommon.alicdn.com/l2nDqpMmn6DGHnWzZQA/Cg9qI5imMInpPvK5Mnm%40%40hd.m3u8
孟庭苇-你究竟有多少个好妹妹,http://vodcdn.video.taobao.com/oss/ali-video/dfb07cbdd8435d48cb1e6691122d8d85/video.m3u8
孟庭苇-你看你看月亮的脸,http://vodcdn.video.taobao.com/oss/ali-video/6e098f7b47614885845efb7a45998eb1/1465875165/video.m3u8.m3u8
孟庭苇-雾里看花,http://bizcommon.alicdn.com/l2nDqpMmn6DGHnWzZQA/fi3PjAgsnTjwzAvSboT%40%40hd.m3u8
孟庭苇-红雨,http://vodcdn.video.taobao.com/oss/ali-video/a816f01838e07c4dac5f8612331bca63/video.m3u8
孟庭苇-无声的雨,http://vodcdn.video.taobao.com/oss/ali-video/d404a897abb4526c94bb5f72dc566952/video.m3u8
孟庭苇-谁的眼泪在飞,http://vodcdn.video.taobao.com/oss/ali-video/bfcfddb1694a43957962294c2f75bdfb/video.m3u8
孟庭苇-把思念寄托远方,http://bizcommon.alicdn.com/l2nDqpMmn6DGHnWzZQA/Y0iKpwmE2YZona6PY7A%40%40hd.m3u8
孟庭苇-风里的梦,http://vodcdn.video.taobao.com/oss/ali-video/626e2336b5e9765e14ba22a617fd6223/video.m3u8
孟庭苇-过冬,http://bizcommon.alicdn.com/l2nDqpMmn6DGHnWzZQA/U9QKnKK2RpKMElnSS07%40%40hd.m3u8
孟庭苇-爱你太深,http://bizcommon.alicdn.com/l2nDqpMmn6DGHnWzZQA/KbJb4OVT1yH1ZDvri5p%40%40hd.m3u8
孟庭苇-不下雨就出太阳吧,http://bizcommon.alicdn.com/l2nDqpMmn6DGHnWzZQA/lhaW77A2RRwiJrh0CiJ%40%40hd.m3u8
孟庭苇-我说的谎都是真的,http://bizcommon.alicdn.com/l2nDqpMmn6DGHnWzZQA/9aqTcUjlJ7KZkA37W1E%40%40hd.m3u8
孟庭苇-春雪,http://bizcommon.alicdn.com/l2nDqpMmn6DGHnWzZQA/5ZFrpzPk37KvY7CaTUj%40%40hd.m3u8
裘正海-爱你十分泪七分,http://vodcdn.video.taobao.com/oss/ali-video/6ad63af2dc4b244d0dc773b2004374c3/video.m3u8
杨曼-9999滴眼泪,http://vodcdn.video.taobao.com/oss/ali-video/f6d027835c0e8f72d3c74379b86fb696/video.m3u8
誓言-求佛,http://vodcdn.video.taobao.com/oss/ali-video/f4f761d970399f186ce1f9ac6d009721/video.m3u8
许茹芸-独角戏,http://vodcdn.video.taobao.com/oss/ali-video/5333f389ce940d0a2c1dd6090927746c/video.m3u8
许茹芸-如果云知道,http://vodcdn.video.taobao.com/oss/ali-video/fd87aea7bc293a5930b8a64c752df476/video.m3u8
许茹芸-泪海,http://vodcdn.video.taobao.com/oss/ali-video/76fe6eb28aee716783f2a47ba8a15e5a/video.m3u8
许茹芸-不爱我放了我,http://vodcdn.video.taobao.com/oss/ali-video/b0f458650135c68f1b88ea7667eec629/video.m3u8
许茹芸-我依然爱你,http://vodcdn.video.taobao.com/oss/ali-video/4c4ec12e6efa0d76e5a269ac05ea394e/video.m3u8
陈明真-变心的翅膀,http://vodcdn.video.taobao.com/oss/ali-video/e18dd3abfada11fb6faf26a521084343/video.m3u8
陈明真-百万个吻,http://vodcdn.video.taobao.com/oss/ali-video/0c66aff1e198e944fb0460172d33d780/video.m3u8
陈明真-为爱笑着流泪,http://vodcdn.video.taobao.com/oss/ali-video/4f31a4692aae0974dbc82a95d23339f4/video.m3u8
陈明真-情债,http://vodcdn.video.taobao.com/oss/ali-video/99c8f1df6d5686d99e4adc1e6caed7b7/video.m3u8
任齐贤-心太软,http://vodcdn.video.taobao.com/oss/ali-video/1675208d8b5f0f0d8ce09236f4068dfe/video.m3u8
周华健-朋友,http://vodcdn.video.taobao.com/oss/ali-video/6079de4355c45a42073ead75954c1b2f/video.m3u8
周华健-风雨无阻,http://vodcdn.video.taobao.com/oss/ali-video/8d77795bdc63d87125ba47f993e0bfb4/video.m3u8
周慧敏-痴心换情深,http://vodcdn.video.taobao.com/oss/ali-video/aa07f0b5c8a36740b3bee03d69a4116c/video.m3u8
胡杨林-香水有毒,http://vodcdn.video.taobao.com/oss/ali-video/180f9fcdb9e2b24d3b13a526fb90003e/video.m3u8
梁静茹-勇气,http://vodcdn.video.taobao.com/oss/ali-video/f501ffc81da040099b17fb1db30b92fe/1462937648/video.m3u8.m3u8
光良-童话,http://vodcdn.video.taobao.com/oss/ali-video/e2c54a5b89aaa794cfc186c41d2ef348/video.m3u8
光良-第一次,http://vodcdn.video.taobao.com/oss/ali-video/fe68ff471420aaefcb3a7f4f413ad3f4/video.m3u8
张惠妹-听海,http://vodcdn.video.taobao.com/oss/ali-video/c105aa7685c54fbfa74b92e8cc88a3e3/1457681472/video.m3u8.m3u8
张惠妹-别在伤口撒盐,http://vodcdn.video.taobao.com/oss/ali-video/5997fdd5c8b241b7b2995ae6da3bc8f8/1458294379/video.m3u8.m3u8
李翊君-诺言,http://vodcdn.video.taobao.com/oss/ali-video/b8096cd4762369bbcb4ceb52cc25a938/video.m3u8
王麟-伤不起,http://vodcdn.video.taobao.com/oss/ali-video/1e3633ff1c3a525e148968b45c18f780/video.m3u8
龙梅子-泪满天,http://vodcdn.video.taobao.com/oss/ali-video/2ea2890443421f58665a7fdf0a297265/video.m3u8
李圣杰-痴心绝对,http://vodcdn.video.taobao.com/oss/ali-video/f2b27944f9960f3dbb2c6dd6c4679747/video.m3u8
谭咏麟/关淑怡-明天你是否依然爱我,http://vodcdn.video.taobao.com/oss/ali-video/0b56ad556e887a9be35d496d318a7565/video.m3u8
张学友-只想一生跟你走,http://vodcdn.video.taobao.com/oss/ali-video/7f567e1159256a099f3de8f1fdda2db0/video.m3u8
张学友-一颗不变心,http://vodcdn.video.taobao.com/oss/ali-video/1dcf180669ab98697e49c4c9b5f76cd7/video.m3u8
辛晓琪-领悟,http://vodcdn.video.taobao.com/oss/ali-video/2a4e61d4bba6b712bd5638fd508e85a5/video.m3u8
辛晓琪-俩俩相忘,http://vodcdn.video.taobao.com/oss/ali-video/6b406c70e3007a5c66a2085c39b13d80/video.m3u8
辛晓琪-味道,http://vodcdn.video.taobao.com/oss/ali-video/ce005204d02a88cfac474f1583f08add/video.m3u8
辛晓琪-仿佛是昨天,http://vodcdn.video.taobao.com/oss/ali-video/dbaf6d1d5a0ec2d93a668796e46e4f05/video.m3u8
梁静茹-问,http://vodcdn.video.taobao.com/oss/ali-video/b2a2adf565e97d00d1bd6d62145184d1/video.m3u8
黎瑞恩-为情为爱,http://vodcdn.video.taobao.com/oss/ali-video/73348f95d4cee3fcc96a63c30deed357/video.m3u8
冷漠-古咖啡,http://antiserver.kuwo.cn/anti.s?rid=MUSIC_3142984&response=res&format=mp4&type=convert_url
冷漠-时光海湾,http://antiserver.kuwo.cn/anti.s?rid=MUSIC_9867444&response=res&format=mp4&type=convert_url
冷漠-真不是闹着玩,http://antiserver.kuwo.cn/anti.s?rid=MUSIC_22836669&response=res&format=mp4&type=convert_url
冷漠-谁都不要说分手,http://antiserver.kuwo.cn/anti.s?rid=MUSIC_12975393&response=res&format=mp4&type=convert_url
冷漠-再爱也没有用,http://antiserver.kuwo.cn/anti.s?rid=MUSIC_5834217&response=res&format=mp4&type=convert_url
冷漠-不要再说你还爱我,http://antiserver.kuwo.cn/anti.s?rid=MUSIC_911272&response=res&format=mp4&type=convert_url
冷漠-别把寂寞当缘分,http://antiserver.kuwo.cn/anti.s?rid=MUSIC_6210858&response=res&format=mp4&type=convert_url
冷漠-你把爱情给了谁,http://antiserver.kuwo.cn/anti.s?rid=MUSIC_1210771&response=res&format=mp4&type=convert_url
冷漠-我是否也在你心中,http://antiserver.kuwo.cn/anti.s?rid=MUSIC_4378249&response=res&format=mp4&type=convert_url
凤凰传奇-华夏传说,http://antiserver.kuwo.cn/anti.s?rid=MUSIC_40828850&response=res&format=mp4&type=convert_url
凤凰传奇-今生的缘,http://antiserver.kuwo.cn/anti.s?rid=MUSIC_646024&response=res&format=mp4&type=convert_url
凤凰传奇-自由飞翔,http://antiserver.kuwo.cn/anti.s?rid=MUSIC_18747906&response=res&format=mp4&type=convert_url
凤凰传奇-策马奔腾,http://antiserver.kuwo.cn/anti.s?rid=MUSIC_24042013&response=res&format=mp4&type=convert_url
凤凰传奇-温柔姑娘,http://antiserver.kuwo.cn/anti.s?rid=MUSIC_6401404&response=res&format=mp4&type=convert_url
凤凰传奇-自由自在,http://antiserver.kuwo.cn/anti.s?rid=MUSIC_24042025&response=res&format=mp4&type=convert_url
凤凰传奇-奇迹世界,http://antiserver.kuwo.cn/anti.s?rid=MUSIC_954805&response=res&format=mp4&type=convert_url
凤凰传奇-歌唱二小放牛郎,http://antiserver.kuwo.cn/anti.s?rid=MUSIC_8120530&response=res&format=mp4&type=convert_url
凤凰传奇-中国味道,http://antiserver.kuwo.cn/anti.s?rid=MUSIC_24042021&response=res&format=mp4&type=convert_url
凤凰传奇-光芒,http://antiserver.kuwo.cn/anti.s?rid=MUSIC_24042019&response=res&format=mp4&type=convert_url
凤凰传奇-御龙归字谣,http://antiserver.kuwo.cn/anti.s?rid=MUSIC_1164118&response=res&format=mp4&type=convert_url
凤凰传奇-月亮之上,http://antiserver.kuwo.cn/anti.s?rid=MUSIC_7084968&response=res&format=mp4&type=convert_url
陈瑞-有谁知道我在等你,http://antiserver.kuwo.cn/anti.s?rid=MUSIC_1583218&response=res&format=mp4&type=convert_url
陈瑞-鱼和水的故事,http://antiserver.kuwo.cn/anti.s?rid=MUSIC_353501&response=res&format=mp4&type=convert_url
陈瑞-三生三世,http://antiserver.kuwo.cn/anti.s?rid=MUSIC_6449820&response=res&format=mp4&type=convert_url
陈瑞-一生的等待,http://antiserver.kuwo.cn/anti.s?rid=MUSIC_1583215&response=res&format=mp4&type=convert_url
陈瑞-一辈子的真爱,http://antiserver.kuwo.cn/anti.s?rid=MUSIC_28470656&response=res&format=mp4&type=convert_url
陈瑞-红尘永相伴,http://antiserver.kuwo.cn/anti.s?rid=MUSIC_506435&response=res&format=mp4&type=convert_url
陈瑞-爱的痕迹,http://antiserver.kuwo.cn/anti.s?rid=MUSIC_1218815&response=res&format=mp4&type=convert_url
陈瑞-分手了别来打扰我,http://antiserver.kuwo.cn/anti.s?rid=MUSIC_5835684&response=res&format=mp4&type=convert_url
陈瑞-烛光里的妈妈,http://antiserver.kuwo.cn/anti.s?rid=MUSIC_1024266&response=res&format=mp4&type=convert_url
陈瑞-爱得真伤的深,http://antiserver.kuwo.cn/anti.s?rid=MUSIC_1218839&response=res&format=mp4&type=convert_url
陈瑞-父亲,http://antiserver.kuwo.cn/anti.s?rid=MUSIC_4247454&response=res&format=mp4&type=convert_url
陈瑞-别思,http://antiserver.kuwo.cn/anti.s?rid=MUSIC_3429064&response=res&format=mp4&type=convert_url
陈瑞-天长地久,http://antiserver.kuwo.cn/anti.s?rid=MUSIC_1583220&response=res&format=mp4&type=convert_url
陈瑞-心中的牵挂,http://antiserver.kuwo.cn/anti.s?rid=MUSIC_1583211&response=res&format=mp4&type=convert_url
卓依婷心挂意无处用,http://vd3.bdstatic.com/mda-jfkgx7x5gki9xpgs/mda-jfkgx7x5gki9xpgs.mp4?playlist=%5B%22hd%22%2C%22sc%22%5D
卓依婷免失志,http://vd3.bdstatic.com/mda-jdngvdh4ru0irwma/mda-jdngvdh4ru0irwma.mp4?playlist=%5B%22hd%22%2C%22sc%22%5D
卓依婷无聊的爱情,http://vd3.bdstatic.com/mda-jfkhu7bksxcqjq2z/mda-jfkhu7bksxcqjq2z.mp4?playlist=%5B%22hd%22%2C%22sc%22%5D
卓依婷歹路不通行,http://vd3.bdstatic.com/mda-imigfktdeeseud4j/mda-imigfktdeeseud4j.mp4?playlist=%5B%22hd%22%2C%22sc%22%5D
卓依婷东南西北风,http://vd3.bdstatic.com/mda-jf9fszd51shymgp6/mda-jf9fszd51shymgp6.mp4?playlist=%5B%22hd%22%2C%22sc%22%5D
卓依婷夜来香,http://vd3.bdstatic.com/mda-jfai9k0sxf0nisvq/mda-jfai9k0sxf0nisvq.mp4?playlist=%5B%22hd%22%2C%22sc%22%5D
卓依婷旧情也绵绵,http://vd3.bdstatic.com/mda-jfje0s0z33b0c9vf/mda-jfje0s0z33b0c9vf.mp4?playlist=%5B%22hd%22%2C%22sc%22%5D
卓依婷雨过天晴,http://vd3.bdstatic.com/mda-jfbggf264f55hv4m/mda-jfbggf264f55hv4m.mp4?playlist=%5B%22hd%22%2C%22sc%22%5D
卓依婷看不见温柔,http://vd3.bdstatic.com/mda-jeqg6s6gc0ietmst/mda-jeqg6s6gc0ietmst.mp4?playlist=%5B%22hd%22%2C%22sc%22%5D
卓依婷大家一起来DJ,http://vd3.bdstatic.com/mda-jf1jfkgj3qte7h96/mda-jf1jfkgj3qte7h96.mp4?playlist=%5B%22hd%22%2C%22sc%22%5D
卓依婷蜗牛与黄鹂鸟,http://vd3.bdstatic.com/mda-jfjnacpfn6r21dec/mda-jfjnacpfn6r21dec.mp4?playlist=%5B%22hd%22%2C%22sc%22%5D
卓依婷山不转水转,http://vd3.bdstatic.com/mda-jb7pfvgc6wuivhqi/mda-jb7pfvgc6wuivhqi.mp4?playlist=%5B%22hd%22%2C%22sc%22%5D
卓依婷采红菱,http://vd3.bdstatic.com/mda-jfdvpsg280t986rz/mda-jfdvpsg280t986rz.mp4?playlist=%5B%22hd%22%2C%22sc%22%5D
卓依婷萍聚,http://vd3.bdstatic.com/mda-jenmbx88uk365k40/mda-jenmbx88uk365k40.mp4?playlist=%5B%22hd%22%2C%22sc%22%5D
卓依婷爱情一阵风,http://vd3.bdstatic.com/mda-jf5fre7jvd0q3rfu/mda-jf5fre7jvd0q3rfu.mp4?playlist=%5B%22hd%22%2C%22sc%22%5D
卓依婷梦醒十分,http://vd3.bdstatic.com/mda-jennyc5ci1ugrxzi/mda-jennyc5ci1ugrxzi.mp4?playlist=%5B%22hd%22%2C%22sc%22%5D
卓依婷无情的班机,http://vd3.bdstatic.com/mda-jeqjsqimdzvytgvv/mda-jeqjsqimdzvytgvv.mp4?playlist=%5B%22hd%22%2C%22sc%22%5D
卓依婷擦干眼泪,http://vd3.bdstatic.com/mda-jeqd4kq8iwh67a1k/mda-jeqd4kq8iwh67a1k.mp4?playlist=%5B%22hd%22%2C%22sc%22%5D
卓依婷同一首歌,http://vd3.bdstatic.com/mda-jf1j2af0dji6ju83/mda-jf1j2af0dji6ju83.mp4?playlist=%5B%22hd%22%2C%22sc%22%5D
卓依婷流星雨,http://vd3.bdstatic.com/mda-jfap39wqmi2yisu6/mda-jfap39wqmi2yisu6.mp4?playlist=%5B%22hd%22%2C%22sc%22%5D
卓依婷鲁冰花,http://vd3.bdstatic.com/mda-jf8fbjprnf1fvpxm/mda-jf8fbjprnf1fvpxm.mp4?playlist=%5B%22hd%22%2C%22sc%22%5D
卓依婷捉泥鳅,http://vd3.bdstatic.com/mda-jf6k8v71hrs8s441/mda-jf6k8v71hrs8s441.mp4?playlist=%5B%22hd%22%2C%22sc%22%5D
卓依婷电话情思,http://vd3.bdstatic.com/mda-jfghscj8datutink/mda-jfghscj8datutink.mp4?playlist=%5B%22hd%22%2C%22sc%22%5D
卓依婷杜十娘,http://vd3.bdstatic.com/mda-jekst5s3c341xwyd/mda-jekst5s3c341xwyd.mp4?playlist=%5B%22hd%22%2C%22sc%22%5D
卓依婷橄榄树,http://vd3.bdstatic.com/mda-jfagwdhxb30ymr13/mda-jfagwdhxb30ymr13.mp4?playlist=%5B%22hd%22%2C%22sc%22%5D
卓依婷花好月圆,http://vd3.bdstatic.com/mda-jepfhjwcthgci13y/mda-jepfhjwcthgci13y.mp4?playlist=%5B%22hd%22%2C%22sc%22%5D
卓依婷美酒加咖啡,http://vd3.bdstatic.com/mda-jfrred8ck6pnh6bq/mda-jfrred8ck6pnh6bq.mp4?playlist=%5B%22hd%22%2C%22sc%22%5D
卓依婷爱拼才会赢,http://vd3.bdstatic.com/mda-jfreugw1pcza8xr1/mda-jfreugw1pcza8xr1.mp4?playlist=%5B%22hd%22%2C%22sc%22%5D
卓依婷莫辜负好时光,http://vd3.bdstatic.com/mda-jfkkh6m5u47trvqc/mda-jfkkh6m5u47trvqc.mp4?playlist=%5B%22hd%22%2C%22sc%22%5D
卓依婷谢谢你的爱,http://vd3.bdstatic.com/mda-jf2fuh2yhd0txff0/mda-jf2fuh2yhd0txff0.mp4?playlist=%5B%22hd%22%2C%22sc%22%5D
卓依婷常回家看看,http://vd3.bdstatic.com/mda-jerf6nxy7nc0d6m5/mda-jerf6nxy7nc0d6m5.mp4?playlist=%5B%22hd%22%2C%22sc%22%5D
卓依婷无言的结局,http://vd3.bdstatic.com/mda-jenpdiydc7kez9ze/mda-jenpdiydc7kez9ze.mp4?playlist=%5B%22hd%22%2C%22sc%22%5D
二小姐酒梦,http://vd4.bdstatic.com/mda-jisq7k1t5n821tjt/sc/mda-jisq7k1t5n821tjt.mp4
王彩华爱情的骗子我问你,http://vd4.bdstatic.com/mda-jm4h7v1isxwc660u/sc/mda-jm4h7v1isxwc660u.mp4
蔡丽津月圆情,http://vd3.bdstatic.com/mda-jm53zq7k0b0kbxch/sc/mda-jm53zq7k0b0kbxch.mp4
江蕙梦中的情话,http://vd2.bdstatic.com/mda-ji4rwrwg7fijyqkh/mda-ji4rwrwg7fijyqkh.mp4
小凤凤爱情一阵风,http://vd2.bdstatic.com/mda-jjm7vgq1iahz0zpg/mda-jjm7vgq1iahz0zpg.mp4
张秀卿车站,http://vd2.bdstatic.com/mda-jjmnjgiabtvmy13u/sc/mda-jjmnjgiabtvmy13u.mp4
陈淑苹离家,http://vd2.bdstatic.com/mda-iftyuk6tjcxrm53p/sc/mda-iftyuk6tjcxrm53p.mp4
陈淑苹黄昏之恋,http://vd4.bdstatic.com/mda-jk0m1rgje4eh01cw/hd/mda-jk0m1rgje4eh01cw.mp4
陈百潭初恋,http://vd4.bdstatic.com/mda-jk22i7yt5vyjbgwt/hd/mda-jk22i7yt5vyjbgwt.mp4
翁立友坚持,http://vd2.bdstatic.com/mda-ji4uxxfqu5tgr7c3/mda-ji4uxxfqu5tgr7c3.mp4
翁立友甲妳惜命命,http://vd2.bdstatic.com/mda-jk2ptewhvn5cee6n/sc/mda-jk2ptewhvn5cee6n.mp4
翁立友限时批,http://vd3.bdstatic.com/mda-iighnnxyc3nfj9zu/sc/mda-iighnnxyc3nfj9zu.mp4
翁立友爱情的陷阱,http://vd3.bdstatic.com/mda-ijgee8tg9n4a95ij/sc/mda-ijgee8tg9n4a95ij.mp4
翁立友妈妈请你不通痛,http://vd3.bdstatic.com/mda-im9gh6d15m05zu9p/sc/mda-im9gh6d15m05zu9p.mp4
翁立友恁姊仔住市内,http://vd3.bdstatic.com/mda-ijfekw4yxergj9ak/sc/mda-ijfekw4yxergj9ak.mp4
翁立友我问天,http://vd4.bdstatic.com/mda-im9gwdckyxiq5ab6/sc/mda-im9gwdckyxiq5ab6.mp4
翁立友行棋,http://vd2.bdstatic.com/mda-ji4w8pcxse8taw5b/sc/mda-ji4w8pcxse8taw5b.mp4
翁立友情缘路,http://vd3.bdstatic.com/mda-ijgdxmwrrfv4tsam/sc/mda-ijgdxmwrrfv4tsam.mp4
翁立友前途,http://vd2.bdstatic.com/mda-jijnuvcf8ggs5wte/mda-jijnuvcf8ggs5wte.mp4
翁立友找巢,http://vd2.bdstatic.com/mda-jm5gc09g63p6j10k/sc/mda-jm5gc09g63p6j10k.mp4
翁立友温暖家园,http://vd3.bdstatic.com/mda-igim5cnwnq4xv94f/hd/mda-igim5cnwnq4xv94f.mp4
翁立友表示,http://vd4.bdstatic.com/mda-ijge8r0m6vgx46ms/sc/mda-ijge8r0m6vgx46ms.mp4
翁立友乎我理由,http://vd3.bdstatic.com/mda-jd0bzjvcp1d19b0k/sc/mda-jd0bzjvcp1d19b0k.mp4
翁立友沃澹的相片,http://vd4.bdstatic.com/mda-jefjhd593hvtfjsc/sc/mda-jefjhd593hvtfjsc.mp4
翁立友感恩,http://vd2.bdstatic.com/mda-jdc4v9b9tvrjw4pe/hd/mda-jdc4v9b9tvrjw4pe.mp4
翁立友迷魂香,http://vd1.bdstatic.com/mda-hid0euc4xc7xmum0/sc/mda-hid0euc4xc7xmum0.mp4
翁立友用泪写缘份,http://vd4.bdstatic.com/mda-ijfeqx4zc0gxq5jq/sc/mda-ijfeqx4zc0gxq5jq.mp4
翁立友痴情雨,http://vd1.bdstatic.com/mda-hemzqd1rrbr8q4kw/sc/mda-hemzqd1rrbr8q4kw.mp4
翁立友思念的情泪,http://vd3.bdstatic.com/mda-hmhng3p0jbskv57p/sc/mda-hmhng3p0jbskv57p.mp4
翁立友阿公的茶,http://vd2.bdstatic.com/mda-ijgqgd9jwz54ray7/sc/mda-ijgqgd9jwz54ray7.mp4
翁立友因为你的爱,http://vd2.bdstatic.com/mda-jk2r3d0w8sqkk59j/mda-jk2r3d0w8sqkk59j.mp4
翁立友送你送到这,http://vd2.bdstatic.com/mda-jm33ts9txcjuaq27/hd/mda-jm33ts9txcjuaq27.mp4
翁立友拼命的坚持,http://vd4.bdstatic.com/mda-jd9ksvdjk0n3qiae/hd/mda-jd9ksvdjk0n3qiae.mp4
翁立友爱过无心,http://vd4.bdstatic.com/mda-ijgqk17gxf3xh2wz/sc/mda-ijgqk17gxf3xh2wz.mp4
翁立友独身仔的生活,http://vd4.bdstatic.com/mda-jdmd7ydrsa0dp6e2/hd/mda-jdmd7ydrsa0dp6e2.mp4
翁立友为爱相逢,http://vd2.bdstatic.com/mda-ijgq79ukweagj0v0/sc/mda-ijgq79ukweagj0v0.mp4
翁立友今生今世,http://vd3.bdstatic.com/mda-ji4sadsbxes30b8h/mda-ji4sadsbxes30b8h.mp4
翁立友探听,http://vd2.bdstatic.com/mda-igmf3i4hied5ar5u/hd/mda-igmf3i4hied5ar5u.mp4
罗时丰无情之梦,http://vd2.bdstatic.com/mda-je1jq1hvgmab08gd/sc/mda-je1jq1hvgmab08gd.mp4
罗时丰心事,http://vd2.bdstatic.com/mda-jaadiz1rwrtrj7kw/sc/mda-jaadiz1rwrtrj7kw.mp4
罗时丰爱那么痛,http://vd2.bdstatic.com/mda-jcrjbhmgprhs00c4/sc/mda-jcrjbhmgprhs00c4.mp4
罗时丰擦掉彼句我爱你,http://vd1.bdstatic.com/mda-hj3j9zhu12h99a79/vs-f5f50550f0b93f5020da43ab88266eda-watermark/hd/mda-hj3j9zhu12h99a79.mp4
罗时丰爱情的路,http://vd4.bdstatic.com/mda-jcrjcp1wy5q2i00n/sc/mda-jcrjcp1wy5q2i00n.mp4
罗时丰一定要成功,http://vd1.bdstatic.com/mda-hgmk00ncqxvvix0v/mda-hgmk00ncqxvvix0v.mp4
体面,https://vdse.bdstatic.com//f18bdf41f28b68a1b0177fa5e5cdf8fe.mp4?authorization=bce-auth-v1%2F40f207e648424f47b2e3dfbb1014b1a5%2F2020-01-31T14%3A25%3A29Z%2F-1%2Fhost
sheep张艺兴,https://vdse.bdstatic.com/971347deaddd6fdb5ada6e87e4722ece.mp4?authorization=bce-auth-v1%2Ffb297a5cc0fb434c971b8fa103e8dd7b%2F2017-05-11T09%3A02%3A31Z%2F-1%2F
屋顶着火宋茜,https://vd3.bdstatic.com/mda-ife08h4xpq85sg65/logo/hd/mda-ife08h4xpq85sg65.mp4?pd=19&vt=1
凉凉张碧晨杨宗纬,https://vdse.bdstatic.com//56bc61cb4f9d080708a7e74647a1c2b2.mp4?authorization=bce-auth-v1%2F40f207e648424f47b2e3dfbb1014b1a5%2F2020-01-31T15%3A48%3A39Z%2F-
纸短情长,https://vdse.bdstatic.com//e214194bf6de7f598b9873619b691fa6.mp4?authorization=bce-auth-v1%2F40f207e648424f47b2e3dfbb1014b1a5%2F2020-01-31T13%3A26%3A53Z%2F-1%2Fhost
讲真的,https://vdse.bdstatic.com//9145a29aecbbf594c5b21ab1e6b14d20.mp4?authorization=bce-auth-v1%2F40f207e648424f47b2e3dfbb1014b1a5%2F2020-01-31T15%3A46%3A15Z%2F-1%2Fhost
陈柯宇生僻字,http://vd2.bdstatic.com/mda-jb28qp6tauzkzpy9/hd/mda-jb28qp6tauzkzpy9.mp4
往后余生,https://vd3.bdstatic.com/mda-jatub6sb1pzwxfnb/hd/mda-jatub6sb1pzwxfnb.mp4?pd=19&vt=1
盗将行,https://vdse.bdstatic.com//8355cbc6c2fe19c5ad280869218430f5.mp4?authorization=bce-auth-v1%2F40f207e648424f47b2e3dfbb1014b1a5%2F2020-01-31T13%3A03%3A13Z%2F-1%2Fhost
不仅仅是喜欢,https://vd3.bdstatic.com/mda-jhjswzf4u7tsujf1/hd/mda-jhjswzf4u7tsujf1.mp4?pd=19&vt=1
下山,https://vdse.bdstatic.com/e2d35750d461a6d524080c7a3c4cb7a4.mp4?authorization=bce-auth-v1%2F40f207e648424f47b2e3dfbb1014b1a5%2F2017-05-11T09%3A02%3A31Z%2F-1%2F
原版大鱼海棠,http://vd3.bdstatic.com/mda-jm9x2pw13gpb4d82/sc/mda-jm9x2pw13gpb4d82.mp4
摩登兄弟探清水河,http://vd2.bdstatic.com/mda-jg6dffnbt92877h0/sc/mda-jg6dffnbt92877h0.mp4
筷子兄弟小苹果,http://vd1.bdstatic.com/mda-hc2rwgemn6yrnvw2/mda-hc2rwgemn6yrnvw2.mp4
你的酒馆对我打了烊陈雪凝,https://vd3.bdstatic.com/mda-ka59e4w0qxxsxnt0/hd/mda-ka59e4w0qxxsxnt0.mp4?pd=19&vt=1
醉千年李袁杰,http://vd3.bdstatic.com/mda-ihai9qt3yny3sx53/hd/mda-ihai9qt3yny3sx53.mp4?pd=19&vt=1
不染,https://vd3.bdstatic.com/mda-jmceuahfwxarnh7v/hd/mda-jmceuahfwxarnh7v.mp4?pd=20&playlist=%5B%22hd%22%2C%22sc%22%5D
左手指月,https://vdse.bdstatic.com//b35227847ccb42d48ea6414d47087ce9.mp4?authorization=bce-auth-v1%2F40f207e648424f47b2e3dfbb1014b1a5%2F2020-01-31T15%3A26%3A59Z%2F-1%2Fhost
天地无霜,https://vdse.bdstatic.com//bd1f7fcb1263b608c60793c5c7094ce9.mp4?authorization=bce-auth-v1%2F40f207e648424f47b2e3dfbb1014b1a5%2F2020-01-31T15%3A25%3A13Z%2F-1%2Fhost
思慕郁可唯,https://vdse.bdstatic.com/5ec8d619d2ecb4ff832cfa252a967bb8.mp4?authorization=bce-auth-v1%2Ffb297a5cc0fb434c971b8fa103e8dd7b%2F2017-05-11T09%3A02%3A31Z%2F-1%2F
就算没有如果张杰,https://vdse.bdstatic.com//b362a1c2ecbc60b18d3dc06cdc97f142.mp4?authorization=bce-auth-v1%2F40f207e648424f47b2e3dfbb1014b1a5%2F2020-01-31T15%3A58%3A51Z%2F-
浮诛张杰,https://vdse.bdstatic.com/1c2dc5580507bc1b0ef507c63b3fc461.mp4?authorization=bce-auth-v1%2Ffb297a5cc0fb434c971b8fa103e8dd7b%2F2017-05-11T09%3A02%3A31Z%2F-1%2F
望赵丽颖张碧晨,https://vdse.bdstatic.com/25f5ae931f851bf09c48abaebe5d6f8d.mp4?authorization=bce-auth-v1%2F40f207e648424f47b2e3dfbb1014b1a5%2F2017-05-11T09%3A02%3A31Z%2F-1%2F
杀阡陌,https://vdse.bdstatic.com/17014878933308f5eb81b2a9d98783d8.mp4?authorization=bce-auth-v1%2Ffb297a5cc0fb434c971b8fa103e8dd7b%2F2017-05-11T09%3A02%3A31Z%2F-1%2F
一念一年,https://vdse.bdstatic.com/ea4ad861c3816ba29b415da2494706a1.mp4?authorization=bce-auth-v1%2Ffb297a5cc0fb434c971b8fa103e8dd7b%2F2017-05-11T09%3A02%3A31Z%2F-1%2F
余年,https://vdse.bdstatic.com/660c78b56b33dca31497de9c6921c5a6.mp4?authorization=bce-auth-v1%2Ffb297a5cc0fb434c971b8fa103e8dd7b%2F2017-05-11T09%3A02%3A31Z%2F-1%2F
只问你肯不肯,https://vdse.bdstatic.com/d4463cd83c0c47fba7ce65c71ad94bbb.mp4?authorization=bce-auth-v1%2Ffb297a5cc0fb434c971b8fa103e8dd7b%2F2017-05-11T09%3A02%3A31Z%2F-1%2F
如梦令,https://vdse.bdstatic.com/20e606730cb53b91bd4a4d2b0323e563.mp4?authorization=bce-auth-v1%2Ffb297a5cc0fb434c971b8fa103e8dd7b%2F2017-05-11T09%3A02%3A31Z%2F-1%2F
孤芳自赏,https://vdse.bdstatic.com//650fda26067e619a8632b173052b3a08.mp4?authorization=bce-auth-v1%2F40f207e648424f47b2e3dfbb1014b1a5%2F2020-01-31T14%3A25%3A59Z%2F-1%2Fhost
风筝误,https://vdse.bdstatic.com/c331feb0b4730b05d03793ffc024e62a.mp4?authorization=bce-auth-v1%2F40f207e648424f47b2e3dfbb1014b1a5%2F2017-05-11T09%3A02%3A31Z%2F-1%2F
我曾,https://vd3.bdstatic.com/mda-jjm8i93paakzz8yj/hd/mda-jjm8i93paakzz8yj.mp4?pd=20&vt=1
我愿意平凡的陪在你身旁,https://vdse.bdstatic.com/570e05ef514db00b14c9c10d1aef7f1f.mp4?authorization=bce-auth-v1%2Ffb297a5cc0fb434c971b8fa103e8dd7b%2F2017-05-11T09%3A02%3A31Z
大田后生仔,https://vdse.bdstatic.com/1f5b8de1e52e8ebe8d5493d29bf29981.mp4?authorization=bce-auth-v1%2Ffb297a5cc0fb434c971b8fa103e8dd7b%2F2017-05-11T09%3A02%3A31Z%2F-1%2F
芒种,https://vd3.bdstatic.com/mda-kat1tr4ka5st965k/hd/mda-kat1tr4ka5st965k.mp4?pd=20
芙蓉雨,https://vdse.bdstatic.com//85593e1127a1389dc49e9b0491814df2.mp4?authorization=bce-auth-v1%2F40f207e648424f47b2e3dfbb1014b1a5%2F2020-01-31T14%3A58%3A05Z%2F-1%2Fhost
你的答案,https://vdse.bdstatic.com/363480020aaa13240bbe51121d3e2a65.mp4?authorization=bce-auth-v1%2Ffb297a5cc0fb434c971b8fa103e8dd7b%2F2017-05-11T09%3A02%3A31Z%2F-1%2F
你若三冬,https://vdse.bdstatic.com/865b4e81a729189fcafe910104151a75.mp4?authorization=bce-auth-v1%2Ffb297a5cc0fb434c971b8fa103e8dd7b%2F2017-05-11T09%3A02%3A31Z%2F-1%2F
站着等你三千年,https://vdse.bdstatic.com//967f216dea39a6f3ccb44884a219f8ff.mp4?authorization=bce-auth-v1%2F40f207e648424f47b2e3dfbb1014b1a5%2F2019-12-14T02%3A12%3A33Z%2F-
世界美好与你环环相扣,https://vdse.bdstatic.com//90f59f9978da89c2f5f8dec807a238b6.mp4?authorization=bce-auth-v1%2F40f207e648424f47b2e3dfbb1014b1a5%2F2020-01-31T13%3A25%3A00Z%2F-
桥边姑娘,https://vdse.bdstatic.com/8ae4235344c61f9c05ccf3716c84e823.mp4?authorization=bce-auth-v1%2Ffb297a5cc0fb434c971b8fa103e8dd7b%2F2017-05-11T09%3A02%3A31Z%2F-1%2F
如果有一天我变的很有钱,https://vd3.bdstatic.com/mda-jjmfvpaqh1z11ibc/hd/mda-jjmfvpaqh1z11ibc.mp4?pd=19&vt=1
消愁,https://vd3.bdstatic.com/mda-ifkj2zwdscwthsfj/logo/hd/mda-ifkj2zwdscwthsfj.mp4?pd=20
Soda东南亚之旅,https://vdse.bdstatic.com//b6295e9776c2cd347716fc2447e27fac.mp4
SNH48剧场,http://117.148.179.139/PLTV/88888888/224/3221231622/index.m3u8
SNH48剧场,http://112.74.200.9:88/tv000000/m3u8.php?/migu/617432328
音乐榜,http://txtest-xp2p.p2p.huya.com/src/1099531740260-1099531740260-86382461021323264-2199063603976-10057-A-0-1.xs
音乐小石榴,http://txtest-xp2p.p2p.huya.com/src/1199512344405-1199512344405-5224693802798678016-2399024812266-10057-A-0-1.xs
音乐Retro,http://stream.mediawork.cz/retrotv/retrotvHQ1/playlist.m3u8
音乐MusicTop,http://live-edge01.telecentro.net.ar/live/smil:musictop.smil/chunklist_w538311571_b364000_sleng.m3u8
M2音乐,http://live.m2.tv/hls3/stream.m3u8
意大利V2,http://de1se01.v2beat.live/playlist.m3u8
法国时尚,http://lb.streaming.sk/fashiontv/stream/chunklist.m3u8
法国时尚,http://lb.streaming.sk/fashiontv/stream/chunklist_w1702070444.m3u8
imodeTV,http://juyunlive.juyun.tv/live/24950198.m3u8
欧美动感DJ,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgyMqg4gUo-uSR5AU.mp4
韩国动感舞曲,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgr-2n9AUoqsakNg.mp4
朴孝敏 –SKETCH,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAguq6r7gUouOyF4gE.mp4
欧美高清动感歌曲1,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgianW4gUoj9-Aaw.mp4
欧美高清动感歌曲2,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgpdia4gUo7oWfiAE.mp4
Girls Gone Wild,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgjd2w4gUou--ljQE.mp4
上下(中文版),https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgtd6M9QUokpHf7AY.mp4
欧美群星-天下一家,http://sofa.resource.shida.sogoucdn.com/6abaf62b-c77e-4642-999b-9301c1826f6e1_0_0.mp4
迈克尔杰克逊,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgw9ma4gUo3YLDvgU.mp4
泫雅-甩Nai舞,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgp92c4gUovM-V_QU.mp4
僵尸跳舞David Jones,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAg-vqa4gUotM7X6wc.mp4
MTV僵尸舞,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgw5Cv4gUoiZqZ4wE.mp4
Alan Walker-feat,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAg9qiM5gUo-tns8Qc.mp4
Trouble Maker,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAg2fWv4gUo9JT7DQ.mp4
Trouble Maker- Now,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgvue_4gUomZa1kQU.mp4
Stellar-Vibrato,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAg_O_-4gUo257EIg.mp4
School-Flashback,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAg_PSc4gUoxOLZ3AM.mp4
skart-短裙,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAggoG24gUouOfNkAM.mp4
Sistar - Give,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgkoe24gUo-OW_mwQ.mp4
School - 初恋,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgn-a24gUouMCswQY.mp4
Dal Shabet,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAg3fq95QUoisPxpAM.mp4
Marionette,http://video.yidianzixun.com/video/get-url?key=video/701b87f7467c0bc1dad16a60a1848446.mp4
Areia Kpop Remix,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAg____4gUopsLtrQQ.mp4
佳仁 - Paradise Lost,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgy9j64wUogPOGEQ.mp4
StickySticky,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgnIS24gUoptqYDQ.mp4
EXID - UP&DOWN,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgzMnG4gUoroOQgQU.mp4
Four Ladies-Move,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAg85Do5QUow-P-wwI.mp4
AOA - Excuse Me,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgmozg7AUolaeS8gU.mp4
AOA - Like A Cat,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgtfm95QUok8Wu6AQ.mp4
金泫雅,https://15799848.s21v.faiusr.com/58/ABUIABA6GAAgyt_s4gUolOCslAQ.mp4

📀女团,#genre#
韩国太妍01,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240162304531.mp4
韩国太妍02,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240167997205.mp4
韩国太妍03,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240059400880.mp4
韩国太妍04,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240407847242.mp4
韩国太妍05,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240062596020.mp4
韩国太妍06,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240170661907.mp4
韩国太妍07,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240411259014.mp4
韩国太妍08,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240174309994.mp4
韩国太妍09,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240175225325.mp4
韩国太妍10,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240066736888.mp4
韩国太妍11,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240175161903.mp4
韩国太妍12,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240295526170.mp4
韩国太妍13,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240295818399.mp4
韩国太妍14,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240177321736.mp4
韩国太妍15,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240177941288.mp4
韩国太妍16,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240070652257.mp4
韩国太妍17,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240298266546.mp4
韩国太妍18,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240070884570.mp4
韩国太妍19,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240298694512.mp4
韩国太妍20,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240418087243.mp4
韩国太妍21,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240299394846.mp4
韩国太妍22,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240181409471.mp4
韩国太妍23,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240182993056.mp4
韩国太妍24,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240301854532.mp4
韩国太妍25,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240075164377.mp4
韩国太妍26,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240349762400.mp4
韩国太妍27,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240121912724.mp4
韩国太妍28,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240126480392.mp4
韩国太妍29,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240355262537.mp4
韩国太妍30,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240355734488.mp4
韩国歌团★001,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240095359203.mp4
韩国歌团★002,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239978750464.mp4
韩国歌团★003,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239858729476.mp4
韩国歌团★004,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239755956819.mp4
韩国歌团★005,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239987758613.mp4
韩国歌团★006,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239880949246.mp4
韩国歌团★007,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239903717006.mp4
韩国歌团★008,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239903321355.mp4
韩国歌团★009,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239799872402.mp4
韩国歌团★010,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239799088974.mp4
韩国歌团★011,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240024786285.mp4
韩国歌团★012,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240142715042.mp4
韩国歌团★013,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240025046562.mp4
韩国歌团★014,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240145171654.mp4
韩国歌团★015,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240147051191.mp4
韩国歌团★016,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239805200933.mp4
韩国歌团★017,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239910253332.mp4
韩国歌团★018,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239806164759.mp4
韩国歌团★019,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239807872136.mp4
韩国歌团★020,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240032526123.mp4
韩国歌团★021,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239808028600.mp4
韩国歌团★022,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240031614983.mp4
韩国歌团★023,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240150331617.mp4
韩国歌团★024,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239809100782.mp4
韩国歌团★025,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240151167718.mp4
韩国歌团★026,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240033362815.mp4
韩国歌团★027,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240151167938.mp4
韩国歌团★028,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240035466345.mp4
韩国歌团★029,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239811800375.mp4
韩国歌团★030,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239916285148.mp4
韩国歌团★031,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239927589941.mp4
韩国歌团★032,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239931661209.mp4
韩国歌团★033,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240171579858.mp4
韩国歌团★034,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239831144046.mp4
韩国歌团★035,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240056530470.mp4
韩国歌团★036,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239832040344.mp4
韩国歌团★037,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240173879894.mp4
韩国歌团★038,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240057078179.mp4
韩国歌团★039,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239936685999.mp4
韩国歌团★040,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240059018784.mp4
韩国歌团★041,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239834324813.mp4
韩国歌团★042,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239834716201.mp4
韩国歌团★043,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239837532125.mp4
韩国歌团★044,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240179867562.mp4
韩国歌团★045,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240063650207.mp4
韩国歌团★046,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240181243061.mp4
韩国歌团★047,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240181363115.mp4
韩国歌团★048,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239944465251.mp4
韩国歌团★049,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240065122134.mp4
韩国歌团★050,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239840536452.mp4
韩国歌团★051,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240065838644.mp4
韩国歌团★052,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239945877111.mp4
韩国歌团★053,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240184339138.mp4
韩国歌团★054,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239842640589.mp4
韩国歌团★055,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240186067562.mp4
韩国歌团★056,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240187071401.mp4
韩国歌团★057,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240069974546.mp4
韩国歌团★058,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240070346911.mp4
韩国歌团★059,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240070818783.mp4
韩国歌团★060,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239846692034.mp4
韩国歌团★061,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239951329234.mp4
韩国歌团★062,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240191295627.mp4
韩国歌团★063,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240026585459.mp4
韩国歌团★064,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240192067467.mp4
韩国歌团★065,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239911732892.mp4
韩国歌团★066,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240196491782.mp4
韩国歌团★067,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239960909980.mp4
韩国歌团★068,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240017737344.mp4
韩国歌团★069,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240202339353.mp4
韩国歌团★070,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240203243765.mp4
韩国歌团★071,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240205555546.mp4
韩国歌团★072,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239983417489.mp4
韩国歌团★074,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240221687198.mp4
韩国歌团★075,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240222023079.mp4
韩国歌团★076,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240107150280.mp4
韩国歌团★077,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240224523227.mp4
韩国歌团★078,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239987569147.mp4
韩国歌团★079,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240225803033.mp4
韩国歌团★080,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239989445779.mp4
韩国歌团★081,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240229579224.mp4
韩国歌团★082,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239993533054.mp4
韩国歌团★083,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239994225085.mp4
韩国歌团★084,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239994741288.mp4
韩国歌团★085,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239995197198.mp4
韩国歌团★086,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240232939168.mp4
韩国歌团★087,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239890536417.mp4
韩国歌团★088,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239890568711.mp4
韩国歌团★089,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240233783820.mp4
韩国歌团★090,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239894180409.mp4
韩国歌团★092,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239895496483.mp4
韩国歌团★093,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240119938989.mp4
韩国歌团★094,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240002397273.mp4
韩国歌团★095,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240241527208.mp4
韩国歌团★096,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239899840062.mp4
韩国歌团★097,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240243499351.mp4
韩国歌团★098,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240127638122.mp4
韩国歌团★099,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240030505796.mp4
韩国歌团★100,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240245283772.mp4
韩国歌团★101,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240247623420.mp4
韩国歌团★102,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240043672242.mp4
韩国歌团★103,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240339124000.mp4
韩国歌团★104,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240221702622.mp4
韩国歌团★105,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239993732827.mp4
韩国歌团★106,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239994460907.mp4
韩国歌团★107,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240340899550.mp4
韩国歌团★108,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239995692215.mp4
韩国歌团★109,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240341971789.mp4
韩国歌团★110,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239996664565.mp4
韩国歌团★111,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240342839842.mp4
韩国歌团★112,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240225254466.mp4
韩国歌团★113,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240225226897.mp4
韩国歌团★114,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239998000351.mp4
韩国歌团★115,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240105989528.mp4
韩国歌团★116,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/239998340711.mp4
韩国歌团★117,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240106477140.mp4
韩国歌团★118,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240107389699.mp4
韩国歌团★119,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240345787129.mp4
韩国歌团★120,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240227966801.mp4
韩国歌团★121,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240228462625.mp4
韩国歌团★122,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240108721427.mp4
韩国歌团★123,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240001176191.mp4
韩国歌团★125,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240001228776.mp4
韩国歌团★126,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240109533631.mp4
韩国歌团★127,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240347663598.mp4
韩国歌团★128,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240001932458.mp4
韩国歌团★129,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240002044738.mp4
韩国歌团★130,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240111085001.mp4
韩国歌团★131,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240350575186.mp4
韩国歌团★132,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240350771160.mp4
韩国歌团★133,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240113261859.mp4
韩国歌团★134,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240352039996.mp4
韩国歌团★135,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240236014123.mp4
韩国歌团★136,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240008036293.mp4
韩国歌团★137,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240354863286.mp4
韩国歌团★138,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240008780109.mp4
韩国歌团★139,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240009608741.mp4
韩国歌团★140,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240379515679.mp4
韩国歌团★141,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240262842385.mp4
韩国歌团★142,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240264262344.mp4
韩国歌团★143,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240384227055.mp4
韩国歌团★145,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240267170778.mp4
韩国歌团★146,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240386743317.mp4
韩国歌团★147,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240268654616.mp4
韩国歌团★148,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240387107547.mp4
韩国歌团★149,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240150573492.mp4
韩国歌团★150,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240388683474.mp4
韩国歌团★151,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240270774376.mp4
韩国歌团★152,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240151273206.mp4
韩国歌团★153,https://cloud.video.taobao.com//play/u/57349687/p/1/e/6/t/1/240389031565.mp4
🎏景区 ,#genre#
峨眉山普贤菩萨,http://gcalic.v.myalicdn.com/gc/gccntv241-slf01_1/index.m3u8
宁夏大漠孤烟,http://gcksc.v.kcdnvip.com/gc/tjhh01_1/index.m3u8
映秀新城,http://gcbsc.v.live.baishancdnx.cn/gc/wcyxxc01_1/index.m3u8
福建华安土楼,http://gccncc.v.wscdns.com/gc/syns01_1/index.m3u8
梅州梅江,http://gctxyc.liveplay.myqcloud.com/gc/gllj01_1_md.m3u8
河南二七塔,http://gctxyc.liveplay.myqcloud.com/gc/xysrf_1_md.m3u8
舟山东极岛,http://gctxyc.liveplay.myqcloud.com/gc/djd01_1_md.m3u8
福建三坊七巷,http://gcksc.v.kcdnvip.com/gc/hhdxg01_1/index.m3u8
武汉两江四岸,https://gcalic.v.myalicdn.com/gc/emspxps_1/index.m3u8?contentid=2820180516001
四川达古冰川,https://gccncc.v.wscdns.com/gc/ztx_1/index.m3u8?contentid=2820180516001
广西崇左白头猴国家级自然保护区,https://gcalic.v.myalicdn.com/gc/ztd_1/index.m3u8?contentid=2820180516001
广州塔和海心桥,https://gcalic.v.myalicdn.com/gc/ztb_1/index.m3u8?contentid=2820180516001
全国风景总览,https://gcalic.v.myalicdn.com/gc/wgw05_1/index.m3u8?contentid=2820180516001
黟县宏村月沼,https://gctxyc.liveplay.myqcloud.com/gc/yxhcyz_1/index.m3u8?contentid=2820180516001
黟县宏村南湖,https://gcalic.v.myalicdn.com/gc/yxhcnh_1/index.m3u8?contentid=2820180516001
黟县西递牌坊,https://gcalic.v.myalicdn.com/gc/yxxdpf_1/index.m3u8?contentid=2820180516001
黟县西递半山亭,https://gcalic.v.myalicdn.com/gc/yxxdbst_1/index.m3u8?contentid=2820180516001
黟县卢村远眺,https://gccncc.v.wscdns.com/gc/yxlcyt_1/index.m3u8?contentid=2820180516001
九寨沟,https://gctxyc.liveplay.myqcloud.com/gc/wygjt1_1/index.m3u8?contentid=2820180516001
南昌滕王阁,https://gccncc.v.wscdns.com/gc/wygjt2_1/index.m3u8?contentid=2820180516001
黄山始信峰,https://gctxyc.liveplay.myqcloud.com/gc/hssxf_1/index.m3u8?contentid=2820180516001
黄山卧云峰,https://gcalic.v.myalicdn.com/gc/hswlf_1/index.m3u8?contentid=2820180516001
黄山梦笔生花,https://gccncc.v.wscdns.com/gc/hsmbsh_1/index.m3u8?contentid=2820180516001
黄山排云亭,https://gcalic.v.myalicdn.com/gc/hspyt_1/index.m3u8?contentid=2820180516001
黄山西海峡谷,https://gcalic.v.myalicdn.com/gc/hsxhdxg_1/index.m3u8?contentid=2820180516001
黄山光明顶,https://gccncc.v.wscdns.com/gc/hsgmd_1/index.m3u8?contentid=2820180516001
黄山信兴道,https://gccncc.v.wscdns.com/gc/hsyg_1/index.m3u8?contentid=2820180516001
黄山平天矼,https://gcalic.v.myalicdn.com/gc/hsptgz_1/index.m3u8?contentid=2820180516001
黄山飞来石,https://gccncc.v.wscdns.com/gc/hsptgy_1/index.m3u8?contentid=2820180516001
云台山红石硖,https://gcalic.v.myalicdn.com/gc/ytshsx_1/index.m3u8?contentid=2820180516001
泰山黄岘岭,https://gctxyc.liveplay.myqcloud.com/gc/taishan01_1/index.m3u8?contentid=2820180516001
泰山大观峰,https://gctxyc.liveplay.myqcloud.com/gc/taishan03_1/index.m3u8?contentid=2820180516001
泰山拱北石,https://gcalic.v.myalicdn.com/gc/taishan04_1/index.m3u8?contentid=2820180516001
济南千佛山望泉城,https://gcalic.v.myalicdn.com/gc/taishan05_1/index.m3u8?contentid=2820180516001
泰山玉皇顶,https://gcalic.v.myalicdn.com/gc/taishan06_1/index.m3u8?contentid=2820180516001
泰山天街,https://gccncc.v.wscdns.com/gc/taishan07_1/index.m3u8?contentid=2820180516001
淳安界首渔港码头,https://gccncc.v.wscdns.com/gc/ytsxzg_1/index.m3u8?contentid=2820180516001
新疆红山,https://gccncc.v.wscdns.com/gc/ytsbjy_1/index.m3u8?contentid=2820180516001
远眺万佛顶,https://gcalic.v.myalicdn.com/gc/emswfs_1/index.m3u8?contentid=2820180516001
印象大红袍,https://gctxyc.liveplay.myqcloud.com/gc/wysyxdhp_1/index.m3u8?contentid=2820180516001
无锡惠山二茅峰望锡城,https://gctxyc.liveplay.myqcloud.com/gc/wysdhpcy_1/index.m3u8?contentid=2820180516001
张家界迷魂台,https://gccncc.v.wscdns.com/gc/zjjmht_1/index.m3u8?contentid=2820180516001
张家界水绕4门,https://gccncc.v.wscdns.com/gc/zjjsrsm_1/index.m3u8?contentid=2820180516001
张家界将军列队,https://gctxyc.liveplay.myqcloud.com/gc/zjjjjdl_1/index.m3u8?contentid=2820180516001
张家界阿凡达悬浮山,https://gcalic.v.myalicdn.com/gc/zjjafdxfs_1/index.m3u8?contentid=2820180516001
凤凰古城,https://gccncc.v.wscdns.com/gc/fhgcdgm_1/index.m3u8?contentid=2820180516001
凤凰古城南华山,https://gccncc.v.wscdns.com/gc/fhgcdnhs_1/index.m3u8?contentid=2820180516001
重庆开州城区,https://gccncc.v.wscdns.com/gc/zsslsgc_1/index.m3u8?contentid=2820180516001
黄花城水长城1,https://gcalic.v.myalicdn.com/gc/wgw01_1/index.m3u8?contentid=2820180516001
黄花城水长城2,https://gcalic.v.myalicdn.com/gc/wgw02_1/index.m3u8?contentid=2820180516001
黄花城水长城4,https://gccncc.v.wscdns.com/gc/wgw04_1/index.m3u8?contentid=2820180516001
天津滨海新区,https://gccncc.v.wscdns.com/gc/ljgcszsnkgc_1/index.m3u8?contentid=2820180516001
天津滨海新区2,https://gcalic.v.myalicdn.com/gc/ljgcwglytylxs_1/index.m3u8?contentid=2820180516001
吉安井冈山红旗广场,https://gcalic.v.myalicdn.com/gc/ljgcdyhxgjt_1/index.m3u8?contentid=2820180516001
峨眉云海日出,https://gctxyc.liveplay.myqcloud.com/gc/emsarm_1/index.m3u8?contentid=2820180516001
贡嘎雪山,https://gctxyc.liveplay.myqcloud.com/gc/emsyh_1/index.m3u8?contentid=2820180516001
悬空寺全景,https://gcalic.v.myalicdn.com/gc/hsxksqj_1/index.m3u8?contentid=2820180516001
张家界玻璃桥,https://gcalic.v.myalicdn.com/gc/hsxkssqdzrqj_1/index.m3u8?contentid=2820180516001
车八岭国家自然保护区,https://gcalic.v.myalicdn.com/gc/hsxkscj_1/index.m3u8?contentid=2820180516001
伊犁巩留县蝶湖公园,https://gctxyc.liveplay.myqcloud.com/gc/tyhjtynl_1/index.m3u8?contentid=2820180516001
重庆洪崖洞,https://gctxyc.liveplay.myqcloud.com/gc/tyhjtys_1/index.m3u8?contentid=2820180516001
南天一柱,https://gctxyc.liveplay.myqcloud.com/gc/tyhjntyz_1/index.m3u8?contentid=2820180516001
雪乡大石碑,https://gcalic.v.myalicdn.com/gc/mdjxxdsb_1/index.m3u8?contentid=2820180516001
雪乡梦幻家园,https://gctxyc.liveplay.myqcloud.com/gc/mdjxxmhjyxj_1/index.m3u8?contentid=2820180516001
江西武功山云顶,https://gctxyc.liveplay.myqcloud.com/gc/jyg04_1/index.m3u8?contentid=2820180516001
嵌雪楼,https://gccncc.v.wscdns.com/gc/ljgcdsc_1/index.m3u8?contentid=2820180516001
丹霞山丹梯铁锁,http://gctxyc.liveplay.myqcloud.com/gc/dxsdtts_1_md.m3u8
韶音亭,http://gctxyc.liveplay.myqcloud.com/gc/dxssyt_1_md.m3u8
坝达景点观景台,http://gccncc.v.wscdns.com/gc/hnttbdjd_1/index.m3u8
多依树景点,http://gcksc.v.kcdnvip.com/gc/hnttdysjd_1/index.m3u8
普高老寨,http://gctxyc.liveplay.myqcloud.com/gc/hnttpgsz_1_md.m3u8
山涧栈道,http://gcbsc.v.live.baishancdnx.cn/gc/lhssjzd_1/index.m3u8
七曲山风景区,http://gcbsc.v.live.baishancdnx.cn/gc/wysyxdhp_1/index.m3u8
山西省宋家沟村,http://gcalic.v.myalicdn.com/gc/wysdhpcy_1/index.m3u8
十八洞村,http://gcksc.v.kcdnvip.com/gc/sbd01_1/index.m3u8
桂林象山公园,http://gcksc.v.kcdnvip.com/gc/glxs01_1/index.m3u8
峡谷石林,http://gcalic.v.myalicdn.com/gc/pshdxg02_1/index.m3u8
内蒙古云计算信息园,http://gcksc.v.kcdnvip.com/gc/tyhjntyz_1/index.m3u8
宁夏回族上滩村,http://gctxyc.liveplay.myqcloud.com/gc/tyhjrys_1_md.m3u8
甘肃火星1号基地,http://gcksc.v.kcdnvip.com/gc/hgsylztpb_1/index.m3u8
六角亭瀑布,http://gcalic.v.myalicdn.com/gc/hgsspzxdpb_1/index.m3u8
深圳世界之窗,http://gcalic.v.myalicdn.com/gc/sjzc01_1/index.m3u8
远眺贡嘎雪山,http://gcalic.v.myalicdn.com/gc/emsyh_1/index.m3u8
普贤菩萨铜像,http://gcalic.v.myalicdn.com/gc/emspxps_1/index.m3u8
远眺万佛顶,http://gcalic.v.myalicdn.com/gc/emswfs_1/index.m3u8
凤凰古城东关门,http://gcksc.v.kcdnvip.com/gc/fhgcdgm_1/index.m3u8
凤凰古城南华山,http://gctxyc.liveplay.myqcloud.com/gc/fhgcdnhs_1_md.m3u8
芦村远眺,http://gcalic.v.myalicdn.com/gc/yxlcyt_1/index.m3u8
西递半山亭,http://gcalic.v.myalicdn.com/gc/yxxdbst_1/index.m3u8
西递牌坊,http://gcbsc.v.live.baishancdnx.cn/gc/yxxdpf_1/index.m3u8
宏村月沼,http://gcbsc.v.live.baishancdnx.cn/gc/yxhcyz_1/index.m3u8
云台山-小寨沟,http://gctxyc.liveplay.myqcloud.com/gc/ytsxzg_1_md.m3u8
云台山-百家岩,http://gccncc.v.wscdns.com/gc/ytsbjy_1/index.m3u8
云台山-红石峡,http://gcalic.v.myalicdn.com/gc/ytshsx_1/index.m3u8
福建宁德太姥山景区,http://gcksc.v.kcdnvip.com/gc/tms01_1/index.m3u8
崇圣寺三塔中景,http://gcksc.v.kcdnvip.com/gc/dlst03_1/index.m3u8
崇圣寺三塔湖面,http://gcalic.v.myalicdn.com/gc/dlst02_1/index.m3u8
崇圣寺三塔远景,http://gcbsc.v.live.baishancdnx.cn/gc/dlst01_1/index.m3u8
西汉南越王博物馆,http://gctxyc.liveplay.myqcloud.com/gc/nywbwg01_1_md.m3u8
醉美沙滩翡翠湾,http://gcksc.v.kcdnvip.com/gc/fcw03_1/index.m3u8
漳州六鳌翡翠湾,http://gcalic.v.myalicdn.com/gc/fcw01_1/index.m3u8
云龙山观景台西,http://gcalic.v.myalicdn.com/gc/ylh04_1/index.m3u8
云龙山观景台南,http://gctxyc.liveplay.myqcloud.com/gc/ylh03_1_md.m3u8
趵突泉,http://gcksc.v.kcdnvip.com/gc/btq01_1/index.m3u8
厦门鼓浪屿,http://gctxyc.liveplay.myqcloud.com/gc/gly01_1_md.m3u8
玉液湖,http://gcksc.v.kcdnvip.com/gc/hkylxs02_1/index.m3u8
蓝月谷,http://gccncc.v.wscdns.com/gc/ylxs12_1/index.m3u8
千岛湖,http://gctxyc.liveplay.myqcloud.com/gc/caqdh_1_md.m3u8
黟县·西递牌坊,http://gcalic.v.myalicdn.com/gc/yxxdpf_1/index.m3u8
乌镇·西市河,http://gcalic.v.myalicdn.com/gc/zjwzbblh_1/index.m3u8
蓝印花布,http://gctxyc.liveplay.myqcloud.com/gc/zjwzlyhb_1_md.m3u8
龙形田,http://gcalic.v.myalicdn.com/gc/zjwzlxt_1/index.m3u8
乌镇全景,http://gcalic.v.myalicdn.com/gc/zjwzblt_1/index.m3u8
鸣沙山山门,http://gcalic.v.myalicdn.com/gc/dhyyqyyq_1/index.m3u8
鸣沙山,http://gcksc.v.kcdnvip.com/gc/dhyyqst_1/index.m3u8
鸣沙山月牙泉,http://gcalic.v.myalicdn.com/gc/dhyyqsm_1/index.m3u8
哈尼梯田,http://gcalic.v.myalicdn.com/gc/hnttpgsz_1/index.m3u8
八达岭长城南七楼,http://gcalic.v.myalicdn.com/gc/bgws7_1/index.m3u8
嘉峪关关城,http://gcalic.v.myalicdn.com/gc/jyg04_1/index.m3u8
四姑娘山幺妹峰,http://gcbsc.v.live.baishancdnx.cn/gc/sgns01_1/index.m3u8
隆珠措,http://gctxyc.liveplay.myqcloud.com/gc/sgns02_1_md.m3u8
九华山,http://gctxyc.liveplay.myqcloud.com/gc/jhs05_1_md.m3u8
九华山花台,http://gccncc.v.wscdns.com/gc/jhs01_1/index.m3u8
天界山-玻璃栈道,http://gcalic.v.myalicdn.com/gc/blg03_1/index.m3u8
天界山-桃花湾瀑布,http://gccncc.v.wscdns.com/gc/blg05_1/index.m3u8
天山-定海神针,http://gctxyc.liveplay.myqcloud.com/gc/xjtcdhsz_1_md.m3u8
天山-海西平台,http://gctxyc.liveplay.myqcloud.com/gc/xjtchxpt_1_md.m3u8
天山-马牙山,http://gctxyc.liveplay.myqcloud.com/gc/xjtcmys_1_md.m3u8
天山-灯杆山,http://gctxyc.liveplay.myqcloud.com/gc/xjtcdgs_1_md.m3u8
天门洞,http://gcalic.v.myalicdn.com/gc/tmstmd01_1/index.m3u8
天空步道,http://gcalic.v.myalicdn.com/gc/tms02_1/index.m3u8
云梦仙顶,http://gctxyc.liveplay.myqcloud.com/gc/tms04_1_md.m3u8
大容山莲花山顶,http://gctxyc.liveplay.myqcloud.com/gc/drs01_1_md.m3u8
南京玄武湖公园,http://gcksc.v.kcdnvip.com/gc/xwh01_1/index.m3u8
江苏南京牛首山,http://gctxyc.liveplay.myqcloud.com/gc/nss01_1_md.m3u8
郑东新区千玺广场,http://gctxyc.liveplay.myqcloud.com/gc/zdxq01_1_md.m3u8
湖南岳阳楼,http://gcalic.v.myalicdn.com/gc/pts01_1/index.m3u8
西藏米林拉林铁路,http://gctxyc.liveplay.myqcloud.com/gc/zyqcdx01_1_md.m3u8
四川凉山邛海景区,http://gctxyc.liveplay.myqcloud.com/gc/xcqh01_1_md.m3u8
贵阳甲秀楼,http://gccncc.v.wscdns.com/gc/nxsptdmgychlr_1/index.m3u8
宁夏黄河漂流,http://gctxyc.liveplay.myqcloud.com/gc/nxspthhpl_1_md.m3u8
江苏聚龙湖,http://gctxyc.liveplay.myqcloud.com/gc/nxsptdmgy_1_md.m3u8
大研花巷观景,http://gcbsc.v.live.baishancdnx.cn/gc/ljgcdyhxgjt_1/index.m3u8
内蒙古额济纳胡杨林,http://gcksc.v.kcdnvip.com/gc/ljgcdsc_1/index.m3u8
天津滨海新区,http://gccncc.v.wscdns.com/gc/ljgcwglytylxs_1/index.m3u8
五彩池,http://gccncc.v.wscdns.com/gc/hlwcc_1/index.m3u8
黄龙·争艳彩池,http://gcalic.v.myalicdn.com/gc/hlzycc_1/index.m3u8
黄龙望乡台,http://gcksc.v.kcdnvip.com/gc/hlwxt_1/index.m3u8
